# Status do port

Legenda: [x] feito e testado no PC | [~] escrito, nao testado | [ ] nao feito

## Nucleo
- [x] Andar/correr com estagios de velocidade e aceleracao do original
- [x] Derrapagem (skid) e virada rapida (fast turnaround)
- [x] Pulo: buffer 12 frames, coyote 3 frames, bonus de velocidade, duplo/triplo
- [x] Gravidade por estagios + velocidade terminal
- [x] Colisao AABB com tiles solidos, wrap lateral
- [x] Pisao entre jogadores
- [x] Agachar (HandleCrouching): para de andar no chao, congela agachado no ar subindo, queda lenta ao sair de borda
- [x] Wallslide e walljump (HandleWallslide): velocidade terminal -4.6875, walljump 4.21875 x 6.4453, 16 frames sem controle
- [x] HandleFacingDirection (subconjunto)
- [x] Teste automatico: vel. andar 2.8125, pulo segurando 2.18 tiles, tap 0.58 tiles

## Online
- [x] Servidor relay (salas com codigo de 4 caracteres, lobby, pronto/iniciar, retransmissao)
- [x] Cliente de rede e lockstep (atraso de 3 frames); estado identico nos dois clientes apos 600 frames (teste)
- [x] Menu, configurar servidor (IP:porta), digitar codigo, lobby, erros (sala inexistente, cheia, nem todos prontos, queda)
- [x] Fluxo completo testado pelo menu com dois apps
- [~] Sockets no PS3 (netInitialize, SO_NBIO): escritos pela API do PSL1GHT, NAO testados no console
- [ ] Hostname/DNS (so IPv4 numerico), mais de 2 jogadores, rollback, reconexao, nomes editaveis
- [ ] Float em PowerPC vs PC: o teste de bit-a-bit foi PC com PC; entre dois PS3 deve bater (mesmo hardware)

## Camada PS3
- [~] Video RSX (framebuffer direto), 2 buffers, vsync
- [~] Entrada DualShock 3 (2 controles)
- [~] Makefile / sfo.xml / .pkg
- [~] Texto e menus (fonte 5x7 propria, conferida em imagens no PC)
- [ ] Audio, sprites

## Diferencas conhecidas em relacao ao original
- Floats em vez de ponto fixo deterministico (FP do Quantum). Irrelevante offline; importa para rollback online.
- Largura da hitbox (0.40) e estimativa; altura (0.42) e do original.
- Faltam: gelo, rampas/angulos, agua, canos, groundpound, deslizar.
- Agachar nao muda a hitbox ainda (o original so muda com powerups grandes).
- Faltam: powerups (cogumelo, flor, estrela, helice, casco, mega/mini), inimigos, blocos, moedas, estrelas, modos de jogo.
- Faltam: todas as 5 fases oficiais (Tilemaps do Unity precisam de conversor) e o menu.
- Online: rede propria (relay + lockstep) no lugar do Photon Quantum; sem predicao/rollback.

## Proximos marcos sugeridos
1. Compilar e rodar a camada PS3 (corrigir o que aparecer)
2. Groundpound, rampas, gelo, canos, agua
3. Blocos + powerup de cogumelo (hitbox grande)
4. Sprites (conversor PNG -> textura) e HUD
5. Inimigos (Goomba, Koopa) a partir de Entity/Enemy
6. Conversor de fases Unity -> ASCII/binario
7. Rollback / mais jogadores / nomes
