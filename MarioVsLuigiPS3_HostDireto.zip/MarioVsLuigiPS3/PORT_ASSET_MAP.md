# Mapa de assets / codigo: original -> port

Origem: NSMB-MarioVsLuigi-master.zip (5983 arquivos, ~320 MB). Quase tudo e Unity/Photon; so uma fracao e logica de jogo.

| Original | Port | Estado |
|---|---|---|
| Assets/QuantumUser/Simulation/NSMB/Entity/Player/MarioPlayerPhysicsInfo.cs | include/physics_info.h | portado (subconjunto) |
| .../Player/MarioPlayerSystem.cs (HandleWalkingRunning, HandleJumping, HandleGravity, HandleTerminalVelocity) | source/game.c | portado |
| .../Entity/Physics/PhysicsObjectSystem.cs (1477 linhas) | source/game.c (AABB simples) | simplificado |
| .../Entity/Enemy/* (21 arquivos) | - | pendente |
| .../Entity/Powerup/*, Projectile/*, Coin*, BigStar | - | pendente |
| .../Map/* (blocos, canos, plataformas, liquidos) | - | pendente |
| .../Gamemode/StarChasersGamemode.cs, CoinRunnersGamemode.cs | - | pendente |
| Assets/Resources/Tilemaps (771 arquivos) | data/*.txt | so 1 fase propria de teste |
| Assets/Sprites/*, Assets/Sound/* | - | pendente (precisa de conversor) |
| Assets/Photon/*, Assets/QuantumUser/Simulation/Generated | - | nao portavel (engine/rede) |
| Assets/Scripts/UI (348 arquivos) | - | refazer do zero |
