# Fontes

- Projeto original: https://ipodtouch0218.itch.io/nsmb-mariovsluigi (codigo no zip enviado)
- Codigo lido para o port: MarioPlayerPhysicsInfo.cs, MarioPlayerSystem.cs, MarioPlayer.cs
- SDK PS3 homebrew: PSL1GHT (https://github.com/ps3dev/PSL1GHT), toolchain em ps3dev
- Emulador para testes: RPCS3

## Licenca e direitos (confirmar antes de distribuir)
- Nao encontrei arquivo LICENSE na raiz do zip, so licencas de bibliotecas de terceiros. Peca permissao ao autor (ipodtouch0218).
- Photon Quantum tem licenca propria e nao deve ser redistribuido.
- Personagens e assets do Mario sao da Nintendo. Este projeto e de estudo; nao distribua publicamente com assets deles.
