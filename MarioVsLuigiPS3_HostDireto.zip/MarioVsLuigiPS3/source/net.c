/* Cliente de rede + servidor embutido no PS3: TCP direto + lockstep de entradas. */
#include "net.h"
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#ifdef __PPU__
#include <net/net.h>
#include <net/netctl.h>
#else
#include <fcntl.h>
#include <poll.h>
#endif

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

static void put32(uint8_t *b, uint32_t v) { b[0] = v >> 24; b[1] = v >> 16; b[2] = v >> 8; b[3] = v; }
static uint32_t get32(const uint8_t *b) { return ((uint32_t) b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]; }

static void set_nonblocking(int s) {
#ifdef __PPU__
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_NBIO, &one, sizeof(one));
#else
    fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
#endif
}

void net_init(Net *n) {
    memset(n, 0, sizeof(*n));
    n->sock = -1;
    n->server.listen_sock = -1;
    for (int i = 0; i < MAX_PLAYERS; i++) n->server.slots[i].sock = -1;
#ifdef __PPU__
    static bool inited = false;
    if (!inited) { netInitialize(); inited = true; }
#endif
}

static void fail(Net *n, int err) {
    if (!n->error) n->error = err;
    if (n->sock >= 0) { close(n->sock); n->sock = -1; }
    n->connected = false;
}

bool net_connect(Net *n, const char *ip, int port) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { n->error = NET_ERR_CONNECT; return false; }
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons((uint16_t) port);
    a.sin_addr.s_addr = inet_addr(ip);
    if (a.sin_addr.s_addr == (in_addr_t) -1) { close(s); n->error = NET_ERR_CONNECT; return false; }
#ifdef __PPU__
    if (connect(s, (struct sockaddr *) &a, sizeof(a)) != 0) { close(s); n->error = NET_ERR_CONNECT; return false; }
#else
    set_nonblocking(s);                      /* connect com timeout de 3 s */
    int r = connect(s, (struct sockaddr *) &a, sizeof(a));
    if (r != 0) {
        if (errno != EINPROGRESS) { close(s); n->error = NET_ERR_CONNECT; return false; }
        struct pollfd p = { s, POLLOUT, 0 };
        int err = 0; socklen_t el = sizeof(err);
        if (poll(&p, 1, 3000) <= 0 || getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &el) != 0 || err != 0) {
            close(s); n->error = NET_ERR_CONNECT; return false;
        }
    }
#endif
    set_nonblocking(s);
    n->sock = s;
    n->connected = true;
    n->error = 0;
    return true;
}

void net_close(Net *n) {
    if (n->sock >= 0) { close(n->sock); n->sock = -1; }
    n->connected = false;
    host_server_stop(&n->server);
}

bool net_get_local_ipv4(uint32_t *out_ip_host) {
#ifdef __PPU__
    netCtlInit();
    union net_ctl_info info;
    if (netCtlGetInfo(NET_CTL_INFO_IP_ADDRESS, &info) == 0) {
        return ipv4_parse(info.ip_address, out_ip_host);
    }
    return false;
#else
    *out_ip_host = 0x7F000001u; /* 127.0.0.1 no PC */
    return true;
#endif
}

bool net_host_room(Net *n, uint32_t advertised_ip_host, int port, const char *name) {
    net_close(n);
    net_init(n);

    char code[ROOM_CODE_LEN + 1];
    room_code_encode(advertised_ip_host, code);

    if (!host_server_start(&n->server, port, code)) {
        n->error = NET_ERR_CONNECT;
        return false;
    }
    if (!net_connect(n, "127.0.0.1", port)) {
        host_server_stop(&n->server);
        return false;
    }
    if (!net_create_room(n, name)) {
        net_close(n);
        return false;
    }
    usleep(1000);
    host_server_poll(&n->server);
    net_poll(n);
    return true;
}

bool net_join_by_code(Net *n, const char *code, int port, const char *name) {
    net_close(n);
    net_init(n);

    uint32_t ip_host = 0;
    if (!room_code_decode(code, &ip_host)) {
        n->error = ERR_BAD_CODE;
        return false;
    }
    char ip_str[16];
    ipv4_format(ip_host, ip_str);
    if (!net_connect(n, ip_str, port)) return false;
    return net_join_room(n, code, name);
}

static bool send_msg(Net *n, uint8_t type, const uint8_t *payload, uint8_t len) {
    if (n->sock < 0) return false;
    uint8_t buf[2 + 255];
    buf[0] = type; buf[1] = len;
    if (len) memcpy(buf + 2, payload, len);
    int total = 2 + len, sent = 0, tries = 0;
    while (sent < total) {
        int r = (int) send(n->sock, buf + sent, total - sent, MSG_NOSIGNAL);
        if (r > 0) { sent += r; continue; }
        if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) && tries++ < 2000) { usleep(1000); continue; }
        fail(n, NET_ERR_DISCONNECTED);
        return false;
    }
    return true;
}

static void pad_name(uint8_t *dst, const char *name) {
    memset(dst, 0, NAME_LEN);
    for (int i = 0; i < NAME_LEN && name[i]; i++) dst[i] = (uint8_t) name[i];
}

bool net_create_room(Net *n, const char *name) {
    uint8_t p[NAME_LEN]; pad_name(p, name);
    return send_msg(n, C_CREATE, p, NAME_LEN);
}

bool net_join_room(Net *n, const char *code, const char *name) {
    uint8_t p[ROOM_CODE_LEN + NAME_LEN];
    memcpy(p, code, ROOM_CODE_LEN);
    pad_name(p + ROOM_CODE_LEN, name);
    return send_msg(n, C_JOIN, p, sizeof(p));
}

void net_set_ready(Net *n, bool ready) { uint8_t b = ready ? 1 : 0; send_msg(n, C_READY, &b, 1); }
void net_start_game(Net *n)            { send_msg(n, C_START, NULL, 0); }

void net_leave_room(Net *n) {
    send_msg(n, C_LEAVE, NULL, 0);
    if (n->server.running) {
        usleep(1000);
        host_server_poll(&n->server);
        host_server_stop(&n->server);
    }
    n->in_room = n->is_host = n->started = false;
    n->peer_left = 0;
}

void net_send_input(Net *n, uint8_t buttons) {
    if (!n->started || n->sock < 0) return;
    if (n->send_frame - n->sim_frame >= NET_INPUT_DELAY + 10) return;
    uint8_t p[5];
    put32(p, n->send_frame++);
    p[4] = buttons;
    send_msg(n, C_INPUT, p, 5);
}

static void start_lockstep(Net *n, int nplayers) {
    n->nplayers = nplayers;
    n->started = true;
    n->sim_frame = n->send_frame = 0;
    memset(n->ring_valid, 0, sizeof(n->ring_valid));
    memset(n->prev_jump, 0, sizeof(n->prev_jump));
    for (int i = 0; i < NET_INPUT_DELAY; i++) {
        uint8_t p[5];
        put32(p, n->send_frame++);
        p[4] = 0;
        send_msg(n, C_INPUT, p, 5);
    }
}

static void handle_msg(Net *n, uint8_t t, const uint8_t *p, int len) {
    switch (t) {
    case S_CREATED: case S_JOINED:
        if (len < ROOM_CODE_LEN + 1) break;
        memcpy(n->code, p, ROOM_CODE_LEN); n->code[ROOM_CODE_LEN] = '\0';
        n->slot = p[ROOM_CODE_LEN];
        n->in_room = true;
        n->is_host = (t == S_CREATED);
        break;
    case S_ERROR:
        if (len >= 1) n->error = p[0];
        break;
    case S_LOBBY:
        if (len < (2 + NAME_LEN) * MAX_PLAYERS) break;
        for (int i = 0; i < MAX_PLAYERS; i++) {
            const uint8_t *q = p + i * (2 + NAME_LEN);
            n->present[i] = q[0]; n->ready[i] = q[1];
            memcpy(n->names[i], q + 2, NAME_LEN); n->names[i][NAME_LEN] = '\0';
        }
        break;
    case S_START:
        if (len >= 1) start_lockstep(n, p[0]);
        break;
    case S_FRAME: {
        if (len < 5) break;
        uint32_t frame = get32(p);
        int cnt = p[4];
        if (len < 5 + cnt || cnt > MAX_PLAYERS) break;
        int idx = frame % NET_RING;
        n->ring_frame[idx] = frame;
        n->ring_valid[idx] = true;
        memset(n->ring[idx], 0, MAX_PLAYERS);
        memcpy(n->ring[idx], p + 5, cnt);
        break; }
    case S_PEERLEFT:
        n->started = false;
        n->peer_left = (len >= 1 && p[0] == 1) ? 2 : 1;
        if (n->peer_left == 2) n->in_room = false;
        break;
    }
}

void net_poll(Net *n) {
    if (n->server.running) host_server_poll(&n->server);
    if (n->sock < 0) return;
    for (;;) {
        if (n->rxlen >= (int) sizeof(n->rx)) { fail(n, NET_ERR_DISCONNECTED); return; }
        int r = (int) recv(n->sock, n->rx + n->rxlen, sizeof(n->rx) - n->rxlen, 0);
        if (r > 0) { n->rxlen += r; continue; }
        if (r == 0) { fail(n, NET_ERR_DISCONNECTED); break; }
        if (errno == EAGAIN || errno == EWOULDBLOCK) break;
        fail(n, NET_ERR_DISCONNECTED);
        break;
    }
    int off = 0;
    while (n->rxlen - off >= 2) {
        int len = n->rx[off + 1];
        if (n->rxlen - off < 2 + len) break;
        handle_msg(n, n->rx[off], n->rx + off + 2, len);
        off += 2 + len;
    }
    if (off) { memmove(n->rx, n->rx + off, n->rxlen - off); n->rxlen -= off; }
}

uint8_t input_to_buttons(const Input *in) {
    return (in->left ? BTN_L : 0) | (in->right ? BTN_R : 0) | (in->down ? BTN_D : 0)
         | (in->jump_down ? BTN_J : 0) | (in->sprint_down ? BTN_S : 0);
}

bool net_next_frame(Net *n, Input out[MAX_PLAYERS]) {
    if (!n->started) return false;
    int idx = n->sim_frame % NET_RING;
    if (!n->ring_valid[idx] || n->ring_frame[idx] != n->sim_frame) return false;
    for (int i = 0; i < MAX_PLAYERS; i++) {
        uint8_t b = n->ring[idx][i];
        out[i] = (Input) {
            .left = b & BTN_L, .right = b & BTN_R, .down = b & BTN_D,
            .jump_down = b & BTN_J, .sprint_down = b & BTN_S,
            .jump_pressed = (b & BTN_J) && !n->prev_jump[i],
        };
        n->prev_jump[i] = (b & BTN_J) ? 1 : 0;
    }
    n->ring_valid[idx] = false;
    n->sim_frame++;
    return true;
}

const char *net_error_text(int err) {
    switch (err) {
    case ERR_NO_ROOM:   return "SALA NAO ENCONTRADA";
    case ERR_FULL:      return "SALA CHEIA";
    case ERR_STARTED:   return "PARTIDA JA COMECOU";
    case ERR_NOT_READY: return "NEM TODOS ESTAO PRONTOS";
    case ERR_BAD:       return "PEDIDO INVALIDO";
    case ERR_BAD_CODE:  return "CODIGO INVALIDO";
    case NET_ERR_DISCONNECTED: return "CONEXAO PERDIDA";
    case NET_ERR_CONNECT:      return "NAO CONECTOU AO ANFITRIAO";
    default: return "ERRO";
    }
}
