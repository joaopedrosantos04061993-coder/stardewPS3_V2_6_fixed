#include "room_code.h"
#include <stdio.h>
#include <string.h>

static int alpha_index(char ch) {
    if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 32);
    const char *p = strchr(CODE_ALPHABET, ch);
    return p ? (int)(p - CODE_ALPHABET) : -1;
}

/* Digito verificador de 3 bits (0..7) sensivel a troca de 1 caractere ou transposicao */
static uint8_t calc_check3(uint32_t ip) {
    uint32_t h = ip ^ 0xA5C35A3Cu;
    h ^= (h >> 16);
    h *= 0x45D9F3Bu;
    h ^= (h >> 16);
    uint32_t sum = ((h >> 0) & 7u) ^ ((h >> 3) & 7u) ^ ((h >> 7) & 7u) ^
                   ((h >> 12) & 7u) ^ ((h >> 19) & 7u) ^ ((h >> 25) & 7u);
    return (uint8_t)(sum & 0x07u);
}

void room_code_encode(uint32_t ipv4_host, char out[ROOM_CODE_LEN + 1]) {
    uint64_t packed = ((uint64_t)ipv4_host << 3) | (uint64_t)calc_check3(ipv4_host);
    for (int i = ROOM_CODE_LEN - 1; i >= 0; i--) {
        out[i] = CODE_ALPHABET[packed & 0x1Fu];
        packed >>= 5;
    }
    out[ROOM_CODE_LEN] = '\0';
}

bool room_code_decode(const char *code, uint32_t *out_ipv4_host) {
    if (!code) return false;
    uint64_t packed = 0;
    for (int i = 0; i < ROOM_CODE_LEN; i++) {
        if (!code[i]) return false;
        int idx = alpha_index(code[i]);
        if (idx < 0) return false;
        packed = (packed << 5) | (uint64_t)idx;
    }
    if (code[ROOM_CODE_LEN] != '\0') return false;

    uint8_t chk = (uint8_t)(packed & 0x07u);
    uint32_t ip = (uint32_t)(packed >> 3);
    if (chk != calc_check3(ip)) return false;

    if (out_ipv4_host) *out_ipv4_host = ip;
    return true;
}

bool ipv4_parse(const char *str, uint32_t *out_host) {
    unsigned int a, b, c, d;
    if (!str || sscanf(str, "%u.%u.%u.%u", &a, &b, &c, &d) != 4) return false;
    if (a > 255 || b > 255 || c > 255 || d > 255) return false;
    *out_host = (a << 24) | (b << 16) | (c << 8) | d;
    return true;
}

void ipv4_format(uint32_t ip_host, char out[16]) {
    snprintf(out, 16, "%u.%u.%u.%u",
             (ip_host >> 24) & 0xFFu,
             (ip_host >> 16) & 0xFFu,
             (ip_host >> 8)  & 0xFFu,
             ip_host & 0xFFu);
}
