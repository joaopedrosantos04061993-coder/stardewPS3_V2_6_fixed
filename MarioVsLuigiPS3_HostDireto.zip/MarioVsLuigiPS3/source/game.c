/* Nucleo do jogo: independente de plataforma (compila no PS3 e no PC).
 * A logica de movimento segue MarioPlayerSystem.cs do NSMB-MarioVsLuigi:
 * HandleWalkingRunning -> HandleJumping -> HandleGravity -> terminal velocity.
 * Diferencas conhecidas estao em PORT_STATUS.md. */
#include "game.h"
#include "physics_info.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#define EPS 1e-4f

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int   signi(float v) { return v > 0 ? 1 : (v < 0 ? -1 : 0); }

/* ---------------- Fase ---------------- */

const char *level_default_text(void) {
    return
        "............................\n"
        "............................\n"
        "............................\n"
        "............................\n"
        "............................\n"
        ".....#####........#####.....\n"
        "............................\n"
        "............................\n"
        "..##..................##....\n"
        "............................\n"
        ".......#####....#####.......\n"
        "............................\n"
        ".1........................2.\n"
        "############################\n";
}

bool level_load_from_string(Level *lv, const char *text) {
    memset(lv, 0, sizeof(*lv));
    int row = 0, col = 0;
    for (const char *c = text; *c && row < LEVEL_H; c++) {
        if (*c == '\r') continue;
        if (*c == '\n') {
            if (col != LEVEL_W) return false;   /* linha com tamanho errado */
            lv->tiles[row][col] = '\0';
            row++; col = 0;
            continue;
        }
        if (col >= LEVEL_W) return false;
        char t = *c;
        int ty = LEVEL_H - 1 - row;             /* y para cima */
        if ((t == '1' || t == '2') && lv->nspawn < MAX_PLAYERS) {
            int idx = t - '1';
            lv->spawn_x[idx] = col + 0.5f;
            lv->spawn_y[idx] = (float) ty;
            lv->nspawn++;
            t = '.';
        }
        lv->tiles[row][col++] = t;
    }
    return row == LEVEL_H;
}

bool level_load(Level *lv, const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    static char buf[(LEVEL_W + 2) * LEVEL_H + 16];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[n] = '\0';
    return level_load_from_string(lv, buf);
}

bool level_solid(const Level *lv, int tx, int ty) {
    if (ty < 0 || ty >= LEVEL_H) return false;   /* acima/abaixo do mapa: vazio */
    tx %= LEVEL_W; if (tx < 0) tx += LEVEL_W;     /* mapa dá a volta nas laterais */
    return lv->tiles[LEVEL_H - 1 - ty][tx] == '#';
}

static bool box_hits(const Level *lv, float x, float y, float w, float h) {
    int tx0 = (int) floorf(x - w * 0.5f), tx1 = (int) floorf(x + w * 0.5f - EPS);
    int ty0 = (int) floorf(y + EPS),      ty1 = (int) floorf(y + h - EPS);
    for (int ty = ty0; ty <= ty1; ty++)
        for (int tx = tx0; tx <= tx1; tx++)
            if (level_solid(lv, tx, ty)) return true;
    return false;
}

/* ---------------- Jogador ---------------- */

static void player_spawn(Player *p) {
    p->x = p->spawn_x; p->y = p->spawn_y;
    p->vx = p->vy = 0;
    p->w = HITBOX_W; p->h = HITBOX_H_SMALL;
    p->on_ground = p->was_on_ground = false;
    p->facing_right = true;
    p->skidding = p->turnaround = p->crouching = false;
    p->wslide_left = p->wslide_right = p->touch_left = p->touch_right = false;
    p->wslide_end = p->walljump_frames = 0;
    p->slow_turn_frames = p->fast_turn_frames = 0;
    p->jump_buffer = p->coyote = 0;
    p->jump_state = p->prev_jump_state = JUMP_NONE;
    p->alive = true;
}

static int speed_stage(float vx) {
    float a = fabsf(vx) - 0.01f;
    for (int i = 0; i < 5; i++) if (a <= WALK_MAX_VEL[i]) return i;
    return 4;
}

static int gravity_stage(float vy) {
    for (int i = 0; i < 4; i++) if (vy >= GRAV_VEL[i]) return i;
    return 4;
}

/* HandleWalkingRunning */
static void handle_walking(Player *p, const Input *in) {
    if (p->walljump_frames > 0) {                    /* sem controle apos walljump */
        p->walljump_frames--;
        if (p->walljump_frames > 0) return;
    }
    float xVel = p->vx, xAbs = fabsf(xVel);
    int   sign = signi(xVel);
    int   maxStage = in->sprint_down ? RUN_SPEED_STAGE : WALK_SPEED_STAGE;
    int   stage = speed_stage(xVel);
    float acc = WALK_ACC[stage];

    if (!p->on_ground) p->fast_turn_frames = 0;

    if (p->fast_turn_frames > 0) {
        p->vx = 0;
        if (--p->fast_turn_frames == 0) p->turnaround = true;
    } else if (p->turnaround) {
        p->turnaround = p->on_ground && xAbs < WALK_MAX_VEL[1];
        p->skidding = p->turnaround;
        p->vx += FAST_TURN_ACC * (p->facing_right ? -1 : 1) * SIM_DT;
    } else if ((in->left != in->right) && (!p->crouching || !p->on_ground)) {
        int dir = in->left ? -1 : 1;
        if (p->skidding) dir = -sign;
        bool reverse = (xVel != 0.0f) && (dir != sign);

        float max = WALK_MAX_VEL[maxStage];
        float maxAcc = fabsf(max - xAbs) * SIM_HZ;
        acc = clampf(acc, -maxAcc, maxAcc);
        if (xAbs > max) acc = -acc;

        if (reverse) {
            p->turnaround = false;
            if (p->on_ground) {
                if (xAbs >= SKID_MIN_VEL) { p->skidding = true; p->facing_right = (sign == 1); }
                if (p->skidding) {
                    acc = (xAbs > WALK_MAX_VEL[RUN_SPEED_STAGE]) ? SKID_STAR_DECEL : SKID_DECEL;
                    p->slow_turn_frames = 0;
                } else {
                    if (p->slow_turn_frames < 3) p->slow_turn_frames++;
                    acc = SLOW_TURN_ACC[p->slow_turn_frames];
                }
            } else {
                acc = WALK_ACC[0] * AIR_REVERSE_FACTOR;
            }
        } else {
            p->slow_turn_frames = 0;
            p->skidding = p->skidding && !p->turnaround;
        }

        float newX = xVel + acc * SIM_DT * dir;
        if ((xVel < max && newX > max) || (xVel > -max && newX < -max))
            newX = clampf(newX, -max, max);

        if (p->skidding && !p->turnaround && (signi(newX) != sign || xAbs < 0.05f)) {
            p->fast_turn_frames = 10;
            newX = 0;
        }
        p->vx = newX;
    } else if (p->on_ground) {
        p->skidding = false;
        p->turnaround = false;
        float newX = xVel + (-WALK_RELEASE_DECEL) * SIM_DT * sign;
        if ((sign == -1) != (newX <= 0.0f)) newX = 0;
        p->vx = newX;
        if (newX != 0.0f) p->facing_right = newX > 0;
    }
}

/* HandleJumping */
static void handle_jumping(Game *g, Player *p, const Input *in) {
    if (in->jump_pressed) p->jump_buffer = JUMP_BUFFER_FRAMES;
    if (p->on_ground) p->coyote = COYOTE_FRAMES;

    if (!p->was_on_ground && p->on_ground) {
        p->landed_frame = g->frame;
        if (p->jump_state == JUMP_TRIPLE && !in->left && !in->right) p->vx = 0;
        if (p->prev_jump_state != JUMP_NONE && p->prev_jump_state == p->jump_state)
            p->jump_state = JUMP_NONE;
        p->prev_jump_state = p->jump_state;
    }

    bool doJump = p->jump_buffer > 0 && (p->on_ground || p->coyote > 0);
    if (p->coyote > 0) p->coyote--;
    if (p->jump_buffer > 0) p->jump_buffer--;
    if (!doJump || p->wslide_left || p->wslide_right) return;

    bool topSpeed = fabsf(p->vx) >= (WALK_MAX_VEL[RUN_SPEED_STAGE] - 0.10f);
    bool canSpecial = topSpeed && !in->down
        && p->jump_state != JUMP_NONE && p->jump_state != JUMP_TRIPLE
        && (g->frame - p->landed_frame < TRIPLE_WINDOW_FRAMES)
        && ((p->vx < 0) != p->facing_right);

    p->skidding = p->turnaround = false;
    p->jump_buffer = 0;
    p->coyote = 0;
    p->was_on_ground = false;
    p->on_ground = false;

    float alpha = clampf(fabsf(p->vx) - WALK_MAX_VEL[1] + WALK_MAX_VEL[1] * 0.5f, 0, 1);
    float newY = JUMP_VEL + JUMP_SPEED_BONUS * alpha;

    if (canSpecial && p->jump_state == JUMP_SINGLE)      p->jump_state = JUMP_DOUBLE;
    else if (canSpecial && p->jump_state == JUMP_DOUBLE) { p->jump_state = JUMP_TRIPLE; newY += JUMP_TRIPLE_BONUS; }
    else                                                  p->jump_state = JUMP_SINGLE;

    p->vy = newY;
}

/* HandleCrouching */
static void handle_crouching(Player *p, const Input *in) {
    if (p->crouching && p->was_on_ground && !p->on_ground && p->vy < 0.10f)
        p->vy = CROUCH_OFF_EDGE_VEL;
    if (p->wslide_left || p->wslide_right) { p->crouching = false; return; }
    p->crouching = (p->on_ground && in->down)
                || (!p->on_ground && (in->down || p->vy > 0) && p->crouching);
}

/* HandleWallslide (+ walljump) */
static void handle_wallslide(Player *p, const Input *in) {
    if (p->crouching) return;

    int wallDir;                                      /* -1 esquerda, +1 direita */
    if (p->wslide_left)       wallDir = -1;
    else if (p->wslide_right) wallDir = 1;
    else if (in->left != in->right) wallDir = in->left ? -1 : 1;
    else return;

    bool sliding = p->wslide_left || p->wslide_right;
    if (sliding) {                                    /* HandleWallslideStopChecks */
        if (p->on_ground || !(p->vy < 0)) {
            p->wslide_left = p->wslide_right = false; p->wslide_end = 0;
        } else {
            bool lost = (wallDir < 0 && (!in->left  || !p->touch_left))
                     || (wallDir > 0 && (!in->right || !p->touch_right));
            if (lost) { if (p->wslide_end == 0) { p->wslide_end = WALLSLIDE_END_FRAMES; p->x -= wallDir * 0.01f; } }
            else p->wslide_end = 0;
        }
    }

    if (p->wslide_end > 0 && --p->wslide_end == 0) {
        p->facing_right = p->wslide_right;
        p->wslide_left = p->wslide_right = false;
        return;
    }

    sliding = p->wslide_left || p->wslide_right;
    if (sliding) {
        p->vx = clampf(p->vx, -0.25f, 0.25f);
        p->facing_right = p->wslide_left;
        if (p->jump_buffer > 0 && p->walljump_frames == 0) {
            p->vx = WALLJUMP_H_VEL * (p->wslide_left ? 1 : -1);
            p->vy = WALLJUMP_V_VEL;
            p->jump_state = JUMP_SINGLE;
            p->on_ground = false;
            p->walljump_frames = WALLJUMP_FRAMES;
            p->wslide_left = p->wslide_right = false;
            p->wslide_end = 0;
            p->jump_buffer = 0;
        }
    } else if (p->touch_left || p->touch_right) {
        bool can = p->vy < -0.10f && !p->on_ground;
        if (!can) return;
        if (p->walljump_frames > 0 || p->wslide_end > 0) return;
        if (!((wallDir > 0 && p->facing_right) || (wallDir < 0 && !p->facing_right))) return;
        p->wslide_right = (wallDir > 0) && p->touch_right;
        p->wslide_left  = (wallDir < 0) && p->touch_left;
        p->wslide_end = 0;
    }
}

/* HandleFacingDirection (subconjunto) */
static void handle_facing(Player *p, const Input *in) {
    if (p->walljump_frames > 0) return;
    if (p->crouching && p->on_ground && fabsf(p->vx) > 0.05f) return;
    if (!p->skidding && !p->turnaround && (in->left != in->right))
        p->facing_right = in->right;
}

/* HandleGravity + HandleTerminalVelocity + integracao com colisao */
static void handle_physics(const Level *lv, Player *p, const Input *in) {
    float gravity;
    if (p->on_ground)        gravity = GRAV_ACC[0];
    else if (p->coyote > 0)  gravity = GRAV_ACC[4];
    else {
        int stage = gravity_stage(p->vy);
        gravity = GRAV_ACC[stage];
        if (stage == 0 && !in->jump_down) gravity = GRAV_ACC[4];
    }

    p->vy += gravity * SIM_DT;
    float term = (p->wslide_left || p->wslide_right) ? TERMINAL_VEL_WALLSLIDE : TERMINAL_VEL;
    if (p->vy < term) p->vy = term;

    p->was_on_ground = p->on_ground;

    /* Eixo X */
    float nx = p->x + p->vx * SIM_DT;
    if (box_hits(lv, nx, p->y, p->w, p->h)) {
        if (p->vx > 0) { int tx = (int) floorf(nx + p->w * 0.5f); nx = tx - p->w * 0.5f - EPS; }
        else           { int tx = (int) floorf(nx - p->w * 0.5f); nx = tx + 1 + p->w * 0.5f + EPS; }
        p->vx = 0;
    }
    p->x = nx;
    if (p->x < 0) p->x += LEVEL_W;
    if (p->x >= LEVEL_W) p->x -= LEVEL_W;

    /* Eixo Y */
    float ny = p->y + p->vy * SIM_DT;
    p->on_ground = false;
    if (box_hits(lv, p->x, ny, p->w, p->h)) {
        if (p->vy <= 0) { p->y = floorf(ny) + 1; p->on_ground = true; }
        else            { int ty = (int) floorf(ny + p->h); p->y = ty - p->h - EPS; }
        p->vy = 0;
    } else {
        p->y = ny;
    }

    /* contato com paredes (sondagem curta dos dois lados) */
    p->touch_right = box_hits(lv, p->x + 0.02f, p->y, p->w, p->h);
    p->touch_left  = box_hits(lv, p->x - 0.02f, p->y, p->w, p->h);
}

/* ---------------- Jogo ---------------- */

void game_init(Game *g, int nplayers) {
    g->nplayers = nplayers < 1 ? 1 : (nplayers > MAX_PLAYERS ? MAX_PLAYERS : nplayers);
    g->frame = 0;
    for (int i = 0; i < g->nplayers; i++) {
        Player *p = &g->players[i];
        memset(p, 0, sizeof(*p));
        p->spawn_x = g->level.nspawn > i ? g->level.spawn_x[i] : 2.5f + 4.0f * i;
        p->spawn_y = g->level.nspawn > i ? g->level.spawn_y[i] : 1.0f;
        player_spawn(p);
    }
}

static void check_stomp(Player *a, Player *b) {
    if (!a->alive || !b->alive) return;
    bool overlap = fabsf(a->x - b->x) < (a->w + b->w) * 0.5f
                && a->y < b->y + b->h && b->y < a->y + a->h;
    if (!overlap) return;
    if (a->vy < 0 && a->y > b->y + b->h * 0.5f) {   /* a caiu em cima de b */
        a->score++;
        a->vy = JUMP_VEL;
        a->on_ground = false;
        player_spawn(b);
    }
}

void game_step(Game *g, const Input in[MAX_PLAYERS]) {
    for (int i = 0; i < g->nplayers; i++) {
        Player *p = &g->players[i];
        handle_crouching(p, &in[i]);
        handle_walking(p, &in[i]);
        handle_jumping(g, p, &in[i]);
        handle_wallslide(p, &in[i]);
        handle_physics(&g->level, p, &in[i]);
        handle_facing(p, &in[i]);
        if (p->y < -2.0f) player_spawn(p);          /* caiu do mapa */
    }
    if (g->nplayers == 2) {
        check_stomp(&g->players[0], &g->players[1]);
        check_stomp(&g->players[1], &g->players[0]);
    }
    g->frame++;
}
