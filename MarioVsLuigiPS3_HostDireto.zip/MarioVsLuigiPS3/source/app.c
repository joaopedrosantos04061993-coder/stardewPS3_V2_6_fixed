/* Menu, lobby e fluxo de jogo. Independente de plataforma: recebe botoes (PadRaw) e desenha num Canvas. */
#include "app.h"
#include <stdio.h>
#include <string.h>

#ifdef __PPU__
#define CONFIG_PATH "/dev_hdd0/game/MVLP00001/USRDIR/server.txt"
#define LEVEL_PATH  "/dev_hdd0/game/MVLP00001/USRDIR/data/level1.txt"
#else
#define CONFIG_PATH "server.txt"
#define LEVEL_PATH  "data/level1.txt"
#endif

#define COL_BG     0x00101828
#define COL_TITLE  0x00FFD84C
#define COL_TEXT   0x00E8E8F0
#define COL_DIM    0x00808CA0
#define COL_SEL    0x00FFD84C
#define COL_OK     0x0060E070
#define COL_ERR    0x00FF6060

static const char *TITLE_ITEMS[] = { "JOGAR LOCAL", "CRIAR SALA ONLINE", "ENTRAR COM CODIGO", "IP DO ANFITRIAO", "SAIR" };
#define TITLE_COUNT 5

/* ---------- config do IP do anfitriao ---------- */

void app_server_string(const App *a, char *out, int n) {
    snprintf(out, n, "%d.%d.%d.%d:%d", a->octet[0], a->octet[1], a->octet[2], a->octet[3], a->port);
}

bool app_load_config(App *a, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return false;
    int o[4], port;
    int n = fscanf(f, "%d.%d.%d.%d:%d", &o[0], &o[1], &o[2], &o[3], &port);
    fclose(f);
    if (n != 5) return false;
    for (int i = 0; i < 4; i++) if (o[i] < 0 || o[i] > 255) return false;
    if (port < 1 || port > 65535) return false;
    for (int i = 0; i < 4; i++) a->octet[i] = o[i];
    a->port = port;
    return true;
}

bool app_save_config(const App *a, const char *path) {
    FILE *f = fopen(path, "w");
    if (!f) return false;
    char s[32]; app_server_string(a, s, sizeof(s));
    fprintf(f, "%s\n", s);
    fclose(f);
    return true;
}

/* ---------- helpers ---------- */

#define PRESSED(field) (pad->field && !prev->field)

static void set_msg(App *a, const char *m) { snprintf(a->msg, sizeof(a->msg), "%s", m); a->scr = SCR_MESSAGE; }

void app_init(App *a) {
    memset(a, 0, sizeof(*a));
    a->scr = SCR_TITLE;
    a->octet[0] = 127; a->octet[3] = 1; a->port = DEFAULT_GAME_PORT;

    uint32_t local_ip = 0;
    if (net_get_local_ipv4(&local_ip)) {
        a->octet[0] = (local_ip >> 24) & 0xFF;
        a->octet[1] = (local_ip >> 16) & 0xFF;
        a->octet[2] = (local_ip >> 8)  & 0xFF;
        a->octet[3] =  local_ip        & 0xFF;
    }
    app_load_config(a, CONFIG_PATH);
    memset(a->code, 'A', ROOM_CODE_LEN);
    a->code[ROOM_CODE_LEN] = '\0';
    net_init(&a->net);
}

static int repeat_dir(App *a, const PadRaw *pad, const PadRaw *prev) {
    int dir = pad->up ? 1 : (pad->down ? -1 : 0);
    if (!dir) { a->hold = 0; return 0; }
    bool edge = (pad->up && !prev->up) || (pad->down && !prev->down);
    if (edge) { a->hold = 0; return dir; }
    a->hold++;
    return (a->hold >= 20 && a->hold % 3 == 0) ? dir : 0;
}

static Input pad_to_input(const PadRaw *p) {
    Input in = {0};
    in.left = p->left; in.right = p->right; in.down = p->down;
    in.jump_down = p->cross || p->circle;
    in.sprint_down = p->square;
    return in;
}

static void start_local(App *a) {
    memset(&a->game, 0, sizeof(a->game));
    if (!level_load(&a->game.level, LEVEL_PATH)) level_load_from_string(&a->game.level, level_default_text());
    game_init(&a->game, 2);
    a->scr = SCR_LOCAL;
}

static void start_online_game(App *a) {
    memset(&a->game, 0, sizeof(a->game));
    level_load_from_string(&a->game.level, level_default_text());
    game_init(&a->game, 2);
    a->scr = SCR_ONLINE;
}

static void connect_and_enter(App *a, bool create) {
    if (create) {
        uint32_t ip = ((uint32_t)a->octet[0] << 24) | ((uint32_t)a->octet[1] << 16) |
                      ((uint32_t)a->octet[2] << 8)  |  (uint32_t)a->octet[3];
        if (!net_host_room(&a->net, ip, a->port, "PS3")) {
            set_msg(a, net_error_text(a->net.error));
            return;
        }
    } else {
        if (!net_join_by_code(&a->net, a->code, a->port, "PS3")) {
            set_msg(a, net_error_text(a->net.error));
            return;
        }
    }
    a->note[0] = '\0';
    a->scr = SCR_LOBBY;
}

static void leave_to_title(App *a) {
    net_leave_room(&a->net);
    net_close(&a->net);
    a->scr = SCR_TITLE;
}

/* ---------- logica por tela ---------- */

static void tick_title(App *a, const PadRaw *pad, const PadRaw *prev) {
    if (PRESSED(up))   a->sel = (a->sel + TITLE_COUNT - 1) % TITLE_COUNT;
    if (PRESSED(down)) a->sel = (a->sel + 1) % TITLE_COUNT;
    if (!PRESSED(cross)) return;
    switch (a->sel) {
    case 0: start_local(a); break;
    case 1: connect_and_enter(a, true); break;
    case 2: a->code_pos = 0; a->scr = SCR_CODE; break;
    case 3: a->cfg_field = 0; a->scr = SCR_SERVER; break;
    case 4: a->quit = true; break;
    }
}

static void tick_server(App *a, const PadRaw *pad, const PadRaw *prev) {
    if (PRESSED(left))  a->cfg_field = (a->cfg_field + 4) % 5;
    if (PRESSED(right)) a->cfg_field = (a->cfg_field + 1) % 5;
    int d = repeat_dir(a, pad, prev);
    if (d) {
        int step = pad->square ? 10 : 1;
        if (a->cfg_field < 4) {
            int v = a->octet[a->cfg_field] + d * step;
            a->octet[a->cfg_field] = v < 0 ? 0 : (v > 255 ? 255 : v);
        } else {
            int v = a->port + d * step * (pad->square ? 10 : 1);
            a->port = v < 1 ? 1 : (v > 65535 ? 65535 : v);
        }
    }
    if (PRESSED(cross) || PRESSED(circle)) { app_save_config(a, CONFIG_PATH); a->scr = SCR_TITLE; }
}

static void tick_code(App *a, const PadRaw *pad, const PadRaw *prev) {
    const char *alpha = CODE_ALPHABET;
    int alen = (int) strlen(alpha);
    if (PRESSED(left))  a->code_pos = (a->code_pos + ROOM_CODE_LEN - 1) % ROOM_CODE_LEN;
    if (PRESSED(right)) a->code_pos = (a->code_pos + 1) % ROOM_CODE_LEN;
    int d = repeat_dir(a, pad, prev);
    if (d) {
        const char *p = strchr(alpha, a->code[a->code_pos]);
        int idx = p ? (int) (p - alpha) : 0;
        a->code[a->code_pos] = alpha[(idx + d + alen) % alen];
    }
    if (PRESSED(circle)) { a->scr = SCR_TITLE; return; }
    if (PRESSED(cross)) {
        if (a->code_pos < ROOM_CODE_LEN - 1) a->code_pos++;
        else connect_and_enter(a, false);
    }
}

static void tick_lobby(App *a, const PadRaw *pad, const PadRaw *prev) {
    Net *n = &a->net;
    net_poll(n);
    if (n->error == ERR_NOT_READY) {
        n->error = 0;
        snprintf(a->note, sizeof(a->note), "%s", net_error_text(ERR_NOT_READY));
    }
    if (n->error) {
        int e = n->error;
        net_close(n);
        set_msg(a, net_error_text(e));
        n->error = 0;
        return;
    }
    if (n->peer_left == 2) { net_close(n); n->peer_left = 0; set_msg(a, "O ANFITRIAO SAIU"); return; }
    if (n->peer_left == 1) { n->peer_left = 0; snprintf(a->note, sizeof(a->note), "O OUTRO JOGADOR SAIU"); }
    if (n->started) { start_online_game(a); return; }
    if (PRESSED(circle)) { leave_to_title(a); return; }
    if (!n->in_room) return;
    if (PRESSED(cross) && !n->is_host) net_set_ready(n, !n->ready[n->slot]);
    if (PRESSED(start) && n->is_host) net_start_game(n);
}

static void tick_online(App *a, const PadRaw pads[2]) {
    Net *n = &a->net;
    net_poll(n);
    if (n->error) { int e = n->error; net_close(n); n->error = 0; set_msg(a, net_error_text(e)); return; }
    if (n->peer_left == 2) { net_close(n); n->peer_left = 0; set_msg(a, "O ANFITRIAO SAIU"); return; }
    if (n->peer_left == 1) {
        n->peer_left = 0;
        snprintf(a->note, sizeof(a->note), "O OUTRO JOGADOR SAIU");
        a->scr = SCR_LOBBY;
        return;
    }
    if (pads[0].start && !a->prev[0].start) { leave_to_title(a); return; }

    Input local = pad_to_input(&pads[0]);
    net_send_input(n, input_to_buttons(&local));
    Input in[MAX_PLAYERS];
    for (int k = 0; k < 2 && net_next_frame(n, in); k++) game_step(&a->game, in);
}

static void tick_local(App *a, const PadRaw pads[2]) {
    if (pads[0].start && !a->prev[0].start) { a->scr = SCR_TITLE; return; }
    Input in[MAX_PLAYERS];
    for (int i = 0; i < MAX_PLAYERS; i++) {
        in[i] = pad_to_input(&pads[i]);
        in[i].jump_pressed = in[i].jump_down && !(a->prev[i].cross || a->prev[i].circle);
    }
    game_step(&a->game, in);
}

void app_tick(App *a, const PadRaw pads[2]) {
    const PadRaw *pad = &pads[0], *prev = &a->prev[0];
    a->tick++;
    switch (a->scr) {
    case SCR_TITLE:   tick_title(a, pad, prev); break;
    case SCR_SERVER:  tick_server(a, pad, prev); break;
    case SCR_CODE:    tick_code(a, pad, prev); break;
    case SCR_LOBBY:   tick_lobby(a, pad, prev); break;
    case SCR_LOCAL:   tick_local(a, pads); break;
    case SCR_ONLINE:  tick_online(a, pads); break;
    case SCR_MESSAGE: if (PRESSED(cross) || PRESSED(circle)) a->scr = SCR_TITLE; break;
    }
    a->prev[0] = pads[0];
    a->prev[1] = pads[1];
}

/* ---------- desenho ---------- */

static int unit(const Canvas *c) { int u = c->h / 180; return u < 1 ? 1 : u; }

static void draw_title(App *a, Canvas *c, int u) {
    draw_text_center(c, 12 * u, 2 * u, COL_TITLE, "MARIO VS LUIGI");
    draw_text_center(c, 32 * u, u, COL_DIM, "VERSAO PS3 - HOST DIRETO");
    for (int i = 0; i < TITLE_COUNT; i++) {
        const char *line = TITLE_ITEMS[i];
        bool sel = (i == a->sel);
        int y = 52 * u + i * 20 * u;
        draw_text_center(c, y, 2 * u, sel ? COL_SEL : COL_TEXT, line);
        if (sel) {
            int w = text_width(line, 2 * u);
            draw_text(c, (c->w - w) / 2 - 14 * u, y, 2 * u, COL_SEL, ">");
        }
    }
    char s[32], line[64];
    app_server_string(a, s, sizeof(s));
    snprintf(line, sizeof(line), "IP DO HOST: %s", s);
    draw_text_center(c, 152 * u, u, COL_DIM, line);
    draw_text_center(c, 164 * u, u, COL_DIM, "CIMA/BAIXO: ESCOLHER   X: CONFIRMAR");
}

static void draw_server(App *a, Canvas *c, int u) {
    draw_text_center(c, 14 * u, 2 * u, COL_TITLE, "IP DO ANFITRIAO");
    draw_text_center(c, 40 * u, u, COL_DIM, "CODIFICADO NO CODIGO DA SALA");
    int scale = 2 * u;
    char f[5][8];
    for (int i = 0; i < 4; i++) snprintf(f[i], sizeof(f[i]), "%d", a->octet[i]);
    snprintf(f[4], sizeof(f[4]), "%d", a->port);
    int total = 0;
    for (int i = 0; i < 5; i++) total += text_width(f[i], scale) + (i < 4 ? 8 * u : 0);
    total += 3 * 8 * u + 8 * u;
    int x = (c->w - total) / 2, y = 80 * u;
    for (int i = 0; i < 5; i++) {
        uint32_t col = (i == a->cfg_field) ? COL_SEL : COL_TEXT;
        draw_text(c, x, y, scale, col, f[i]);
        int w = text_width(f[i], scale);
        if (i == a->cfg_field) canvas_rect(c, x, y + 16 * u, w, u, COL_SEL);
        x += w;
        if (i < 3)      { draw_text(c, x + 2 * u, y, scale, COL_DIM, "."); x += 8 * u + 4 * u; }
        else if (i == 3) { draw_text(c, x + 2 * u, y, scale, COL_DIM, ":"); x += 8 * u + 4 * u; }
    }
    draw_text_center(c, 130 * u, u, COL_DIM, "ESQ/DIR: CAMPO   CIMA/BAIXO: VALOR");
    draw_text_center(c, 142 * u, u, COL_DIM, "SEGURE QUADRADO: PASSOS DE 10");
    draw_text_center(c, 160 * u, u, COL_DIM, "X OU O: SALVAR E VOLTAR");
}

static void draw_code(App *a, Canvas *c, int u) {
    draw_text_center(c, 14 * u, 2 * u, COL_TITLE, "ENTRAR NA SALA");
    draw_text_center(c, 40 * u, u, COL_DIM, "DIGITE O CODIGO DE 7 CARACTERES");
    int scale = 3 * u, cw = 7 * scale;
    int x = (c->w - cw * ROOM_CODE_LEN) / 2, y = 72 * u;
    for (int i = 0; i < ROOM_CODE_LEN; i++) {
        char ch[2] = { a->code[i], 0 };
        bool sel = (i == a->code_pos);
        canvas_rect(c, x + i * cw, y - 4 * u, cw - 2 * u, 7 * scale + 8 * u, sel ? 0x00283858 : 0x00182038);
        draw_text(c, x + i * cw + (cw - 2 * u - text_width(ch, scale)) / 2, y, scale, sel ? COL_SEL : COL_TEXT, ch);
        if (sel) {
            draw_text(c, x + i * cw + (cw - 2 * u - 5 * u) / 2, y - 14 * u, u, COL_SEL, "+");
        }
    }
    draw_text_center(c, 140 * u, u, COL_DIM, "CIMA/BAIXO: LETRA   ESQ/DIR: POSICAO");
    draw_text_center(c, 152 * u, u, COL_DIM, "X: PROXIMO / ENTRAR   O: VOLTAR");
}

static void draw_lobby(App *a, Canvas *c, int u) {
    const Net *n = &a->net;
    draw_text_center(c, 10 * u, 2 * u, COL_TITLE, "SALA");
    if (!n->in_room) {
        draw_text_center(c, 80 * u, 2 * u, COL_TEXT, "CONECTANDO...");
        draw_text_center(c, 160 * u, u, COL_DIM, "O: CANCELAR");
        return;
    }
    char code[ROOM_CODE_LEN * 2 + 1];
    int len = 0;
    for (int i = 0; i < ROOM_CODE_LEN; i++) { code[len++] = n->code[i]; if (i < ROOM_CODE_LEN - 1) code[len++] = ' '; }
    code[len] = '\0';
    draw_text_center(c, 34 * u, 3 * u, COL_OK, code);
    draw_text_center(c, 68 * u, u, COL_DIM, n->is_host ? "PASSE ESTE CODIGO PARA O OUTRO JOGADOR" : "VOCE ENTROU NA SALA");
    for (int i = 0; i < MAX_PLAYERS; i++) {
        char line[64];
        const char *tag = "";
        uint32_t col = COL_DIM;
        if (n->present[i]) {
            col = COL_TEXT;
            snprintf(line, sizeof(line), "JOGADOR %d  %s%s%s", i + 1, n->names[i],
                     i == 0 ? "  (ANFITRIAO)" : "", i == n->slot ? "  (VOCE)" : "");
            tag = n->ready[i] ? "PRONTO" : "AGUARDANDO";
        } else {
            snprintf(line, sizeof(line), "JOGADOR %d  VAZIO", i + 1);
        }
        int y = 84 * u + i * 18 * u;
        canvas_rect(c, c->w / 2 - 150 * u, y - 3 * u, 300 * u, 14 * u, 0x00182038);
        draw_text(c, c->w / 2 - 146 * u, y, u, col, line);
        if (*tag) draw_text(c, c->w / 2 + 146 * u - text_width(tag, u), y, u, n->ready[i] ? COL_OK : COL_SEL, tag);
    }
    if (a->note[0]) draw_text_center(c, 126 * u, u, COL_ERR, a->note);
    draw_text_center(c, 144 * u, u, COL_DIM, n->is_host ? "START: INICIAR (TODOS PRONTOS)   O: SAIR"
                                                         : "X: PRONTO / NAO PRONTO   O: SAIR");
}

static void draw_message(App *a, Canvas *c, int u) {
    draw_text_center(c, 70 * u, 2 * u, COL_ERR, a->msg);
    draw_text_center(c, 160 * u, u, COL_DIM, "X: VOLTAR AO MENU");
}

void app_draw(App *a, Canvas *c) {
    int u = unit(c);
    if (a->scr == SCR_LOCAL || a->scr == SCR_ONLINE) {
        draw_game(c, &a->game);
        if (a->scr == SCR_ONLINE) {
            char s[48];
            snprintf(s, sizeof(s), "SALA %s  VOCE: P%d", a->net.code, a->net.slot + 1);
            draw_text(c, c->w - text_width(s, u) - 6 * u, 4 * u, u, 0x00FFFFFF, s);
        }
        return;
    }
    canvas_rect(c, 0, 0, c->w, c->h, COL_BG);
    switch (a->scr) {
    case SCR_TITLE:   draw_title(a, c, u); break;
    case SCR_SERVER:  draw_server(a, c, u); break;
    case SCR_CODE:    draw_code(a, c, u); break;
    case SCR_LOBBY:   draw_lobby(a, c, u); break;
    case SCR_MESSAGE: draw_message(a, c, u); break;
    default: break;
    }
}
