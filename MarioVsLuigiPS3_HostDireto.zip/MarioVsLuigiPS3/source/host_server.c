/* Servidor embutido no PS3 do anfitriao (porta do relay_server.py para C nao-bloqueante). */
#include "host_server.h"
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#ifdef __PPU__
#include <net/net.h>
#else
#include <fcntl.h>
#endif

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

static void hs_set_nonblock(int s) {
#ifdef __PPU__
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_NBIO, &one, sizeof(one));
#else
    fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
#endif
}

static void hs_put32(uint8_t *b, uint32_t v) {
    b[0] = v >> 24; b[1] = v >> 16; b[2] = v >> 8; b[3] = v;
}

static uint32_t hs_get32(const uint8_t *b) {
    return ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) | ((uint32_t)b[2] << 8) | b[3];
}

static void slot_send(HostSlot *sl, uint8_t type, const uint8_t *payload, uint8_t len) {
    if (!sl->active || sl->sock < 0) return;
    uint8_t buf[2 + 255];
    buf[0] = type;
    buf[1] = len;
    if (len) memcpy(buf + 2, payload, len);
    int total = 2 + len, sent = 0, tries = 0;
    while (sent < total) {
        int r = (int)send(sl->sock, buf + sent, total - sent, MSG_NOSIGNAL);
        if (r > 0) { sent += r; continue; }
        if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) && tries++ < 1000) { usleep(500); continue; }
        break;
    }
}

static void broadcast(HostServer *hs, uint8_t type, const uint8_t *payload, uint8_t len) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (hs->slots[i].active) slot_send(&hs->slots[i], type, payload, len);
    }
}

static void broadcast_lobby(HostServer *hs) {
    uint8_t payload[MAX_PLAYERS * (2 + NAME_LEN)];
    memset(payload, 0, sizeof(payload));
    for (int i = 0; i < MAX_PLAYERS; i++) {
        uint8_t *p = payload + i * (2 + NAME_LEN);
        p[0] = hs->slots[i].active ? 1 : 0;
        p[1] = (hs->slots[i].active && hs->slots[i].ready) ? 1 : 0;
        if (hs->slots[i].active) memcpy(p + 2, hs->slots[i].name, NAME_LEN);
    }
    broadcast(hs, S_LOBBY, payload, sizeof(payload));
}

static void clean_name(char dst[NAME_LEN + 1], const uint8_t *raw) {
    memset(dst, 0, NAME_LEN + 1);
    int j = 0;
    for (int i = 0; i < NAME_LEN && raw[i]; i++) {
        uint8_t c = raw[i];
        dst[j++] = (c >= 32 && c < 127) ? (char)c : '?';
    }
    if (j == 0) strcpy(dst, "JOGADOR");
}

static void drop_slot(HostServer *hs, int idx) {
    HostSlot *sl = &hs->slots[idx];
    if (!sl->active) return;
    if (sl->sock >= 0) close(sl->sock);
    memset(sl, 0, sizeof(*sl));
    sl->sock = -1;

    if (idx == 0) {
        uint8_t reason = 1;
        broadcast(hs, S_PEERLEFT, &reason, 1);
        host_server_stop(hs);
        return;
    }
    if (hs->started) {
        hs->started = false;
        memset(hs->frame_mask, 0, sizeof(hs->frame_mask));
        if (hs->slots[0].active) hs->slots[0].ready = true;
    }
    uint8_t reason = 0;
    broadcast(hs, S_PEERLEFT, &reason, 1);
    broadcast_lobby(hs);
}

static void handle_slot_msg(HostServer *hs, int idx, uint8_t type, const uint8_t *p, int len) {
    HostSlot *sl = &hs->slots[idx];
    if (type == C_CREATE && idx == 0) {
        if (len >= NAME_LEN) clean_name(sl->name, p);
        sl->ready = true;
        uint8_t out[ROOM_CODE_LEN + 1];
        memcpy(out, hs->code, ROOM_CODE_LEN);
        out[ROOM_CODE_LEN] = 0;
        slot_send(sl, S_CREATED, out, sizeof(out));
        broadcast_lobby(hs);
    } else if (type == C_JOIN && idx > 0) {
        if (len < ROOM_CODE_LEN + NAME_LEN) {
            uint8_t err = ERR_BAD;
            slot_send(sl, S_ERROR, &err, 1);
            drop_slot(hs, idx);
            return;
        }
        char rx_code[ROOM_CODE_LEN + 1];
        for (int i = 0; i < ROOM_CODE_LEN; i++) {
            char c = (char)p[i];
            rx_code[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
        }
        rx_code[ROOM_CODE_LEN] = '\0';
        if (strcmp(rx_code, hs->code) != 0) {
            uint8_t err = ERR_NO_ROOM;
            slot_send(sl, S_ERROR, &err, 1);
            drop_slot(hs, idx);
            return;
        }
        clean_name(sl->name, p + ROOM_CODE_LEN);
        sl->ready = false;
        uint8_t out[ROOM_CODE_LEN + 1];
        memcpy(out, hs->code, ROOM_CODE_LEN);
        out[ROOM_CODE_LEN] = (uint8_t)idx;
        slot_send(sl, S_JOINED, out, sizeof(out));
        broadcast_lobby(hs);
    } else if (type == C_READY && !hs->started && idx != 0) {
        sl->ready = (len >= 1 && p[0] != 0);
        broadcast_lobby(hs);
    } else if (type == C_START && idx == 0 && !hs->started) {
        int count = 0;
        bool all_ready = true;
        for (int i = 0; i < MAX_PLAYERS; i++) {
            if (hs->slots[i].active) {
                count++;
                if (!hs->slots[i].ready) all_ready = false;
            }
        }
        if (count < MAX_PLAYERS || !all_ready) {
            uint8_t err = ERR_NOT_READY;
            slot_send(sl, S_ERROR, &err, 1);
            return;
        }
        hs->started = true;
        memset(hs->frame_mask, 0, sizeof(hs->frame_mask));
        uint8_t np = MAX_PLAYERS;
        broadcast(hs, S_START, &np, 1);
    } else if (type == C_INPUT && hs->started && len >= 5) {
        uint32_t frame = hs_get32(p);
        uint8_t btns = p[4];
        int widx = (int)(frame % HOST_FRAME_WINDOW);
        if (hs->frame_mask[widx] != 0 && hs->frame_num[widx] != frame) {
            hs->frame_mask[widx] = 0;
        }
        hs->frame_num[widx] = frame;
        hs->frame_btns[widx][idx] = btns;
        hs->frame_mask[widx] |= (uint8_t)(1u << idx);

        uint8_t full_mask = (uint8_t)((1u << MAX_PLAYERS) - 1u);
        if (hs->frame_mask[widx] == full_mask) {
            uint8_t out[5 + MAX_PLAYERS];
            hs_put32(out, frame);
            out[4] = MAX_PLAYERS;
            for (int i = 0; i < MAX_PLAYERS; i++) out[5 + i] = hs->frame_btns[widx][i];
            broadcast(hs, S_FRAME, out, sizeof(out));
            hs->frame_mask[widx] = 0;
        }
    } else if (type == C_LEAVE) {
        drop_slot(hs, idx);
    }
}

bool host_server_start(HostServer *hs, int port, const char *room_code) {
    host_server_stop(hs);
    memset(hs, 0, sizeof(*hs));
    hs->listen_sock = -1;
    for (int i = 0; i < MAX_PLAYERS; i++) hs->slots[i].sock = -1;

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return false;

    int yes = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);

    if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(s, 4) != 0) {
        close(s);
        return false;
    }

    hs_set_nonblock(s);
    hs->listen_sock = s;
    hs->port = port;
    memcpy(hs->code, room_code, ROOM_CODE_LEN);
    hs->code[ROOM_CODE_LEN] = '\0';
    hs->running = true;
    return true;
}

void host_server_poll(HostServer *hs) {
    if (!hs->running || hs->listen_sock < 0) return;

    for (;;) {
        struct sockaddr_in cli_addr;
        socklen_t clen = sizeof(cli_addr);
        int cs = accept(hs->listen_sock, (struct sockaddr *)&cli_addr, &clen);
        if (cs < 0) break;

        hs_set_nonblock(cs);
        int free_slot = -1;
        for (int i = 0; i < MAX_PLAYERS; i++) {
            if (!hs->slots[i].active) { free_slot = i; break; }
        }
        if (free_slot < 0 || hs->started) {
            uint8_t msg[3] = { S_ERROR, 1, hs->started ? ERR_STARTED : ERR_FULL };
            send(cs, msg, 3, MSG_NOSIGNAL);
            close(cs);
            continue;
        }
        HostSlot *sl = &hs->slots[free_slot];
        memset(sl, 0, sizeof(*sl));
        sl->sock = cs;
        sl->active = true;
        strcpy(sl->name, "JOGADOR");
    }

    for (int i = 0; i < MAX_PLAYERS; i++) {
        HostSlot *sl = &hs->slots[i];
        if (!sl->active) continue;
        for (;;) {
            if (sl->rxlen >= (int)sizeof(sl->rx)) { drop_slot(hs, i); break; }
            int r = (int)recv(sl->sock, sl->rx + sl->rxlen, sizeof(sl->rx) - sl->rxlen, 0);
            if (r > 0) { sl->rxlen += r; continue; }
            if (r == 0) { drop_slot(hs, i); break; }
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            drop_slot(hs, i);
            break;
        }
        if (!sl->active) continue;

        int off = 0;
        while (sl->rxlen - off >= 2) {
            uint8_t type = sl->rx[off];
            uint8_t len  = sl->rx[off + 1];
            if (sl->rxlen - off < 2 + len) break;
            handle_slot_msg(hs, i, type, sl->rx + off + 2, len);
            if (!hs->running || !sl->active) break;
            off += 2 + len;
        }
        if (hs->running && sl->active && off > 0) {
            memmove(sl->rx, sl->rx + off, sl->rxlen - off);
            sl->rxlen -= off;
        }
    }
}

void host_server_stop(HostServer *hs) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (hs->slots[i].active && hs->slots[i].sock >= 0) close(hs->slots[i].sock);
        hs->slots[i].active = false;
        hs->slots[i].sock = -1;
    }
    if (hs->listen_sock >= 0) {
        close(hs->listen_sock);
        hs->listen_sock = -1;
    }
    hs->running = false;
    hs->started = false;
}
