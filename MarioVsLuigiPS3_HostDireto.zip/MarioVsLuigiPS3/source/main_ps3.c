/* Camada PS3 (PSL1GHT): video via RSX framebuffer, controle DualShock 3, loop a 60 Hz.
 * ATENCAO: esta camada NAO foi compilada nem testada (sem toolchain neste ambiente).
 * O nucleo (game.c) foi testado no PC. Veja PORT_STATUS.md. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>

#include <ppu-lv2.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <rsx/rsx.h>
#include <io/pad.h>

#include "app.h"

#define GCM_CB_SIZE   (1024 * 1024)
#define HOST_SIZE     (32 * 1024 * 1024)

typedef struct { int w, h; uint32_t id; uint32_t *ptr; uint32_t offset; } Buffer;

static gcmContextData *ctx;
static Buffer   bufs[2];
static int      cur = 0;
static uint32_t disp_w, disp_h;
static volatile int running = 1;

static void sysutil_cb(u64 status, u64 param, void *usrdata) {
    (void) param; (void) usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

static void wait_flip(void) {
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static void flip(int i) {
    if (gcmSetFlip(ctx, i) == 0) {
        rsxFlushBuffer(ctx);
        gcmSetWaitFlip(ctx);
    }
}

static int init_video(void) {
    void *host = memalign(1024 * 1024, HOST_SIZE);
    if (!host) return -1;
    if (rsxInit(&ctx, GCM_CB_SIZE, HOST_SIZE, host) != 0) return -1;

    videoState state;
    if (videoGetState(0, 0, &state) != 0 || state.state != 0) return -1;
    videoResolution res;
    if (videoGetResolution(state.displayMode.resolution, &res) != 0) return -1;

    videoConfiguration vc;
    memset(&vc, 0, sizeof(vc));
    vc.resolution = state.displayMode.resolution;
    vc.format     = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch      = res.width * sizeof(uint32_t);
    vc.aspect     = state.displayMode.aspect;
    if (videoConfigure(0, &vc, NULL, 0) != 0) return -1;
    if (videoGetState(0, 0, &state) != 0) return -1;

    gcmSetFlipMode(GCM_FLIP_VSYNC);
    disp_w = res.width; disp_h = res.height;

    for (int i = 0; i < 2; i++) {
        bufs[i].w = res.width; bufs[i].h = res.height; bufs[i].id = i;
        bufs[i].ptr = (uint32_t *) rsxMemalign(64, res.width * res.height * sizeof(uint32_t));
        if (!bufs[i].ptr) return -1;
        rsxAddressToOffset(bufs[i].ptr, &bufs[i].offset);
        gcmSetDisplayBuffer(i, bufs[i].offset, res.width * sizeof(uint32_t), res.width, res.height);
    }
    gcmResetFlipStatus();
    flip(1);                     /* mostra o buffer 1; desenhamos no 0 primeiro */
    return 0;
}

/* ---- entrada: DualShock 3 -> PadRaw ---- */
static PadRaw read_pad(int idx, const padInfo *info) {
    PadRaw p = {0};
    if (!info->status[idx]) return p;
    padData d;
    ioPadGetData(idx, &d);
    p.left   = d.BTN_LEFT  || d.ANA_L_H < 64;
    p.right  = d.BTN_RIGHT || d.ANA_L_H > 192;
    p.up     = d.BTN_UP    || d.ANA_L_V < 64;
    p.down   = d.BTN_DOWN  || d.ANA_L_V > 192;
    p.cross  = d.BTN_CROSS;
    p.circle = d.BTN_CIRCLE;
    p.square = d.BTN_SQUARE;
    p.start  = d.BTN_START;
    return p;
}

int main(void) {
    sysUtilRegisterCallback(0, sysutil_cb, NULL);
    if (init_video() != 0) return 1;
    ioPadInit(7);

    static App app;
    app_init(&app);                 /* tambem inicializa a rede (netInitialize) */

    while (running && !app.quit) {
        sysUtilCheckCallback();
        padInfo info; ioPadGetInfo(&info);
        PadRaw pads[2] = { read_pad(0, &info), read_pad(1, &info) };

        app_tick(&app, pads);

        wait_flip();
        Canvas canvas = { bufs[cur].ptr, bufs[cur].w, bufs[cur].h };
        app_draw(&app, &canvas);
        flip(cur);
        cur ^= 1;
    }
    ioPadEnd();
    return 0;
}
