/* Desenho independente de plataforma: retangulos, texto 5x7 e a cena do jogo. */
#include "render.h"
#include "font_data.h"

void canvas_rect(Canvas *c, int x, int y, int w, int h, uint32_t color) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > c->w) w = c->w - x;
    if (y + h > c->h) h = c->h - y;
    for (int j = 0; j < h; j++) {
        uint32_t *row = c->px + (y + j) * c->w + x;
        for (int i = 0; i < w; i++) row[i] = color;
    }
}

static const uint8_t *glyph(char ch) {
    if (ch >= 'a' && ch <= 'z') ch -= 32;
    for (int i = 0; i < FONT_GLYPH_COUNT; i++)
        if (FONT_GLYPHS[i].ch == ch) return FONT_GLYPHS[i].rows;
    return FONT_GLYPHS[FONT_GLYPH_COUNT - 1].rows;      /* espaco */
}

int text_width(const char *s, int scale) {
    int n = 0;
    while (s[n]) n++;
    return n ? n * 6 * scale - scale : 0;
}

void draw_text(Canvas *c, int x, int y, int scale, uint32_t color, const char *s) {
    for (; *s; s++, x += 6 * scale) {
        const uint8_t *g = glyph(*s);
        for (int r = 0; r < 7; r++)
            for (int col = 0; col < 5; col++)
                if (g[r] & (1 << (4 - col)))
                    canvas_rect(c, x + col * scale, y + r * scale, scale, scale, color);
    }
}

void draw_text_center(Canvas *c, int y, int scale, uint32_t color, const char *s) {
    draw_text(c, (c->w - text_width(s, scale)) / 2, y, scale, color, s);
}

void draw_game(Canvas *c, const Game *g) {
    int sx = c->w / LEVEL_W, sy = c->h / LEVEL_H;
    int s = sx < sy ? sx : sy;
    int ox = (c->w - s * LEVEL_W) / 2, oy = (c->h - s * LEVEL_H) / 2;

    canvas_rect(c, 0, 0, c->w, c->h, 0x005C94FC);
    for (int r = 0; r < LEVEL_H; r++)
        for (int col = 0; col < LEVEL_W; col++)
            if (g->level.tiles[r][col] == '#')
                canvas_rect(c, ox + col * s, oy + r * s, s - 1, s - 1, 0x00C84C0C);

    static const uint32_t colors[MAX_PLAYERS] = { 0x00E52521, 0x0043B047 };
    for (int i = 0; i < g->nplayers; i++) {
        const Player *p = &g->players[i];
        int px = ox + (int) ((p->x - p->w * 0.5f) * s);
        int py = oy + (int) ((LEVEL_H - (p->y + p->h)) * s);
        canvas_rect(c, px, py, (int) (p->w * s), (int) (p->h * s), colors[i]);
    }
    for (int i = 0; i < g->nplayers; i++)
        for (int k = 0; k < g->players[i].score && k < 20; k++)
            canvas_rect(c, ox + 8 + k * 14, oy + 8 + i * 16, 10, 10, colors[i]);
}
