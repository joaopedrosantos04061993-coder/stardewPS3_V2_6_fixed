/* Teste de ponta a ponta pelo menu: dois App, um cria a sala, o outro entra pelo codigo. */
#include "app.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int fails = 0;
#define CHECK(name, cond) do { int ok = (cond); printf("[%s] %s\n", ok ? "OK " : "ERRO", name); if (!ok) fails++; } while (0)

static void tick2(App *a, PadRaw pa, App *b, PadRaw pb, int n) {
    PadRaw none[2] = { {0}, {0} };
    for (int i = 0; i < n; i++) {
        PadRaw pA[2] = { i == 0 ? pa : none[0], {0} }, pB[2] = { i == 0 ? pb : none[0], {0} };
        app_tick(a, pA); app_tick(b, pB);
        usleep(2000);
    }
}

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 17777;
    static App A, B;
    app_init(&A); app_init(&B);
    A.octet[0] = B.octet[0] = 127; A.octet[1] = A.octet[2] = B.octet[1] = B.octet[2] = 0; A.octet[3] = B.octet[3] = 1;
    A.port = B.port = port;
    PadRaw none = {0};

    tick2(&A, (PadRaw){ .down = true }, &B, none, 2);
    tick2(&A, (PadRaw){ .cross = true }, &B, none, 2);
    tick2(&A, none, &B, none, 40);
    CHECK("A foi para o lobby e recebeu o codigo", A.scr == SCR_LOBBY && A.net.in_room && A.net.is_host);
    printf("      codigo: %s\n", A.net.code);

    tick2(&A, none, &B, (PadRaw){ .down = true }, 2);
    tick2(&A, none, &B, (PadRaw){ .down = true }, 2);
    tick2(&A, none, &B, (PadRaw){ .cross = true }, 2);
    CHECK("B abriu a tela de codigo", B.scr == SCR_CODE);
    memcpy(B.code, A.net.code, ROOM_CODE_LEN);
    B.code_pos = ROOM_CODE_LEN - 1;
    tick2(&A, none, &B, (PadRaw){ .cross = true }, 2);
    tick2(&A, none, &B, none, 40);
    CHECK("B entrou no lobby pelo codigo", B.scr == SCR_LOBBY && B.net.in_room && !B.net.is_host && B.net.slot == 1);
    CHECK("A ve o jogador 2 no lobby", A.net.present[1]);

    tick2(&A, (PadRaw){ .start = true }, &B, none, 2);
    tick2(&A, none, &B, none, 30);
    CHECK("sem B pronto: A continua no lobby com aviso", A.scr == SCR_LOBBY && A.net.connected && strstr(A.note, "PRONTOS"));

    tick2(&A, none, &B, (PadRaw){ .cross = true }, 2);
    tick2(&A, none, &B, none, 30);
    CHECK("A ve B pronto", A.net.ready[1]);
    tick2(&A, (PadRaw){ .start = true }, &B, none, 2);
    tick2(&A, none, &B, none, 30);
    CHECK("os dois entram na partida online", A.scr == SCR_ONLINE && B.scr == SCR_ONLINE);

    for (int t = 0; t < 400; t++) {
        PadRaw pa = { .right = true, .square = true, .cross = (t / 40) % 2 == 0 };
        PadRaw pb = { .left = true, .cross = (t / 25) % 2 == 1 };
        PadRaw pA[2] = { pa, {0} }, pB[2] = { pb, {0} };
        app_tick(&A, pA); app_tick(&B, pB);
        usleep(2000);
    }
    printf("      A: frame %u  P1 (%.3f,%.3f)  P2 (%.3f,%.3f)\n", A.net.sim_frame,
           A.game.players[0].x, A.game.players[0].y, A.game.players[1].x, A.game.players[1].y);
    printf("      B: frame %u  P1 (%.3f,%.3f)  P2 (%.3f,%.3f)\n", B.net.sim_frame,
           B.game.players[0].x, B.game.players[0].y, B.game.players[1].x, B.game.players[1].y);
    CHECK("os dois simulam o jogo", A.net.sim_frame > 200 && B.net.sim_frame > 200);
    CHECK("jogadores se moveram", A.game.players[0].x != A.game.players[0].spawn_x);

    PadRaw pB2[2] = { { .start = true }, {0} }, pA2[2] = { none, {0} };
    app_tick(&B, pB2); app_tick(&A, pA2);
    tick2(&A, none, &B, none, 40);
    CHECK("B voltou ao titulo", B.scr == SCR_TITLE);
    CHECK("A voltou ao lobby com aviso", A.scr == SCR_LOBBY && strstr(A.note, "SAIU") && A.net.in_room);

    printf("\n%s\n", fails ? "FALHOU" : "TUDO OK");
    return fails != 0;
}
