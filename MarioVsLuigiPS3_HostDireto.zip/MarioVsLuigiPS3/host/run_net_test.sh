#!/bin/bash
cd "$(dirname "$0")/.."
PORT=17777
gcc -Wall -Wextra -Iinclude host/test_net.c source/net.c source/host_server.c source/room_code.c source/game.c -lm -o /tmp/test_net || exit 1
gcc -Wall -Wextra -Iinclude host/test_app_flow.c source/app.c source/render.c source/net.c source/host_server.c source/room_code.c source/game.c -lm -o /tmp/test_app_flow || exit 1
echo "=== protocolo, codigo 7 chars e lockstep ==="; /tmp/test_net $PORT; RC1=$?
echo; echo "=== fluxo completo pelo menu ==="; /tmp/test_app_flow $PORT; RC2=$?
[ $RC1 -eq 0 ] && [ $RC2 -eq 0 ]
