/* Teste de integracao: servidor embutido em C + codigo 7 chars + 2 clientes.
 * Uso: bash host/run_net_test.sh */
#include "net.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

static int fails = 0;
#define CHECK(name, cond) do { int ok = (cond); printf("[%s] %s\n", ok ? "OK " : "ERRO", name); if (!ok) fails++; } while (0)

static void pump(Net *a, Net *b, int ms) {
    for (int i = 0; i < ms; i++) { net_poll(a); if (b) net_poll(b); usleep(1000); }
}

static Input scripted(int slot, int frame) {
    Input in = {0};
    if (slot == 0) { in.right = true; in.sprint_down = true; in.jump_down = (frame / 40) % 2 == 0; }
    else           { in.left = true;  in.jump_down = (frame / 25) % 2 == 1; }
    return in;
}

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 17777;
    Net a, b, c;

    char encoded[ROOM_CODE_LEN + 1];
    uint32_t decoded = 0;
    room_code_encode(0xC0A8000Au, encoded);
    CHECK("codigo gerado tem 7 caracteres", strlen(encoded) == 7);
    CHECK("decodifica 192.168.0.10 corretamente", room_code_decode(encoded, &decoded) && decoded == 0xC0A8000Au);

    int typo_caught = 1;
    for (int i = 0; i < 7; i++) {
        char bad[8];
        strcpy(bad, encoded);
        bad[i] = (bad[i] == 'A') ? 'B' : 'A';
        if (room_code_decode(bad, &decoded)) typo_caught = 0;
    }
    CHECK("digito verificador rejeita troca de 1 caractere em qualquer posicao", typo_caught);

    net_init(&a);
    CHECK("A sobe servidor embutido e cria sala", net_host_room(&a, 0x7F000001u, port, "ANA"));
    pump(&a, NULL, 50);
    CHECK("A recebe codigo de 7 caracteres", a.in_room && strlen(a.code) == 7 && a.is_host && a.slot == 0);
    printf("      codigo da sala (127.0.0.1): %s\n", a.code);
    CHECK("A aparece no lobby", a.present[0] && a.ready[0] && strcmp(a.names[0], "ANA") == 0);

    net_init(&c);
    char typo[ROOM_CODE_LEN + 1];
    strcpy(typo, a.code);
    typo[6] = (typo[6] == 'A') ? 'B' : 'A';
    CHECK("codigo com typo -> CODIGO INVALIDO sem conectar", !net_join_by_code(&c, typo, port, "CAIO") && c.error == ERR_BAD_CODE);
    net_close(&c);

    net_init(&b);
    char lower[ROOM_CODE_LEN + 1];
    for (int i = 0; i < ROOM_CODE_LEN; i++) {
        char ch = a.code[i];
        lower[i] = (ch >= 'A' && ch <= 'Z') ? ch + 32 : ch;
    }
    lower[ROOM_CODE_LEN] = '\0';
    CHECK("B conecta decodificando o codigo", net_join_by_code(&b, lower, port, "BIA"));
    pump(&a, &b, 150);
    CHECK("B entra pelo codigo no slot 1", b.in_room && !b.is_host && b.slot == 1 && strcmp(b.code, a.code) == 0);
    CHECK("A ve B no lobby", a.present[1] && !a.ready[1] && strcmp(a.names[1], "BIA") == 0);

    net_init(&c);
    net_join_by_code(&c, a.code, port, "CAIO");
    pump(&a, &c, 100);
    CHECK("terceiro jogador -> SALA CHEIA", c.error == ERR_FULL);
    net_close(&c);

    net_start_game(&a);
    pump(&a, &b, 100);
    CHECK("iniciar sem B pronto e recusado", a.error == ERR_NOT_READY && !a.started);
    a.error = 0;

    net_set_ready(&b, true);
    pump(&a, &b, 100);
    CHECK("A ve B pronto", a.ready[1]);
    net_start_game(&a);
    pump(&a, &b, 100);
    CHECK("os dois recebem S_START", a.started && b.started && a.nplayers == 2 && b.nplayers == 2);

    static Game ga, gb;
    memset(&ga, 0, sizeof(ga)); memset(&gb, 0, sizeof(gb));
    level_load_from_string(&ga.level, level_default_text());
    level_load_from_string(&gb.level, level_default_text());
    game_init(&ga, 2); game_init(&gb, 2);

    int stepsA = 0, stepsB = 0;
    for (int t = 0; t < 700 && (stepsA < 600 || stepsB < 600); t++) {
        net_poll(&a); net_poll(&b);
        Input la = scripted(0, t), lb = scripted(1, t);
        net_send_input(&a, input_to_buttons(&la));
        net_send_input(&b, input_to_buttons(&lb));
        usleep(2000);
        net_poll(&a); net_poll(&b);
        Input in[MAX_PLAYERS];
        int k = 0;
        while (k++ < 2 && stepsA < 600 && net_next_frame(&a, in)) { game_step(&ga, in); stepsA++; }
        k = 0;
        while (k++ < 2 && stepsB < 600 && net_next_frame(&b, in)) { game_step(&gb, in); stepsB++; }
    }
    printf("      frames simulados: A=%d B=%d\n", stepsA, stepsB);
    CHECK("os dois simularam 600 frames", stepsA == 600 && stepsB == 600);
    int same = 1;
    for (int i = 0; i < 2; i++) {
        const Player *p = &ga.players[i], *q = &gb.players[i];
        if (memcmp(&p->x, &q->x, sizeof(float)) || memcmp(&p->y, &q->y, sizeof(float)) ||
            memcmp(&p->vx, &q->vx, sizeof(float)) || memcmp(&p->vy, &q->vy, sizeof(float)) ||
            p->score != q->score) same = 0;
    }
    CHECK("estado identico nos dois clientes (bit a bit)", same);

    net_close(&b);
    pump(&a, NULL, 200);
    CHECK("A e avisado e volta ao lobby", a.peer_left == 1 && !a.started && a.in_room);

    net_init(&c);
    net_join_by_code(&c, a.code, port, "DUDA");
    pump(&a, &c, 150);
    CHECK("novo jogador entra na sala depois da saida", c.in_room && c.slot == 1);
    net_leave_room(&a);
    pump(&c, NULL, 150);
    CHECK("anfitriao saiu: sala fechada para os outros", c.peer_left == 2 && !c.in_room);

    net_close(&a); net_close(&c);
    printf("\n%s\n", fails ? "FALHOU" : "TUDO OK");
    return fails != 0;
}
