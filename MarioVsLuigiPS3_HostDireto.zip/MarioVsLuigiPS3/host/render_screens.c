/* Renderiza as telas do menu em arquivos .ppm para conferir o visual no PC.
 * Uso: gcc -Iinclude host/render_screens.c source/app.c source/render.c source/net.c source/game.c -lm -o /tmp/render_screens && /tmp/render_screens /tmp/shots */
#include "app.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define W 1280
#define H 720
static uint32_t pixels[W * H];

static void shot(App *a, const char *dir, const char *name) {
    Canvas c = { pixels, W, H };
    app_draw(a, &c);
    char path[256]; snprintf(path, sizeof(path), "%s/%s.ppm", dir, name);
    FILE *f = fopen(path, "wb");
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (int i = 0; i < W * H; i++) { unsigned char rgb[3] = { pixels[i] >> 16, pixels[i] >> 8, pixels[i] }; fwrite(rgb, 1, 3, f); }
    fclose(f);
}
static void press(App *a, PadRaw p) {
    PadRaw pads[2] = { p, {0} }, none[2] = { {0}, {0} };
    app_tick(a, pads);
    app_tick(a, none);
}

int main(int argc, char **argv) {
    const char *dir = argc > 1 ? argv[1] : ".";
    App a; app_init(&a);
    shot(&a, dir, "1_titulo");
    press(&a, (PadRaw){ .down = true }); press(&a, (PadRaw){ .down = true });
    press(&a, (PadRaw){ .cross = true });                      /* ENTRAR COM CODIGO */
    press(&a, (PadRaw){ .up = true }); press(&a, (PadRaw){ .right = true }); press(&a, (PadRaw){ .up = true });
    printf("codigo digitado: %s (esperado BBAA?)\n", a.code);
    shot(&a, dir, "2_codigo");
    press(&a, (PadRaw){ .circle = true });
    press(&a, (PadRaw){ .down = true }); press(&a, (PadRaw){ .cross = true });  /* SERVIDOR */
    for (int i = 0; i < 5; i++) press(&a, (PadRaw){ .up = true });
    press(&a, (PadRaw){ .right = true }); press(&a, (PadRaw){ .down = true });
    shot(&a, dir, "3_servidor");

    /* lobby montado a mao (sem servidor) */
    a.scr = SCR_LOBBY;
    a.net.in_room = true; a.net.is_host = true; a.net.slot = 0;
    memcpy(a.net.code, "K7QF", 5);
    a.net.present[0] = a.net.present[1] = true; a.net.ready[0] = true; a.net.ready[1] = false;
    strcpy(a.net.names[0], "PS3"); strcpy(a.net.names[1], "PS3");
    shot(&a, dir, "4_lobby_host");
    a.net.ready[1] = true; a.net.present[1] = true;
    snprintf(a.note, sizeof(a.note), "O OUTRO JOGADOR SAIU");
    shot(&a, dir, "5_lobby_pronto");

    a.scr = SCR_MESSAGE; snprintf(a.msg, sizeof(a.msg), "SALA NAO ENCONTRADA");
    shot(&a, dir, "6_erro");
    a.scr = SCR_TITLE; a.sel = 0;
    press(&a, (PadRaw){ .cross = true });                      /* JOGAR LOCAL */
    for (int i = 0; i < 90; i++) press(&a, (PadRaw){ .right = true, .square = true });
    shot(&a, dir, "7_jogo");
    return 0;
}
