/* Teste no PC: gcc -Iinclude host/test_physics.c source/game.c -lm -o test && ./test */
#include "game.h"
#include <stdio.h>
#include <math.h>

static int fails = 0;
#define CHECK(name, cond) do { int ok = (cond); printf("[%s] %s\n", ok ? "OK " : "ERRO", name); if (!ok) fails++; } while (0)

static void setup(Game *g, int n) {
    if (!level_load(&g->level, "data/level1.txt")) { printf("falha ao carregar fase\n"); fails++; }
    game_init(g, n);
}
static void run(Game *g, Input in, int frames) {
    Input arr[MAX_PLAYERS] = { in, {0} };
    for (int i = 0; i < frames; i++) { game_step(g, arr); in.jump_pressed = false; arr[0] = in; }
}

int main(void) {
    Game g; Input in;

    setup(&g, 1);
    in = (Input){0};
    run(&g, in, 30);
    CHECK("assenta no chao (y = 1.0)", fabsf(g.players[0].y - 1.0f) < 0.01f && g.players[0].on_ground);

    in = (Input){ .right = true };
    run(&g, in, 120);
    printf("      andar: vx = %.4f (esperado 2.8125)\n", g.players[0].vx);
    CHECK("velocidade de andar = 2.8125", fabsf(g.players[0].vx - 2.8125f) < 0.02f);

    setup(&g, 1);
    in = (Input){ .right = true, .sprint_down = true };
    run(&g, in, 40);   /* curto: nao dar a volta no mapa para bater em parede */
    printf("      correr (40 frames): vx = %.4f (rumo a 5.625)\n", g.players[0].vx);
    CHECK("acelerando ao correr (vx > 2.8125)", g.players[0].vx > 2.8125f);

    /* Altura de pulo: segurando e tap */
    setup(&g, 1); in = (Input){0}; run(&g, in, 30);
    float y0 = g.players[0].y, maxy = y0;
    Input hold = { .jump_down = true, .jump_pressed = true };
    Input arr[MAX_PLAYERS] = { hold, {0} };
    for (int i = 0; i < 120; i++) {
        game_step(&g, arr); hold.jump_pressed = false; arr[0] = hold;
        if (g.players[0].y > maxy) maxy = g.players[0].y;
    }
    printf("      pulo segurando: altura = %.3f tiles (calculo manual ~2.17)\n", maxy - y0);
    CHECK("altura do pulo segurando ~2.17", fabsf((maxy - y0) - 2.17f) < 0.15f);

    setup(&g, 1); in = (Input){0}; run(&g, in, 30);
    y0 = g.players[0].y; maxy = y0;
    Input tap = { .jump_down = false, .jump_pressed = true };
    arr[0] = tap;
    for (int i = 0; i < 120; i++) {
        game_step(&g, arr); tap.jump_pressed = false; arr[0] = tap;
        if (g.players[0].y > maxy) maxy = g.players[0].y;
    }
    printf("      pulo rapido (tap): altura = %.3f tiles (calculo manual ~0.57)\n", maxy - y0);
    CHECK("altura do pulo tap ~0.57", fabsf((maxy - y0) - 0.57f) < 0.1f);

    /* nao atravessa o chao depois de muito tempo */
    setup(&g, 1); in = (Input){0}; run(&g, in, 600);
    CHECK("sem vazamento pelo chao apos 10s", g.players[0].y > 0.99f);


    /* ---- Agachar: desacelera no chao e nao anda ---- */
    setup(&g, 1);
    run(&g, (Input){0}, 30);
    run(&g, (Input){ .right = true, .sprint_down = true }, 30);
    float v_before = g.players[0].vx;
    run(&g, (Input){ .down = true, .right = true }, 20);
    printf("      agachar: vx %.3f -> %.3f\n", v_before, g.players[0].vx);
    CHECK("agachado no chao desacelera mesmo segurando direita", g.players[0].crouching && g.players[0].vx < v_before);
    run(&g, (Input){ .down = true }, 60);
    CHECK("agachado fica parado", fabsf(g.players[0].vx) < 0.001f);
    run(&g, (Input){0}, 2);
    CHECK("soltar baixo levanta", !g.players[0].crouching);

    /* ---- Parede: wallslide e walljump ---- */
    static const char *WALL =
        "............................\n............................\n............................\n"
        "............................\n..........#.................\n..........#.................\n"
        "..........#.................\n..........#.................\n..........#.................\n"
        "..........#.................\n..........#.................\n..........#.................\n"
        ".1........#.................\n############################\n";
    Game w;
    CHECK("carrega fase com parede", level_load_from_string(&w.level, WALL));
    game_init(&w, 1);
    Player *p = &w.players[0];
    p->x = 9.79f; p->y = 8.0f; p->vx = 0.5f; p->vy = -1.0f; p->facing_right = true;
    Input hr = { .right = true };
    Input arr2[MAX_PLAYERS] = { hr, {0} };
    float min_vy = 0;
    for (int i = 0; i < 20; i++) { game_step(&w, arr2); if (p->vy < min_vy) min_vy = p->vy; }
    printf("      wallslide: ativo=%d vy=%.3f\n", p->wslide_right, p->vy);
    CHECK("encosta na parede e entra em wallslide", p->wslide_right);
    p->vy = -6.0f;
    for (int i = 0; i < 3; i++) game_step(&w, arr2);
    CHECK("velocidade de queda limitada a -4.6875", p->vy >= -4.6875f - 0.001f);
    Input jp = { .right = true, .jump_down = true, .jump_pressed = true };
    arr2[0] = jp; game_step(&w, arr2);
    printf("      walljump: vx=%.3f vy=%.3f frames=%d\n", p->vx, p->vy, p->walljump_frames);
    CHECK("walljump joga para longe da parede", p->vx < -3.0f && p->vy > 5.0f && p->walljump_frames > 0);
    CHECK("sai do wallslide", !p->wslide_right && !p->wslide_left);

    printf("\n%s\n", fails ? "FALHOU" : "TUDO OK");
    return fails != 0;
}
