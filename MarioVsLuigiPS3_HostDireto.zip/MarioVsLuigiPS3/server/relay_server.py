#!/usr/bin/env python3
"""Servidor relay do Mario vs Luigi PS3.

Cria salas com codigo de 4 caracteres, mantem o lobby e retransmite os botoes dos
jogadores (lockstep: so avanca o frame N quando todos enviaram o frame N).
Nao simula o jogo; so repassa. Uso:  python3 server/relay_server.py --port 7777
"""
import argparse
import asyncio
import random
import struct

MAX_PLAYERS = 2
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

C_CREATE, C_JOIN, C_READY, C_START, C_INPUT, C_LEAVE = 1, 2, 3, 4, 5, 6
S_CREATED, S_JOINED, S_ERROR, S_LOBBY, S_START, S_FRAME, S_PEERLEFT = 16, 17, 18, 19, 20, 21, 22
ERR_NO_ROOM, ERR_FULL, ERR_STARTED, ERR_NOT_READY, ERR_BAD = 1, 2, 3, 4, 5

rooms = {}


def pack(t, payload=b""):
    return bytes([t, len(payload)]) + payload


def name12(raw):
    raw = raw.split(b"\0", 1)[0][:12]
    clean = bytes(c if 32 <= c < 127 else ord("?") for c in raw) or b"JOGADOR"
    return clean.ljust(12, b"\0")


class Client:
    def __init__(self, writer):
        self.writer = writer
        self.name = b"JOGADOR".ljust(12, b"\0")
        self.room = None
        self.slot = -1
        self.ready = False

    def send(self, t, payload=b""):
        try:
            self.writer.write(pack(t, payload))
        except Exception:
            pass


class Room:
    def __init__(self, code):
        self.code = code
        self.slots = [None] * MAX_PLAYERS
        self.started = False
        self.nplayers = 0
        self.frames = {}

    def clients(self):
        return [c for c in self.slots if c]

    def broadcast(self, t, payload=b""):
        for c in self.clients():
            c.send(t, payload)

    def lobby_payload(self):
        out = b""
        for c in self.slots:
            out += bytes([1 if c else 0, 1 if (c and c.ready) else 0]) + (c.name if c else b"\0" * 12)
        return out


def new_code():
    for _ in range(1000):
        code = "".join(random.choice(ALPHABET) for _ in range(4))
        if code not in rooms:
            return code
    raise RuntimeError("sem codigos livres")


def leave(client):
    room = client.room
    if not room:
        return
    slot = client.slot
    client.room, client.slot, client.ready = None, -1, False
    room.slots[slot] = None
    if slot == 0:                         # anfitriao saiu: fecha a sala
        for c in room.clients():
            c.send(S_PEERLEFT, bytes([1]))
            c.room, c.slot, c.ready = None, -1, False
        rooms.pop(room.code, None)
        print(f"sala {room.code} fechada")
        return
    if room.started:                      # partida interrompida: volta ao lobby
        room.started = False
        room.frames = {}
        for c in room.clients():
            c.ready = (c.slot == 0)
    room.broadcast(S_PEERLEFT, bytes([0]))
    room.broadcast(S_LOBBY, room.lobby_payload())


def handle_msg(client, t, p):
    if t == C_CREATE:
        leave(client)
        client.name = name12(p[:12])
        code = new_code()
        room = Room(code)
        rooms[code] = room
        room.slots[0] = client
        client.room, client.slot, client.ready = room, 0, True
        client.send(S_CREATED, code.encode() + bytes([0]))
        room.broadcast(S_LOBBY, room.lobby_payload())
        print(f"sala {code} criada")
    elif t == C_JOIN:
        leave(client)
        code = p[:4].decode("ascii", "replace").upper()
        client.name = name12(p[4:16])
        room = rooms.get(code)
        if not room:
            return client.send(S_ERROR, bytes([ERR_NO_ROOM]))
        if room.started:
            return client.send(S_ERROR, bytes([ERR_STARTED]))
        free = [i for i, c in enumerate(room.slots) if c is None]
        if not free:
            return client.send(S_ERROR, bytes([ERR_FULL]))
        slot = free[0]
        room.slots[slot] = client
        client.room, client.slot, client.ready = room, slot, False
        client.send(S_JOINED, code.encode() + bytes([slot]))
        room.broadcast(S_LOBBY, room.lobby_payload())
        print(f"{code}: jogador entrou no slot {slot}")
    elif t == C_READY and client.room and not client.room.started and client.slot != 0:
        client.ready = bool(p[0]) if p else False
        client.room.broadcast(S_LOBBY, client.room.lobby_payload())
    elif t == C_START and client.room and client.slot == 0 and not client.room.started:
        room = client.room
        present = room.clients()
        if len(present) < 2 or not all(c.ready for c in present):
            return client.send(S_ERROR, bytes([ERR_NOT_READY]))
        room.started, room.nplayers, room.frames = True, MAX_PLAYERS, {}
        room.broadcast(S_START, bytes([room.nplayers]))
        print(f"{room.code}: partida iniciada")
    elif t == C_INPUT and client.room and client.room.started and len(p) >= 5:
        room = client.room
        frame = struct.unpack(">I", p[:4])[0]
        room.frames.setdefault(frame, {})[client.slot] = p[4]
        if len(room.frames[frame]) == room.nplayers:
            buttons = bytes(room.frames[frame].get(i, 0) for i in range(room.nplayers))
            room.broadcast(S_FRAME, struct.pack(">IB", frame, room.nplayers) + buttons)
            del room.frames[frame]
    elif t == C_LEAVE:
        leave(client)


async def serve_client(reader, writer):
    client = Client(writer)
    try:
        while True:
            hdr = await reader.readexactly(2)
            payload = await reader.readexactly(hdr[1]) if hdr[1] else b""
            handle_msg(client, hdr[0], payload)
            await writer.drain()
    except (asyncio.IncompleteReadError, ConnectionError):
        pass
    finally:
        leave(client)
        try:
            writer.close()
        except Exception:
            pass


async def main(host, port):
    server = await asyncio.start_server(serve_client, host, port)
    print(f"relay ouvindo em {host}:{port}")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=7777)
    a = ap.parse_args()
    try:
        asyncio.run(main(a.host, a.port))
    except KeyboardInterrupt:
        pass
