#ifndef RENDER_H
#define RENDER_H
#include <stdint.h>
#include "game.h"

typedef struct { uint32_t *px; int w, h; } Canvas;   /* pixels XRGB */

void canvas_rect(Canvas *c, int x, int y, int w, int h, uint32_t color);
void draw_text(Canvas *c, int x, int y, int scale, uint32_t color, const char *s);
int  text_width(const char *s, int scale);
void draw_text_center(Canvas *c, int y, int scale, uint32_t color, const char *s);
void draw_game(Canvas *c, const Game *g);

#endif
