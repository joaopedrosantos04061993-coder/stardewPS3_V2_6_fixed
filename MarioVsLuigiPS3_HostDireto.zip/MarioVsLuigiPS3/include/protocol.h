/* Protocolo cliente <-> servidor embutido no PS3 (TCP). Cada mensagem: [tipo u8][tamanho u8][payload].
 * Inteiros multi-byte em ordem de rede (big-endian). */
#ifndef PROTOCOL_H
#define PROTOCOL_H

/* cliente -> servidor */
#define C_CREATE  1   /* nome[12] */
#define C_JOIN    2   /* codigo[7] nome[12] */
#define C_READY   3   /* pronto u8 */
#define C_START   4   /* (so o anfitriao) */
#define C_INPUT   5   /* frame u32, botoes u8 */
#define C_LEAVE   6

/* servidor -> cliente */
#define S_CREATED  16 /* codigo[7] slot u8 */
#define S_JOINED   17 /* codigo[7] slot u8 */
#define S_ERROR    18 /* erro u8 */
#define S_LOBBY    19 /* por slot: presente u8, pronto u8, nome[12] */
#define S_START    20 /* nplayers u8 */
#define S_FRAME    21 /* frame u32, n u8, botoes[n] */
#define S_PEERLEFT 22 /* motivo u8: 0 = jogador saiu, 1 = anfitriao saiu (sala fechada) */

/* codigos de erro */
#define ERR_NO_ROOM   1
#define ERR_FULL      2
#define ERR_STARTED   3
#define ERR_NOT_READY 4
#define ERR_BAD       5
#define ERR_BAD_CODE  6   /* digito verificador do codigo invalido */

/* botoes (1 byte por jogador por frame) */
#define BTN_L 1
#define BTN_R 2
#define BTN_D 4
#define BTN_J 8
#define BTN_S 16

#define DEFAULT_GAME_PORT 7777
#define ROOM_CODE_LEN     7
#define NAME_LEN          12
#define CODE_ALPHABET     "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

#endif
