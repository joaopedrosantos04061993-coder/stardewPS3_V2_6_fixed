#ifndef HOST_SERVER_H
#define HOST_SERVER_H

#include <stdint.h>
#include <stdbool.h>
#include "game.h"
#include "protocol.h"

#define HOST_FRAME_WINDOW 64

typedef struct {
    int     sock;
    bool    active;
    bool    ready;
    char    name[NAME_LEN + 1];
    uint8_t rx[512];
    int     rxlen;
} HostSlot;

typedef struct {
    bool     running;
    int      listen_sock;
    int      port;
    char     code[ROOM_CODE_LEN + 1];
    bool     started;
    HostSlot slots[MAX_PLAYERS];

    /* Buffer de lockstep (espelha room.frames do relay_server) */
    uint32_t frame_num[HOST_FRAME_WINDOW];
    uint8_t  frame_mask[HOST_FRAME_WINDOW];
    uint8_t  frame_btns[HOST_FRAME_WINDOW][MAX_PLAYERS];
} HostServer;

bool host_server_start(HostServer *hs, int port, const char *room_code);
void host_server_poll(HostServer *hs);
void host_server_stop(HostServer *hs);

#endif
