#ifndef NET_H
#define NET_H
#include <stdint.h>
#include <stdbool.h>
#include "game.h"
#include "protocol.h"
#include "host_server.h"
#include "room_code.h"

#define NET_INPUT_DELAY 3      /* frames de atraso de entrada (lockstep) */
#define NET_RING 64
#define NET_ERR_DISCONNECTED 100
#define NET_ERR_CONNECT      101

typedef struct {
    int  sock;
    bool connected;
    int  error;                       /* 0, ERR_* do servidor, ou NET_ERR_* */

    /* servidor embutido (ativo apenas no PS3 anfitriao) */
    HostServer server;

    /* sala */
    bool in_room, is_host, started;
    char code[ROOM_CODE_LEN + 1];
    int  slot;
    bool present[MAX_PLAYERS], ready[MAX_PLAYERS];
    char names[MAX_PLAYERS][NAME_LEN + 1];
    int  nplayers;
    int  peer_left;                   /* 0 = nada, 1 = jogador saiu, 2 = anfitriao saiu */

    /* lockstep */
    uint32_t sim_frame, send_frame;
    uint32_t ring_frame[NET_RING];
    bool     ring_valid[NET_RING];
    uint8_t  ring[NET_RING][MAX_PLAYERS];
    uint8_t  prev_jump[MAX_PLAYERS];

    uint8_t  rx[1024];
    int      rxlen;
} Net;

void net_init(Net *n);
bool net_connect(Net *n, const char *ip, int port);   /* IPv4 numerico, ex. "192.168.0.10" */
void net_close(Net *n);
void net_poll(Net *n);

/* Fluxo direto PS3 <-> PS3 */
bool net_get_local_ipv4(uint32_t *out_ip_host);
bool net_host_room(Net *n, uint32_t advertised_ip_host, int port, const char *name);
bool net_join_by_code(Net *n, const char *code, int port, const char *name);

bool net_create_room(Net *n, const char *name);
bool net_join_room(Net *n, const char *code, const char *name);
void net_set_ready(Net *n, bool ready);
void net_start_game(Net *n);
void net_leave_room(Net *n);
void net_send_input(Net *n, uint8_t buttons);
bool net_next_frame(Net *n, Input out[MAX_PLAYERS]);

uint8_t input_to_buttons(const Input *in);
const char *net_error_text(int err);

#endif
