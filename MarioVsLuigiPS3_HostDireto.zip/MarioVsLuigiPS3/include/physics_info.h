/* Constantes de fisica portadas de MarioPlayerPhysicsInfo.cs (NSMB-MarioVsLuigi).
 * Unidades: tiles e segundos. Simulacao a 60 Hz. Somente powerup "normal" por enquanto. */
#ifndef PHYSICS_INFO_H
#define PHYSICS_INFO_H

#define SIM_HZ 60
#define SIM_DT (1.0f / SIM_HZ)

/* Andar / correr */
#define WALK_SPEED_STAGE 1
#define RUN_SPEED_STAGE  3
static const float WALK_MAX_VEL[5]  = { 0.9375f, 2.8125f, 4.21875f, 5.625f, 8.4375f };
static const float WALK_ACC[5]      = { 7.91015625f, 3.955081725f, 3.515625f, 2.63671875f, 84.375f };
#define WALK_RELEASE_DECEL     3.9550781196f
static const float SLOW_TURN_ACC[4] = { 3.955078125f, 8.7890625f, 8.7890625f, 21.093756f };
#define FAST_TURN_ACC          28.125f
#define SKID_MIN_VEL           4.6875f
#define SKID_DECEL             10.54687536f
#define SKID_STAR_DECEL        84.375f
#define AIR_REVERSE_FACTOR     0.85f   /* Constants._0_85 no original */

/* Pulo */
#define JUMP_BUFFER_FRAMES     12
#define COYOTE_FRAMES          3
#define JUMP_VEL               6.62109375f
#define JUMP_SPEED_BONUS       0.46875f
#define JUMP_TRIPLE_BONUS      0.50f
#define TRIPLE_WINDOW_FRAMES   12

/* Gravidade (estagios por velocidade vertical) */
static const float GRAV_VEL[4] = { 4.16015625f, 2.109375f, 0.0f, -5.859375f };
static const float GRAV_ACC[5] = { -7.03125f, -28.125f, -38.671875f, -28.125f, -38.671875f };
#define TERMINAL_VEL           (-7.5f)

/* Parede e agachar */
#define WALLJUMP_H_VEL         4.21875f
#define WALLJUMP_V_VEL         6.4453125f
#define WALLJUMP_FRAMES        16
#define WALLSLIDE_END_FRAMES   16
#define TERMINAL_VEL_WALLSLIDE (-4.6875f)
#define CROUCH_OFF_EDGE_VEL    (-3.75f)

/* Hitbox (altura do original; largura e estimativa, ver PORT_STATUS.md) */
#define HITBOX_H_SMALL         0.42f
#define HITBOX_W               0.40f

#endif
