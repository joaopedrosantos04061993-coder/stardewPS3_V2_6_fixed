#ifndef GAME_H
#define GAME_H
#include <stdint.h>
#include <stdbool.h>

#define MAX_PLAYERS 2
#define LEVEL_W 28
#define LEVEL_H 14

typedef struct {
    bool left, right, down;
    bool jump_down, jump_pressed;   /* pressed = acabou de apertar neste frame */
    bool sprint_down;
} Input;

typedef enum { JUMP_NONE = 0, JUMP_SINGLE, JUMP_DOUBLE, JUMP_TRIPLE } JumpState;

typedef struct {
    float x, y;            /* centro dos pes (y para cima, como no Unity) */
    float vx, vy;
    float w, h;
    bool  on_ground, was_on_ground, facing_right, skidding, turnaround, crouching, alive;
    bool  wslide_left, wslide_right, touch_left, touch_right;
    int   wslide_end, walljump_frames;
    int   slow_turn_frames, fast_turn_frames;
    int   jump_buffer, coyote;
    int   landed_frame;
    JumpState jump_state, prev_jump_state;
    int   score;
    float spawn_x, spawn_y;
} Player;

typedef struct {
    char  tiles[LEVEL_H][LEVEL_W + 1];  /* [0] = linha de cima no arquivo */
    int   nspawn;
    float spawn_x[MAX_PLAYERS], spawn_y[MAX_PLAYERS];
} Level;

typedef struct {
    Level  level;
    Player players[MAX_PLAYERS];
    int    nplayers;
    int    frame;
} Game;

const char *level_default_text(void);   /* fase embutida (igual em todos os clientes) */
bool level_load(Level *lv, const char *path);
bool level_load_from_string(Level *lv, const char *text);
bool level_solid(const Level *lv, int tx, int ty_from_bottom);

void game_init(Game *g, int nplayers);
void game_step(Game *g, const Input in[MAX_PLAYERS]);

#endif
