#ifndef APP_H
#define APP_H
#include <stdbool.h>
#include "game.h"
#include "net.h"
#include "render.h"

typedef struct {
    bool up, down, left, right;
    bool cross, circle, square, start;
} PadRaw;

typedef enum { SCR_TITLE, SCR_SERVER, SCR_CODE, SCR_LOBBY, SCR_LOCAL, SCR_ONLINE, SCR_MESSAGE } Screen;

typedef struct {
    Screen scr;
    int    sel, tick;
    bool   quit;
    PadRaw prev[2];
    int    hold;

    /* servidor */
    int    octet[4], port, cfg_field;
    /* codigo */
    char   code[ROOM_CODE_LEN + 1];
    int    code_pos;
    /* avisos */
    char   msg[48], note[48];

    Net    net;
    Game   game;
} App;

void app_init(App *a);
void app_tick(App *a, const PadRaw pads[2]);
void app_draw(App *a, Canvas *c);
void app_server_string(const App *a, char *out, int n);
bool app_load_config(App *a, const char *path);
bool app_save_config(const App *a, const char *path);

#endif
