#ifndef ROOM_CODE_H
#define ROOM_CODE_H

#include <stdint.h>
#include <stdbool.h>
#include "protocol.h"

/* Codifica um IPv4 (host byte order, ex: 0xC0A8000A = 192.168.0.10) em 7 chars + '\0'
 * contendo 32 bits de endereco + 3 bits de digito verificador. */
void room_code_encode(uint32_t ipv4_host, char out[ROOM_CODE_LEN + 1]);

/* Decodifica e valida o digito verificador. Retorna false se houver erro de digitacao. */
bool room_code_decode(const char *code, uint32_t *out_ipv4_host);

/* Utilitarios IPv4 <-> string */
bool ipv4_parse(const char *str, uint32_t *out_host);
void ipv4_format(uint32_t ip_host, char out[16]);

#endif
