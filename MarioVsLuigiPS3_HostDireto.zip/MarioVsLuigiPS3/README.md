# Mario vs Luigi PS3 (prototipo homebrew)

Reescrita em C para PS3 (PSL1GHT) inspirada em *NSMB - Mario vs Luigi Online* (ipodtouch0218).
**Nao e um port do codigo**: o original e Unity + Photon Quantum (C#), que nao roda no PS3.
Aqui a fisica do jogador foi portada a mao, a partir do codigo-fonte, para C.

## Online direto PS3 <-> PS3 (sem PC e sem servidor separado)
Fluxo: **Menu -> Criar sala online** sobe o servidor embutido em C dentro do proprio PS3 do anfitriao
e gera um **codigo de 7 caracteres** (ex.: `R6AAAAM`) que codifica o IPv4 do anfitriao + digito verificador.
O outro jogador escolhe **Entrar com codigo**, digita o codigo de 7 caracteres (o digito verificador valida
erros de digitacao na hora) e conecta direto no PS3 do anfitriao.

1. Em rede local (LAN): o PS3 detecta seu IP automaticamente via `netCtlGetInfo` ao iniciar. Basta criar a sala e passar o codigo.
2. Pela internet: encaminhe a porta TCP `7777` para o IP local do PS3 anfitriao no roteador e informe seu IPv4 publico em **Menu -> IP do anfitriao** (salvo em `server.txt`).

O jogo usa lockstep com atraso de 3 frames (~50 ms) sobre TCP; funciona bem em LAN e em internet estavel.
