import * as THREE from 'three'
import { RAPIER, type Physics } from '../engine/physics'

export type Dummy = { root: THREE.Group; body: RAPIER.RigidBody }
const suit = new THREE.MeshStandardMaterial({ color: '#d6a645', roughness: 0.68, metalness: 0.08 })
const trim = new THREE.MeshStandardMaterial({ color: '#39474a', roughness: 0.45, metalness: 0.38 })
const visor = new THREE.MeshStandardMaterial({ color: '#55e4de', emissive: '#1aa9a4', emissiveIntensity: 0.5, roughness: 0.22, metalness: 0.45 })
const joint = new THREE.MeshStandardMaterial({ color: '#b6b9ad', roughness: 0.5, metalness: 0.5 })
const torsoGeo = new THREE.CapsuleGeometry(0.28, 0.42, 5, 12)
const headGeo = new THREE.SphereGeometry(0.22, 16, 12)
const limbGeo = new THREE.CapsuleGeometry(0.085, 0.35, 4, 8)
const bootGeo = new THREE.BoxGeometry(0.22, 0.16, 0.32)

/** Spawnable physics target; each dummy is one articulated-looking rigid training prop. */
export class Dummies {
  readonly entries: Dummy[] = []
  constructor(private readonly physics: Physics, private readonly scene: THREE.Scene, private readonly limit = 8) {}
  get count(): number { return this.entries.length }
  get targets(): THREE.Object3D[] { return this.entries.map(entry => entry.root) }

  spawn(position: THREE.Vector3, forward: THREE.Vector3): void {
    while (this.entries.length >= this.limit) this.remove(this.entries[0])
    const at = position.clone().addScaledVector(forward, 2.15)
    at.y = Math.max(0.96, at.y)
    const root = new THREE.Group()
    root.position.copy(at)
    root.rotation.y = Math.atan2(-forward.x, -forward.z)

    const torso = new THREE.Mesh(torsoGeo, suit)
    torso.position.y = -0.05
    torso.castShadow = true
    const head = new THREE.Mesh(headGeo, trim)
    head.position.set(0, 0.48, 0)
    head.castShadow = true
    const face = new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.09, 0.035), visor)
    face.position.set(0, 0.49, -0.185)
    const chest = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.16, 0.055), trim)
    chest.position.set(0, 0.05, -0.27)
    const chestLight = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), visor)
    chestLight.position.set(0, 0.05, -0.31)
    root.add(torso, head, face, chest, chestLight)

    for (const side of [-1, 1]) {
      const arm = new THREE.Mesh(limbGeo, suit)
      arm.position.set(side * 0.37, -0.05, 0)
      arm.rotation.z = side * -0.12
      arm.castShadow = true
      root.add(arm)
      const leg = new THREE.Mesh(limbGeo, trim)
      leg.position.set(side * 0.15, -0.58, 0)
      leg.castShadow = true
      root.add(leg)
      const boot = new THREE.Mesh(bootGeo, joint)
      boot.position.set(side * 0.15, -0.82, -0.04)
      root.add(boot)
    }

    const body = this.physics.world.createRigidBody(
      RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(at.x, at.y, at.z)
        .setLinearDamping(0.24)
        .setAngularDamping(0.55)
        .setCcdEnabled(true),
    )
    this.physics.world.createCollider(RAPIER.ColliderDesc.capsule(0.5, 0.28).setFriction(0.72).setDensity(2), body)
    root.userData.physicsBody = body
    this.physics.bind(body, root)
    this.scene.add(root)
    this.entries.push({ root, body })
    body.applyImpulse({ x: forward.x * 1.6, y: 0.7, z: forward.z * 1.6 }, true)
  }

  clear(): void {
    for (const entry of [...this.entries]) this.remove(entry)
  }

  private remove(entry: Dummy): void {
    const index = this.entries.indexOf(entry)
    if (index >= 0) this.entries.splice(index, 1)
    this.scene.remove(entry.root)
    this.physics.removeBody(entry.body)
  }
}
