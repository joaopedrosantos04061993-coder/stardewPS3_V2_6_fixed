import * as THREE from 'three'
import type { PortalAnchor } from './world'

const UP = new THREE.Vector3(0, 1, 0)
const FORWARD = new THREE.Vector3(0, 0, 1)
const COLORS = ['#ff9b3d', '#45e9ff'] as const

type PortalView = { anchor: PortalAnchor; group: THREE.Group; rings: THREE.Mesh[] }
export type TeleportResult = { position: THREE.Vector3; velocity: THREE.Vector3; yaw: number }

/** Visual and traversal logic for the two linked portals. */
export class Portals {
  private views: Array<PortalView | undefined> = [undefined, undefined]

  constructor(private readonly scene: THREE.Scene) {}

  get count(): number { return this.views.filter(Boolean).length }
  get connected(): boolean { return this.count === 2 }

  place(index: 0 | 1, anchor: PortalAnchor): void {
    const other = this.views[1 - index]
    if (other?.anchor.id === anchor.id) this.remove(1 - index)
    this.remove(index)

    const color = COLORS[index]
    const group = new THREE.Group()
    group.position.copy(anchor.center).addScaledVector(anchor.normal, 0.035)
    group.quaternion.setFromUnitVectors(FORWARD, anchor.normal)
    const disc = new THREE.Mesh(
      new THREE.CircleGeometry(0.72, 48),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.52, depthWrite: false, side: THREE.DoubleSide }),
    )
    disc.scale.set(1, 1.72, 1)
    group.add(disc)

    const rimMaterial = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.35, roughness: 0.28, metalness: 0.2 })
    const outer = new THREE.Mesh(new THREE.TorusGeometry(0.76, 0.075, 12, 48), rimMaterial)
    outer.scale.y = 1.72
    const inner = new THREE.Mesh(new THREE.TorusGeometry(0.64, 0.025, 8, 48), rimMaterial.clone())
    inner.scale.y = 1.72
    group.add(outer, inner)
    this.scene.add(group)
    this.views[index] = { anchor, group, rings: [outer, inner] }
  }

  /** Walk through the source portal only when the linked destination is active. */
  cross(previous: THREE.Vector3, current: THREE.Vector3, velocity: THREE.Vector3, yaw: number): TeleportResult | null {
    if (!this.connected) return null
    for (const index of [0, 1] as const) {
      const source = this.views[index]!
      const destination = this.views[1 - index]!
      const before = previous.clone().sub(source.anchor.center).dot(source.anchor.normal)
      const after = current.clone().sub(source.anchor.center).dot(source.anchor.normal)
      if (before <= 0.02 || after > 0.02 || before - after < 1e-4) continue

      const t = THREE.MathUtils.clamp(before / (before - after), 0, 1)
      const crossing = previous.clone().lerp(current, t).sub(source.anchor.center)
      const x = crossing.dot(source.anchor.right)
      const y = crossing.y
      const halfWidth = source.anchor.width / 2 - 0.33
      const halfHeight = source.anchor.height / 2 - 0.9
      if (Math.abs(x) > halfWidth || Math.abs(y) > halfHeight) continue

      const offset = current.clone().sub(source.anchor.center)
      const localX = offset.dot(source.anchor.right)
      const localY = offset.y
      const localZ = offset.dot(source.anchor.normal)
      const position = destination.anchor.center.clone()
        .addScaledVector(destination.anchor.right, -localX)
        .addScaledVector(UP, localY)
        .addScaledVector(destination.anchor.normal, 0.42 - localZ)
      const mappedVelocity = this.mapVector(velocity, source.anchor, destination.anchor)
      const forward = this.mapVector(new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw)), source.anchor, destination.anchor)
      return { position, velocity: mappedVelocity, yaw: Math.atan2(-forward.x, -forward.z) }
    }
    return null
  }

  update(dt: number): void {
    for (const view of this.views) {
      if (!view) continue
      view.rings[0].rotation.z += dt * 0.55
      view.rings[1].rotation.z -= dt * 0.8
      const pulse = 1 + Math.sin(performance.now() * 0.002 + view.anchor.center.x) * 0.025
      view.group.scale.set(pulse, pulse, 1)
    }
  }

  reset(): void {
    this.remove(0)
    this.remove(1)
  }

  private remove(index: number): void {
    const view = this.views[index]
    if (!view) return
    this.scene.remove(view.group)
    view.group.traverse(object => {
      const mesh = object as THREE.Mesh
      if (!mesh.isMesh) return
      mesh.geometry.dispose()
      const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
      materials.forEach(material => material.dispose())
    })
    this.views[index] = undefined
  }

  private mapVector(v: THREE.Vector3, source: PortalAnchor, destination: PortalAnchor): THREE.Vector3 {
    const x = v.dot(source.right)
    const y = v.y
    const z = v.dot(source.normal)
    return destination.right.clone().multiplyScalar(-x)
      .addScaledVector(UP, y)
      .addScaledVector(destination.normal, -z)
  }
}
