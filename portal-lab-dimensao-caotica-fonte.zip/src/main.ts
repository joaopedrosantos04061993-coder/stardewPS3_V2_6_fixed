import './styles/main.css'
import { Audio } from './engine/audio'
import { Assets } from './engine/assets'
import { I18n } from './engine/i18n'
import { Input } from './engine/input'
import { GameLoop } from './engine/loop'
import { SAVE_KEY, SaveStore, type SaveData } from './engine/save'
import { assetUrl } from './game/asset-paths'
import type { Game } from './game/game'

async function boot(): Promise<void> {
  const canvas = document.querySelector<HTMLCanvasElement>('#game')!
  const firstRun = safeGet(SAVE_KEY) === null
  const save = new SaveStore()
  if (save.data.locale !== 'pt-BR') save.update({ locale: 'pt-BR' })
  const i18n = new I18n('pt-BR')
  const input = new Input(canvas)
  const audio = new Audio()
  const assets = new Assets()
  const ui = new (await import('./ui/ui')).Ui(
    i18n, save, audio, input,
    {
      play: () => startRun(),
      resume: () => resume(),
      quit: () => toTitle(),
      exit: () => ui.push('exit'),
      settings: patch => {
        const qualityChanged = patch.quality !== undefined && patch.quality !== save.data.quality
        save.update(patch)
        applySettings(save.data)
        if (qualityChanged) game?.setQuality(save.data.quality)
      },
    },
    assetUrl('assets/images/rick_and_morty_menu.jpg'),
    assetUrl('assets/share/portal_lab_favicon.png'),
  )
  let game: Game | undefined
  let loop: GameLoop | undefined
  let lockLostAt = 0

  function applySettings(data: SaveData): void {
    input.sensitivity = data.sensitivity
    input.invertY = data.invertY
    audio.setVolumes(data.musicVolume, data.sfxVolume, data.muted)
  }
  function startRun(): void {
    if (!game || !loop) return
    audio.unlock()
    audio.startMusic()
    game.start()
    ui.show('hud')
    loop.resetAccumulator()
    loop.paused = false
    if (input.method === 'keyboard') input.lockPointer()
  }
  function pause(): void {
    if (game?.mode !== 'playing') return
    game.pause()
    ui.show('pause')
    input.unlockPointer()
  }
  function resume(): void {
    if (game?.mode !== 'paused' || !loop) return
    game.resume()
    ui.show('hud')
    loop.resetAccumulator()
    loop.paused = false
    if (input.method === 'keyboard') input.lockPointer()
  }
  function toTitle(): void {
    game?.toTitle()
    ui.show('title')
    input.unlockPointer()
    if (loop) { loop.paused = true; loop.resetAccumulator() }
  }

  applySettings(save.data)
  try {
    const [{ Game: GameClass }, { Renderer, suggestQuality }, physics] = await Promise.all([
      import('./game/game'), import('./engine/renderer'), import('./engine/physics'), document.fonts.ready,
    ])
    ui.setBootProgress(0.2)
    await physics.initPhysics()
    const removeProgress = assets.onProgress(progress => ui.setBootProgress(0.2 + progress * 0.65))
    const [street, gun] = await Promise.all([
      assets.gltf(assetUrl('assets/models/alien_residential_street.glb')),
      assets.gltf(assetUrl('assets/models/portal_gun_rick_and_morty.glb')),
    ])
    removeProgress()
    ui.setBootProgress(0.9)
    if (firstRun) {
      save.update({ locale: 'pt-BR', quality: suggestQuality() })
      i18n.set('pt-BR')
      ui.refreshSettings()
    }
    const renderer = new Renderer(canvas, save.data.quality)
    game = new GameClass(renderer, input, street.scene, gun.scene)
    game.setQuality(save.data.quality)
    loop = new GameLoop({
      beforeFrame: frameSeconds => input.update(frameSeconds),
      step: dt => game?.step(dt),
      render: (alpha, frameSeconds) => {
        if (input.consume('pause')) {
          if (game?.mode === 'playing') pause()
          else if (game?.mode === 'paused' && ui.screen === 'pause' && performance.now() - lockLostAt > 300) resume()
        }
        ui.frame(frameSeconds)
        if (loop) loop.paused = game?.mode !== 'playing'
        if (game) {
          ui.updateHud(game.status())
          game.render(alpha, frameSeconds)
        }
      },
    })
    loop.paused = true
    loop.start()
    ui.setBootProgress(1)
    ui.show('title')

    document.addEventListener('pointerlockchange', () => {
      if (!document.pointerLockElement && game?.mode === 'playing' && input.method === 'keyboard') {
        lockLostAt = performance.now()
        pause()
      }
    })
    document.addEventListener('visibilitychange', () => { if (document.hidden) pause() })
    window.addEventListener('game:pause', pause)
    canvas.addEventListener('click', () => { if (game?.mode === 'playing' && input.method === 'keyboard') input.lockPointer() })
    ;(window as unknown as { __game?: unknown }).__game = { game, ui, input, save }
  } catch (error) {
    console.error(error)
    ui.showBootError(error)
  }
}

function safeGet(key: string): string | null {
  try { return localStorage.getItem(key) } catch { return null }
}

boot().catch(error => {
  console.error(error)
  const element = document.getElementById('ui')
  if (element) element.innerHTML = `<div class="fatal">Não foi possível iniciar o protótipo: ${String((error as Error)?.message ?? error).replace(/[<>&]/g, '')}</div>`
})
