# Portal Lab: Dimensão Caótica

Protótipo **Web 3D offline**, em primeira pessoa, inspirado em *Rick and Morty*. Explore um bairro alienígena, coloque dois portais em molduras de teste, atravesse-os nos dois sentidos, empurre objetos com física e invoque dummies pelo gamepad.

> **Alvo futuro desejado: PS3.** Esta entrega é um protótipo Web feito com Three.js e Rapier; não é um executável de PS3, não pode ser instalado no console e não fecha o jogo nem retorna ao XMB. A opção Exit mostra esse aviso em vez de fingir que encerrou a aplicação.

## Executar

Requisitos: Node.js compatível com o projeto e pnpm 10.18.0. O jogo não precisa de conta nem de servidor de jogo. Os assets grandes são recuperados pelo runtime gerenciado do projeto.

```bash
pnpm install
pnpm dev       # servidor Web local
pnpm test      # testes da entrada, física FPS, portais, loop, localização e saves
pnpm build     # typecheck, build e orçamento de tamanho
```

## Menu e modo de jogo

O menu oferece **Play**, **Options** e **Exit**. Play abre o sandbox; Options permite ajustar volumes, sensibilidade, inversão vertical e qualidade gráfica; Exit abre um aviso de saída simulada. Pausa e retorno ao menu principal também são locais e não encerram a aba.

| Ação | Teclado e mouse | Gamepad compatível com mapeamento padrão |
| --- | --- | --- |
| Mover / olhar | WASD / movimento do mouse com captura | Analógico esquerdo / analógico direito |
| Mirar com a Portal Gun | Botão direito | L2 |
| Disparar | Botão esquerdo | R2 |
| Instanciar um dummy | Seta ↑ | D-pad ↑ |
| Pausar | Esc ou P | Start |
| Confirmar / voltar nos menus | Enter / Esc | A / B |

O D-pad para cima também navega para cima nos menus; durante a partida ele instancia um dummy. Os dois disparos alternam entre as posições de portal A e B quando o raio atinge uma moldura. Os objetos improvisados e dummies respondem a impulsos físicos.

## Estrutura

- `src/engine/`: input de teclado/mouse/gamepad, loop fixo, Rapier, renderização, áudio, assets, localização e preferências locais.
- `src/game/player.ts`: cápsula cinemática em primeira pessoa e movimentação com colisão.
- `src/game/world.ts`: bairro, molduras de portal, superfícies atingíveis e objetos físicos.
- `src/game/portals.ts`: efeitos visuais, colocação A/B e mapeamento de posição, velocidade e orientação na travessia.
- `src/game/dummies.ts`: criação/remoção limitada de dummies físicos.
- `src/game/game.ts`: câmera FPS, arma GLB visível, mira, disparo e orquestração da simulação.
- `src/ui/` e `src/styles/`: menu, Options, pausa, HUD e aviso de saída simulada.
- `src/i18n/`: dicionários pt-BR, inglês e chinês simplificado; o primeiro uso inicia em pt-BR.
- `assets.lock.json`: mapa durável dos modelos e das imagens em Manus Storage; `scripts/manus-game-assets/` contém os auxiliares gerenciados de restauração.

## Assets e créditos

A Portal Gun e a rua alienígena são modelos GLB; a arma é anexada à câmera em primeira pessoa. O fluxo de assets recupera os bytes compatíveis com o manifesto sem substituir o validador de tamanho `scripts/check-size.mjs`. A imagem de menu é arte promocional de *Rick and Morty: The Anime* encontrada em ComicBook.com; sua origem e a ressalva sobre titularidade/licenciamento estão em [`assets/images/SOURCES.md`](assets/images/SOURCES.md). O arquivo OG é arte original do projeto sem os personagens. Os nomes e materiais de *Rick and Morty* pertencem aos respectivos titulares.

Bibliotecas: Three.js (MIT) e Rapier 3D (Apache-2.0). O áudio de interface é sintetizado localmente. O jogo não tem rede, multiplayer ou backend.
