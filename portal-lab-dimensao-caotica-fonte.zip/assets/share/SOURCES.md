# Arte de compartilhamento

`portal_lab_og.png` é a arte promocional original do projeto, gerada para Portal Lab: Dimensão Caótica sem personagens ou lettering de terceiros. `portal_lab_favicon.png` é um ícone PNG original com anéis de portal, feito para identificar este protótipo. Os arquivos são usados somente na capa de compartilhamento e favicon declarados em `game-sharing.json`.
