import { afterEach, describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { initPhysics, Physics } from '../src/engine/physics'
import { Player } from '../src/game/player'
let physics: Physics | undefined
afterEach(() => { physics?.dispose(); physics = undefined })
describe('FPS capsule movement', () => {
  it('walks over a Rapier floor and settles without falling through', async () => {
    await initPhysics()
    physics = new Physics(-22)
    physics.addStaticBox(new THREE.Vector3(0, -0.25, 0), new THREE.Vector3(24, 0.5, 24))
    const player = new Player(physics, new THREE.Vector3(0, 0.95, 0))
    for (let i = 0; i < 120; i += 1) {
      player.step(1 / 60, { moveX: 0, moveY: 1, sprint: false }, 0)
      physics.step(1 / 60)
      physics.sync(1)
    }
    expect(player.position.z).toBeLessThan(-2)
    expect(player.position.y).toBeGreaterThan(0.84)
    expect(player.position.y).toBeLessThan(0.99)
    expect(player.grounded).toBe(true)
  })
})
