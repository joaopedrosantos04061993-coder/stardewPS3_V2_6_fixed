# Relatório técnico — v2.2 Visual Update

## Objetivo e escopo

A v2.2 renova capa, tela inicial e gráficos vistos durante o gameplay. O projeto permanece em C++11/SDL2, e mantém regras de gameplay, controles, colisões e formato legado de saves.

## Alterações realizadas

A tela inicial usa nova arte de fazenda em `assets/textures/title_screen.bmp` (RGB 24-bit, 1280×720). O ícone do pacote `ICON0.PNG` mede 320×176. Os mestres PNG em 2816×1584 estão separados em `artwork/source/`, fora dos arquivos copiados para o payload instalável. Em `Game::drawMainMenu`, título/subtítulo renderizados pelo jogo, vinheta, painel translúcido, seleção destacada, mensagem, status do controle e slot ativo completam a composição.

Os gráficos de gameplay agora são gerados proceduralmente em C++ para respeitar os formatos lidos pelo jogo. `TileMap::buildProceduralTileset` gera um atlas de 24 células 32×32: índices antigos 0–19 mantêm o significado; 20–23 são variações sazonais de grama. Inclui terreno, água, pisos, árvore, cerca, rocha e objetos. `Player::buildProceduralSpritesheet` gera o personagem em atlas 128×128 (quatro direções por quatro quadros). Plantações, galinha, vaca e NPCs são desenhados com formas em camadas. Os BMPs antigos ficam no projeto como referência, mas não são carregados pelo runtime v2.2. As prévias dos atlas estão em `artwork/previews/`.

CMake e Makefile foram atualizados para v2.2.0, CONTENTID `UP0001-STDP00001_00-STARDEWPS3V22000` e nome de pacote `StardewPS3_v2_2.pkg`.

## Verificações executadas

- Testes PadInput: **63/63**; SaveSlots: **9/9**.
- `Player.cpp` e `TileMap.cpp` compilados com `-std=gnu++11 -Wall -Wextra -Wpedantic -fsyntax-only` usando mock temporário dos tipos SDL ausentes.
- Harness temporário com mock SDL executou os geradores e capturou atlas 768×32 e 128×128; as prévias foram verificadas visualmente.
- Fundo BMP, ícone e PNGs-mestres conferidos quanto a formato e dimensões.
- O ZIP `/home/ubuntu/work/StardewPS3_v2_2.zip`, já incluindo os gráficos de gameplay, os mestres e as prévias, passou em `unzip -t` sem erros. Mestres/prévias estão fora de `assets/` e não aumentam o payload de runtime copiado para o pacote PS3.

## Limitações

SDL2, CMake e o toolchain PSL1GHT não estão disponíveis nesta sessão. A aplicação completa não foi compilada nem executada no renderer SDL; não foi produzido ELF/SELF/PKG e não houve teste em PS3/HEN. O mock confirma sintaxe e geração dos dados de pixel, mas não valida blend, scaling, cor ou desempenho no console. O formato legado de save não foi alterado. O projeto é independente e não oficial.
