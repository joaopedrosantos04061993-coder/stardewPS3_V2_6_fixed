# Correções de compilação PS3 — v2.6

- `Game.cpp`: `std::to_string` (6 usos) trocado por helper `toStr` baseado em `snprintf`; o libstdc++/newlib do ps3toolchain pode não fornecer `to_string`.
- `main.cpp`: `sysModuleLoad` protegido por `#ifdef SYSMODULE_*`, pois os IDs variam entre versões do PSL1GHT.
- `Makefile.ps3`: executa `sprxlinker` no ELF após o link (necessário antes de FSELF/NPDRM); rastreia dependências de headers (`-MMD -MP`); fallback para `sfo.xml`; `EXTRA_LIBS` para dependências do SDL2_mixer; alvo `make -f Makefile.ps3 check` para validar o toolchain.
- `tests/`: adicionados mocks de SDL2/SDL_mixer/sysutil/sysmodule e `tests/syntax_check.sh`.

Verificação: checagem de sintaxe (`-fsyntax-only`, gnu++11) de todos os 8 .cpp, incluindo `Renderer.cpp`, com e sem mixer; PadInput e SaveSlots rodados; dry-run do `pkg`. Não houve build real com PSL1GHT nem teste em hardware.
