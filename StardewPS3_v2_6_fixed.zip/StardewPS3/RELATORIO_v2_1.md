# Relatório técnico — v2.1 Save Protection Update

## Escopo

A v2.1 implementa a melhoria acordada para os três slots: inspeção de cabeçalho/versão, aviso ao selecionar slot ocupado e tentativa explícita de recuperação após falha no carregamento. O formato binário da fazenda não foi alterado; o slot 1 continua sendo o save legado.

## Mudanças técnicas

- `SaveSlots::inspect` identifica arquivo ausente, cabeçalho/versão reconhecidos, cabeçalho inválido ou versão incompatível. O nome “cabeçalho reconhecido” é deliberado: a função não faz checksum nem valida todos os campos.
- `SaveSlots::copyFile` copia e compara em blocos de 4 KiB, para evitar carregar o arquivo inteiro na memória.
- `saveGame` só prossegue para truncar o arquivo principal quando não há save reconhecível ou quando consegue copiar/verificar o backup anterior. Falha na cópia interrompe o salvamento antes da abertura em modo truncado do principal.
- `loadGame` continua sendo a validação integral existente: confere assinatura, versão, leituras, estação, dimensões e quantidade/bytes dos objetos antes de aplicar o estado às entidades do jogo.
- Se o carregamento principal falhar e o backup possuir cabeçalho/versão reconhecidos, o menu solicita confirmação. A recuperação preserva temporariamente o principal, copia o backup para o caminho do slot e tenta o `loadGame` integral. Se falhar, a cópia original é restaurada; se passar, o temporário é apagado e o `.bak` continua preservado.
- Ativar slot ocupado exige confirmação. O aviso informa que o próximo salvamento pode substituir o conteúdo e que o backup anterior reconhecido será preservado quando possível. Cancelamento está disponível por O/Escape.
- Atualizados CMake, Makefile, título e CONTENTID para 2.1.

## Testes executados

- `g++ -std=gnu++11 -Wall -Wextra -Wpedantic -DSTARDEW_PS3 -Itests/mock -Iinclude src/PadInput.cpp tests/pad_test.cpp -o /tmp/pad_test_v21 && /tmp/pad_test_v21`: **63/63 verificações OK**.
- `g++ -std=gnu++11 -Wall -Wextra -Wpedantic -Iinclude src/SaveSlots.cpp tests/save_slots_test.cpp -o /tmp/save_slots_test_v21 && /tmp/save_slots_test_v21`: **9/9 verificações SaveSlots OK**. Cobre nomes e limites dos slots, cabeçalho reconhecido, cabeçalho truncado, versão incompatível, arquivo ausente e cópia de backup.

Esses testes são unitários e não exercitam a classe `Game`, o renderizador SDL, o carregamento integral de arquivos de fazenda ou falha de I/O em dispositivo PS3.

## Limitações e riscos conhecidos

- Não há CMake, headers/bibliotecas SDL2 reais nem toolchain PSL1GHT nesta sessão. A compilação integral da aplicação v2.1 e o PKG não foram realizados. Nenhum teste em PS3 Super Slim/HEN foi feito.
- `inspect` valida apenas assinatura, versão e um mínimo de conteúdo posterior ao cabeçalho. Um save truncado em campo posterior pode aparecer com “cabeçalho reconhecido”; o `loadGame` tenta detectar leituras incompletas quando é carregado.
- O formato legado não tem checksum. Alguns campos são tipos/estruturas binárias nativas; não há prova de integridade byte a byte para estados arbitrários.
- A recuperação testa o backup através do mesmo carregador existente antes de aceitar a operação. Não foi construída uma suíte de fixtures de saves completos para testar sucesso/falha dessa função de ponta a ponta.
- O carregador legado não rejeita explicitamente todo byte extra no fim e tem as mesmas limitações anteriores na validação semântica de entidades/valores.
- A cópia anterior temporária da recuperação usa sufixo `.recovery.tmp`. Se o processo/console perder energia durante a operação, o usuário pode precisar preservar/restaurar manualmente esse arquivo; não há ferramenta de recuperação pós-crash que o interprete automaticamente.
- Se a tentativa de restaurar o original temporário falhar por I/O, o jogo não pode garantir recuperação; mantenha backup externo.
- O serializador original não grava todo o estado existente em RAM. A v2.1 não muda o formato nem reconstitui dados que não eram persistidos.
- Nenhum recurso de gameplay novo, performance medida ou compatibilidade de hardware foi alegado.
