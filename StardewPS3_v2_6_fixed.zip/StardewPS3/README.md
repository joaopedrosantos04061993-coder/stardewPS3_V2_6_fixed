# Stardew PS3 — v2.6 Fazenda e calendário

Projeto independente de fazenda 2D em C++11/SDL2, preparado para PSL1GHT. **Não é o código-fonte nem um port oficial do jogo comercial Stardew Valley.** A v2.6 acrescenta rotinas simples de moradores e animais, calendário sazonal, inventário categorizado, pedidos diários com recompensa, resumo ao dormir, otimizações e novos detalhes visuais.

## Novidades v2.6

- **Moradores e animais em rotina diurna:** moradores, galinhas, vacas e ovelhas fazem pequenos deslocamentos durante o dia e retornam às posições de origem à noite. Os sprites de moradores e animais agora são pré-compostos em um atlas, reduzindo operações de desenho individuais. A arte mantém o estilo pixelado e a escala de tiles 32×32.
- **Calendário e feira sazonal:** a data e estação continuam no HUD; o painel também informa quando será a feira, realizada no último dia de cada ciclo sazonal de sete dias. Vender itens elegíveis nesse dia concede bônus de 50%.
- **Inventário por categorias:** cultivos, pesca, animais, recursos, produtos processados, sementes e refeições. Use esquerda/direita ou L1/R1 para navegar; os atalhos de ferramenta ficam bloqueados enquanto o inventário está aberto.
- **Pedido do dia:** o quadro de avisos (R2/B) informa item, quantidade, estoque disponível e recompensa. X/Enter entrega quando há itens suficientes; a solicitação fica concluída até o dia seguinte. O estado é registrado por slot em arquivo lateral temporário e substituído via rename para reduzir gravações parciais, sem modificar saves existentes.
- **Resumo diário:** ao dormir, aparece um resumo das coletas e ganhos daquele dia, além da data sazonal seguinte. Peixes, produtos animais, colheitas, vendas e recompensas entram nos totais.
- **Feedback e apresentação:** construções mostram uma mensagem específica quando faltam materiais. O cache do renderer evita chamadas redundantes de `SDL_SetRenderDrawColor` e é invalidado ao inicializar o renderer.

## Controles relevantes

- **Triângulo / I:** abrir ou fechar inventário; esquerda/direita ou L1/R1 navega categorias.
- **R2 / B:** abrir o quadro; **X / Enter** entrega o pedido do dia se houver estoque suficiente; **O / Esc** fecha.
- **SELECT / P:** loja; vender tudo. No dia 7 de cada estação, as vendas elegíveis recebem +50%.
- **D-pad para baixo:** pedir confirmação para dormir no controle; X confirma e O cancela. **E** no teclado dorme diretamente. O resumo é mostrado após o avanço do dia.

## Compatibilidade e compilação

O save binário segue na **versão 2**, com a mesma ordem e tamanho serializado da v2.5. Nenhum campo do mapa, inventário ou cabeçalho foi adicionado ao save; o pedido diário usa `daily_request_slotN.cfg`, separado por slot. Um jogo v2.5 sem esse sidecar inicia com o pedido do dia ainda não concluído. C++11, dimensões de tela 1280×720, tiles 32×32, spritesheet do jogador 128×128 e entradas de controle existentes foram mantidos.

Versão CMake: **2.6.0**. O Makefile PS3 define CONTENTID `UP0001-STDP00001_00-STARDEWPS3V26000` e nome de pacote `StardewPS3_v2_6.pkg`.

## Verificações e limitações

Nesta sessão, PadInput passou **66/66** verificações e SaveSlots **9/9**. `Game.cpp`, `Player.cpp` e `TileMap.cpp` passaram checagem sintática C++11 com mock SDL. O dry-run do Makefile confirmou título, CONTENTID e nome do PKG v2.6. Consulte [RELATORIO_v2_6.md](RELATORIO_v2_6.md) para detalhes.

SDL2, CMake e PSL1GHT não estão disponíveis neste sandbox. `Game.cpp` foi somente verificado por sintaxe com mock e `Renderer.cpp` não foi compilado; não houve build integral CMake/PS3, geração de ELF/SELF/PKG, nem teste no PS3/HEN. Os checks com mock não validam desenho, mixagem ou desempenho real no hardware. A capa e a tela inicial são criações do projeto, não assets oficiais de Stardew Valley.
