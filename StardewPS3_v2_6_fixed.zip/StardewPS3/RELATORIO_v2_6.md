# Relatório técnico — v2.6 Fazenda e calendário

## Escopo implementado

- Adicionadas pequenas rotinas de deslocamento diurno para moradores e animais; à noite, retornam às posições de origem. A animação depende de tempo visual transitório e não adiciona estado aos saves.
- Criado atlas RGBA procedural com sprites de galinha, vaca, ovelha e moradores. O desenho usa sprites pré-compostos em vez de muitos retângulos por personagem, reduzindo chamadas de desenho por ator. A escala 32×32 foi mantida e o atlas é liberado em `TileMap::shutdown()`.
- Incluído indicador de feira sazonal no HUD, com evento no dia 7 de cada ciclo de sete dias e bônus de 50% sobre vendas elegíveis nesse dia.
- Reorganizado o inventário em sete categorias: cultivos, pesca, animais, recursos, processados, sementes e refeições. L1/R1 e esquerda/direita mudam a categoria; atalhos numéricos não mudam ferramenta com o inventário aberto.
- Implementados pedidos diários determinísticos no quadro de avisos, com quantidade, item, estado de estoque e recompensa. A entrega debita itens, credita ouro e grava o estado concluído; a rotina devolve itens e ouro se a gravação não for confirmada. Uma nova solicitação fica disponível no próximo dia.
- Registrado o estado do pedido em `daily_request_slotN.cfg`, sidecar separado por slot, escrito em temporário e substituído por `rename`. O sidecar é carregado quando o save é carregado e não altera o formato binário existente. Saves legados sem sidecar começam com a solicitação atual disponível.
- Ao dormir, a interface exibe um resumo transitório com coletas e ganhos do dia. Coletas de plantações, ovos, produtos de gado e peixes, além de vendas e recompensa do pedido, contam nas estatísticas do dia.
- Construções exibem feedback específico para falta de materiais. O cache de cor do Renderer ignora chamadas `SDL_SetRenderDrawColor` redundantes e é invalidado ao iniciar o renderer. A compra em lotes de cinco impede ultrapassar o teto de 999 sementes; o carregamento não rejeita saves legados por novos limites.
- Metadados atualizados para CMake 2.6.0, CONTENTID `UP0001-STDP00001_00-STARDEWPS3V26000` e pacote `StardewPS3_v2_6.pkg`.

## Saves e compatibilidade

O cabeçalho e o formato serializado continuam na **versão 2**. A ordem e o tamanho dos campos gravados no save principal permanecem inalterados em relação à v2.5. Estado transitório de interface, contadores do dia e animação não são serializados; apenas a conclusão do pedido diário é persistida no sidecar. Compatibilidade com saves anteriores é preservada pelo caminho de carregamento existente, que não exige esse arquivo auxiliar.

## Verificações executadas

- PadInput: **66/66 verificações OK**, com backend mock PS3, cabeçalho falso `tests/mock/io/pad.h` e macros de VID/PID/pressão.
- SaveSlots: **9/9 verificações OK**.
- `Game.cpp`, `Player.cpp` e `TileMap.cpp`: checagem de sintaxe com `g++ -std=c++11 -Wall -Wextra -Wpedantic -fsyntax-only`, usando mocks SDL; sem diagnósticos. `Renderer.cpp` não foi incluído porque o mock disponível não declara a API gráfica completa.
- `make -n -f Makefile.ps3 PS3DEV=/tmp/fake-ps3dev pkg`: dry-run concluído e confirmou CONTENTID, título e nome do pacote v2.6.
- Inspeção dos fontes confirmou que a API de `updateWeather` tem sua declaração, definição e chamada atualizadas para receber o tempo do jogo.

## Limitações

SDL2, CMake e PSL1GHT/toolchain PS3 não estão disponíveis no sandbox. `Game.cpp` passou apenas checagem sintática, não compilação/linkagem completa; `Renderer.cpp` também não foi validado por sintaxe. Não houve build CMake/PS3, não foram gerados ELF/SELF/PKG, e não foi possível rodar o jogo ou verificar visualmente os recursos em hardware. O dry-run valida apenas expansão das regras Make. A confirmação final depende de build completo e teste no PS3/HEN.
