#ifndef STARDEWPS3_TILEMAP_H
#define STARDEWPS3_TILEMAP_H

#include "Renderer.h"
#include <vector>
#include <cstdint>
#include <string>

enum class Season : uint8_t {
    Spring = 0,
    Summer = 1,
    Autumn = 2,
    Winter = 3
};

enum class TileType : uint8_t {
    Grass = 0,
    Dirt = 1,
    WateredDirt = 2,
    TallGrass = 3,
    Water = 4,
    CaveFloor = 5,
    BarnFloor = 6,
    GreenhouseFloor = 7
};

enum class CropType : uint8_t {
    None = 0,
    Turnip = 1,
    Potato = 2,
    Pumpkin = 3,
    AncientFruit = 4
};

struct CropData {
    CropType type;
    int growthStage;
    bool watered;
};

struct PropObject {
    int tileX;
    int tileY;
    uint8_t type; // 0=Tree, 1=Fence, 3=Rock, 5=Sprinkler, 6=Furniture, 7=Keg, 8=Scarecrow, 9=MayonnaiseMachine, 10=CheesePress
    bool solid;
    int health;
};

struct Chicken {
    float x;
    float y;
    bool hasEgg;
};

struct Livestock {
    std::string type;
    float x;
    float y;
    bool readyToHarvest;
};

struct NPC {
    std::string name;
    float x;
    float y;
    std::string dialogue;
    int friendshipLevel;
    std::string lovedGift;
    std::string hatedGift;
};

struct WeatherParticle {
    float x;
    float y;
    float speedY;
    float speedX;
};

class TileMap {
public:
    static const int TILE_SIZE = 32;

    TileMap();
    ~TileMap();

    bool initTextures(Renderer& renderer);
    void shutdown();

    void generateInitialFarm(int widthInTiles, int heightInTiles);
    void render(Renderer& renderer, const Camera2D& camera, Season season, bool isRaining) const;
    void updateWeather(float deltaTime, int screenW, int screenH, const Camera2D& camera, int timeOfDayMinutes);

    TileType getTileAt(int tileX, int tileY) const;
    void setTileAt(int tileX, int tileY, TileType type);

    CropData getCropAt(int tileX, int tileY) const;
    bool hasCropAt(int tileX, int tileY) const;
    
    bool hoeTile(int tileX, int tileY);
    bool waterTile(int tileX, int tileY);
    bool isCropPlantableInSeason(int tileX, int tileY, CropType cropType, Season season) const;
    bool plantCrop(int tileX, int tileY, CropType cropType, Season season);
    bool harvestCrop(int tileX, int tileY, CropType& outHarvestedType);
    bool chopProp(int tileX, int tileY);
    bool mineRock(int tileX, int tileY, int mineDepth, int& outOreType);
    bool placeFence(int tileX, int tileY);
    bool placeSprinkler(int tileX, int tileY);
    bool placeFurniture(int tileX, int tileY);
    bool placeKeg(int tileX, int tileY);
    bool placeScarecrow(int tileX, int tileY);
    bool placeMayonnaiseMachine(int tileX, int tileY);
    bool placeCheesePress(int tileX, int tileY);
    bool collectEgg(int tileX, int tileY);
    bool interactLivestock(int tileX, int tileY, std::string& outProduct);
    bool giveGiftToNPC(int tileX, int tileY, std::string giftName, std::string& outResponse);

    void nextDay(bool isRaining, Season season);

    bool checkCollision(float worldX, float worldY, float boxW, float boxH) const;
    bool isTileBlocked(int tileX, int tileY) const;

    int getWidthInTiles() const { return m_width; }
    int getHeightInTiles() const { return m_height; }
    int getPixelWidth() const { return m_width * TILE_SIZE; }
    int getPixelHeight() const { return m_height * TILE_SIZE; }

    std::vector<Chicken>& getChickens() { return m_chickens; }
    std::vector<Livestock>& getLivestock() { return m_livestock; }
    std::vector<NPC>& getNPCs() { return m_npcs; }
    std::vector<TileType>& getTilesRef() { return m_tiles; }
    std::vector<CropData>& getCropsRef() { return m_crops; }
    std::vector<PropObject>& getPropsRef() { return m_props; }

private:
    void buildProceduralTileset(Renderer& renderer);
    void buildActorAtlas(Renderer& renderer);

    struct ActorHome { float x; float y; };

    int m_width;
    int m_height;
    std::vector<TileType> m_tiles;
    std::vector<CropData> m_crops;
    std::vector<PropObject> m_props;
    std::vector<Chicken> m_chickens;
    std::vector<Livestock> m_livestock;
    std::vector<NPC> m_npcs;
    std::vector<WeatherParticle> m_weatherParticles;
    SDL_Texture* m_tilesetTexture;
    SDL_Texture* m_actorTexture;
    std::vector<ActorHome> m_chickenHomes;
    std::vector<ActorHome> m_livestockHomes;
    std::vector<ActorHome> m_npcHomes;
    float m_visualTime;
};

#endif // STARDEWPS3_TILEMAP_H
