#ifndef STARDEWPS3_SAVESLOTS_H
#define STARDEWPS3_SAVESLOTS_H

#include <string>

namespace SaveSlots {
static const int COUNT = 3;
enum class FileStatus { Missing, ValidHeader, InvalidHeader, UnsupportedVersion };
bool valid(int slot);
std::string fileName(int slot);
std::string backupFileName(int slot);
FileStatus inspect(const std::string& path, const char magic[8], int version);
bool copyFile(const std::string& source, const std::string& destination);
}

#endif
