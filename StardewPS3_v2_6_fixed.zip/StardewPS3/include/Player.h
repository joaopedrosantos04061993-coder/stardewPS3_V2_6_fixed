#ifndef STARDEWPS3_PLAYER_H
#define STARDEWPS3_PLAYER_H

#include "Renderer.h"
#include "TileMap.h"
#include <cstdint>

enum class Direction : uint8_t {
    Down = 0,
    Up = 1,
    Left = 2,
    Right = 3
};

enum class ToolType : uint8_t {
    Hoe = 0,
    WateringCan = 1,
    Axe = 2,
    Pickaxe = 3,
    FishingRod = 4,
    TurnipSeeds = 5,
    PotatoSeeds = 6,
    PumpkinSeeds = 7,
    FenceBuild = 8,
    SprinklerBuild = 9,
    FurnitureBuild = 10,
    KegBuild = 11,
    ScarecrowBuild = 12,
    MayoBuild = 13,
    CheeseBuild = 14,
    Hand = 15
};

struct AnimationState {
    Direction facing;
    int currentFrame;
    int maxFrames;
    float frameTimer;
    float frameDuration;
    bool isMoving;
};

class Player {
public:
    static const int SPRITE_WIDTH = 32;
    static const int SPRITE_HEIGHT = 32;

    Player();
    ~Player();

    bool initTextures(Renderer& renderer);
    void shutdown();

    void setPosition(float x, float y);
    void setInputDirection(float dirX, float dirY);
    void setFacingDirection(Direction dir);
    void triggerActionVisual();

    void setSelectedTool(ToolType tool);
    ToolType getSelectedTool() const { return m_selectedTool; }
    bool isMoving() const { return m_anim.isMoving; }
    void cycleTool();
    void cycleToolPrev();

    void update(float deltaTime, const TileMap& map);
    void render(Renderer& renderer, const Camera2D& camera) const;

    float getX() const { return m_x; }
    float getY() const { return m_y; }
    float getCenterX() const { return m_x + (SPRITE_WIDTH * 0.5f); }
    float getCenterY() const { return m_y + (SPRITE_HEIGHT * 0.5f); }
    Direction getFacingDirection() const { return m_anim.facing; }

    void getFacingTile(int& outTileX, int& outTileY) const;

private:
    void updateAnimation(float deltaTime);
    void buildProceduralSpritesheet(Renderer& renderer);

    float m_x;
    float m_y;
    float m_inputX;
    float m_inputY;
    float m_speed;
    float m_actionTimer;
    ToolType m_selectedTool;
    AnimationState m_anim;
    SDL_Texture* m_spriteSheet;
};

#endif // STARDEWPS3_PLAYER_H
