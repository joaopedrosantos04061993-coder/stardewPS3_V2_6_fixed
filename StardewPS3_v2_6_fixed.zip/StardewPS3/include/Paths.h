#ifndef STARDEWPS3_PATHS_H
#define STARDEWPS3_PATHS_H

#include <string>

// Resolve caminhos de assets e saves.
// No PS3 o diretório base é o USRDIR do app (derivado de argv[0]); no PC é o diretório atual.
namespace Paths {
void init(const char* argv0);
std::string resource(const std::string& relative);   // ex.: "assets/textures/player.bmp"
std::string saveFile(const std::string& name);       // ex.: "save_v1.6.dat"
void ensureSaveDir();
}

#endif
