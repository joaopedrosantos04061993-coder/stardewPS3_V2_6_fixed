#ifndef STARDEWPS3_RENDERER_H
#define STARDEWPS3_RENDERER_H

#include <SDL.h>
#include <cstdint>
#include <string>
#include "Platform.h"

struct Camera2D {
    float x;
    float y;
    int viewportWidth;
    int viewportHeight;
};

class Renderer {
public:
    Renderer();
    ~Renderer();

    bool init(const char* title, int width, int height);
    void shutdown();

    void clear(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);
    void present();

    SDL_Texture* loadTextureBMP(const std::string& path, bool useColorKey = true,
                                uint8_t keyR = 255, uint8_t keyG = 0, uint8_t keyB = 255);

    SDL_Texture* createTextureFromRGBA(const uint32_t* pixels, int width, int height);

    void drawSprite(SDL_Texture* texture, const Camera2D& camera,
                    int srcX, int srcY, int srcW, int srcH,
                    float worldX, float worldY, float dstW, float dstH);

    void drawWorldRect(const Camera2D& camera, float worldX, float worldY, float w, float h,
                       uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);

    void drawWorldRectOutline(const Camera2D& camera, float worldX, float worldY, float w, float h,
                              uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);

    void drawScreenRect(int x, int y, int w, int h,
                        uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);

    void drawScreenRectOutline(int x, int y, int w, int h,
                               uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);

    void drawLightingOverlay(float intensity, uint8_t r, uint8_t g, uint8_t b);

    // Texto (fonte bitmap embutida em Font.h). Aceita UTF-8 com acentos do português.
    bool initFont();
    int textWidth(const std::string& text, int scale = 1) const;
    void drawText(const std::string& text, int x, int y, int scale,
                  uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255);
    void drawTextShadow(const std::string& text, int x, int y, int scale,
                        uint8_t r, uint8_t g, uint8_t b);
    void drawTextCentered(const std::string& text, int centerX, int y, int scale,
                          uint8_t r, uint8_t g, uint8_t b);
    void drawFullscreenTexture(SDL_Texture* texture);

    void windowToLogical(int winX, int winY, int& logicalX, int& logicalY) const;

    SDL_Renderer* getNativeRenderer() const { return m_renderer; }
    int getWidth() const { return m_width; }
    int getHeight() const { return m_height; }

private:
    SDL_Window* m_window;
    SDL_Renderer* m_renderer;
    int glyphFor(uint32_t codepoint) const;
    void setDrawColor(uint8_t r, uint8_t g, uint8_t b, uint8_t a);

    int m_width;
    int m_height;
    SDL_Texture* m_fontTexture;
    int m_glyphForLatin1[256];
    uint8_t m_drawR, m_drawG, m_drawB, m_drawA;
    bool m_drawColorCacheValid;
};

#endif // STARDEWPS3_RENDERER_H
