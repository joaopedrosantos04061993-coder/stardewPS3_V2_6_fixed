#ifndef STARDEWPS3_GAME_H
#define STARDEWPS3_GAME_H

#include "Renderer.h"
#include "TileMap.h"
#include "Player.h"
#include "PadInput.h"
#include <SDL.h>
#ifdef HAVE_SDL_MIXER
#include <SDL_mixer.h>
#endif
#include <array>
#include <string>
#include <vector>

enum class GameState {
    MainMenu = 0,
    Playing = 1
};

class Game {
public:
    Game();
    ~Game();

    bool init();
    void run();
    void shutdown();

private:
    void processEvents();
    void flushPadLog();
    void onPadButton(PadButton button);
    void onMenuConfirm();
    bool anyOverlayOpen() const;
    void closeTopOverlay();
    void update(float deltaTime);
    void render();
    void handleToolAction(int targetTileX, int targetTileY);
    void talkOrCareAtTarget();

    void drawMainMenu();
    void drawSettingsMenu();
    void drawSaveSlotsMenu();
    void drawRecoveryPrompt();
    bool restoreCurrentBackup();
    void loadSettings();
    void saveSettings();
    void drawHUD();
    void drawQuickbar();
    void drawControlsHint();
    void drawDialogueBox();
    void drawInventoryMenu();
    void drawShopMenu();
    void drawBulletinBoard();
    void drawMineLevelSelector();
    void drawAchievementsOverlay();
    void drawQuestJournal();
    void drawFishingMinigame();
    void drawPanel(int x, int y, int w, int h, const std::string& title);

    void updateFishingMinigame(float dt);
    void cookMeal();
    void sleepInBed();
    void sellAll();
    void buyShopItem(int item);
    void deliverDailyRequest();
    int dailyRequestItemIndex() const;
    int dailyRequestQuantity() const;
    std::string dailyRequestItemName() const;
    bool saveDailyRequestState() const;
    void loadDailyRequestState();
    void processArtisanMachines();
    void checkAchievements();
    bool saveGame();
    bool loadGame();
    void playSoundEffect(int soundId);
    void playMusic(const std::string& musicPath);

    std::array<int*, 20> inventoryRefs();

    bool m_isRunning;
    GameState m_gameState;
    int m_mainMenuSelection; // 0=Novo/Continuar, 1=Carregar slot, 2=Selecionar slot, 3=Configurações, 4=Sair
    bool m_showSettings;
    bool m_showSaveSlots;
    bool m_showRecoveryPrompt;
    bool m_confirmSlotUse;
    int m_slotCandidate;
    int m_saveSlot;
    int m_slotSelection;
    int m_settingsSelection;
    float m_stickDeadzone, m_stickSensitivity;
    int m_musicVolume;
    int m_shopSelection;
    int m_inventoryCategory;
    bool m_hasStarted;
    std::string m_menuMessage;

    bool m_showInventoryMenu;
    bool m_showShopMenu;
    bool m_showBulletinBoard;
    bool m_showMineMenu;
    bool m_showAchievements;
    bool m_showQuestJournal;
    bool m_isFishingActive;
    bool m_isRaining;
    Season m_currentSeason;
    std::string m_activeDialogue;
    std::string m_farmName;
    int m_dayCount;
    int m_dayOfSeason;
    int m_timeOfDayMinutes; // 600 = 6:00, 2400 = 24:00 (base 100 por hora)
    int m_mineDepth;
    int m_money;
    float m_stamina;
    float m_maxStamina;
    float m_stepSoundTimer;
    float m_actionFeedbackTimer;
    std::string m_actionFeedback;
    bool m_dailyRequestClaimed;
    int m_dailyHarvestCount;
    int m_dailyEarnings;

    // Fishing minigame state
    float m_fishPos;
    float m_barPos;
    float m_barVelocity;
    float m_catchProgress;
    bool m_fishHooked;

    int m_farmingLevel;
    int m_miningLevel;
    int m_fishingLevel;
    int m_forageLevel;

    int m_inventoryTurnips;
    int m_inventoryPotatoes;
    int m_inventoryPumpkins;
    int m_inventoryFish;
    int m_inventoryEggs;
    int m_inventoryMilk;
    int m_inventoryWool;
    int m_inventoryMayonnaise;
    int m_inventoryCheese;
    int m_inventoryWood;
    int m_inventoryCopperOre;
    int m_inventoryIronOre;
    int m_inventoryGoldOre;
    int m_inventoryIridiumOre;
    int m_inventoryJelly;
    int m_inventoryWine;
    int m_inventoryTurnipSeeds;
    int m_inventoryPotatoSeeds;
    int m_inventoryPumpkinSeeds;
    int m_inventoryMeals;

    bool m_achievementMillionaire;
    bool m_achievementMasterFarmer;
    bool m_achievementDeepMiner;

    Renderer m_renderer;
    TileMap m_tileMap;
    Player m_player;
    Camera2D m_camera;
    SDL_Texture* m_coverTexture;

    SDL_GameController* m_gameController;
    SDL_Joystick* m_joystick;
    float m_keyDirX;
    float m_keyDirY;
    PadInput m_pad;          // leitura nativa (libio) no PS3: DualShock 3/4 originais e paralelos

#ifdef HAVE_SDL_MIXER
    Mix_Chunk* m_sfxStep;
    Mix_Chunk* m_sfxAction;
    Mix_Chunk* m_sfxHarvest;
    Mix_Chunk* m_sfxSleep;
    Mix_Chunk* m_sfxFishBite;
    Mix_Chunk* m_sfxWater;
    Mix_Chunk* m_sfxPlant;
    Mix_Chunk* m_sfxTool;
    Mix_Music* m_bgmMusic;
#endif
};

#endif // STARDEWPS3_GAME_H
