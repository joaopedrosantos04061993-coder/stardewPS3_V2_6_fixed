#ifndef STARDEWPS3_PLATFORM_H
#define STARDEWPS3_PLATFORM_H

// Detecta o build para PS3 (PSL1GHT). O Makefile.ps3 define STARDEW_PS3.
#if defined(STARDEW_PS3) || defined(__PS3__) || defined(__CELLOS_LV2__)
#define STARDEW_ON_PS3 1
#endif

namespace Screen {
const int WIDTH = 1280;   // 720p
const int HEIGHT = 720;
}

#endif
