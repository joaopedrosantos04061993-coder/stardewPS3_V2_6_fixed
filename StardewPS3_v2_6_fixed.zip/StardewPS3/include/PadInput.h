#ifndef STARDEWPS3_PADINPUT_H
#define STARDEWPS3_PADINPUT_H

#include <cstdint>
#include <deque>
#include <memory>
#include <string>
#include <vector>

// Botões lógicos do controle (layout DualShock). Todas as fontes de entrada de controle
// (API nativa do PS3, SDL_GameController, SDL_Joystick) são convertidas para estes valores.
enum class PadButton {
    Cross, Circle, Square, Triangle,
    Start, Select,
    L1, R1, L2, R2, L3, R3,
    Up, Down, Left, Right,
    Count
};

enum class PadKind { Unknown, DualShock3, DualShock4, Generic };

// Estado cru de uma porta, já independente da API usada para ler.
struct PadRawData {
    bool valid;                       // false = sem dados novos neste quadro
    bool btn[static_cast<int>(PadButton::Count)];
    uint8_t lx, ly, rx, ry;           // 0..255, centro nominal 128
    PadRawData();
};

// Backend de leitura (PS3 libio em produção; falso/mock nos testes de PC).
class PadBackend {
public:
    virtual ~PadBackend() {}
    virtual bool init() = 0;          // false = backend indisponível
    virtual void shutdown() = 0;
    virtual int maxPorts() const = 0;
    virtual bool refresh() = 0;       // atualiza a lista de portas (1x por quadro)
    virtual bool portInfo(int port, bool& connected, uint16_t& vendorId, uint16_t& productId) = 0;
    virtual bool portData(int port, PadRawData& out) = 0;
};

struct PadPortInfo {
    bool connected;
    PadKind kind;
    uint16_t vendorId, productId;
    PadPortInfo() : connected(false), kind(PadKind::Unknown), vendorId(0), productId(0) {}
};

class PadInput {
public:
    static const int MAX_PORTS = 7;

    PadInput();
    ~PadInput();

    void setDeadzone(float value);     // 0.05..0.50
    float deadzone() const { return m_deadzone; }
    void setSensitivity(float value);  // 0.50..1.50
    float sensitivity() const { return m_sensitivity; }

    // Usa o backend nativo do PS3 (libio: ioPadInit/ioPadGetInfo/ioPadGetData). Retorna false
    // fora do PS3 ou se a libio não puder ser inicializada (o jogo então cai para SDL).
    bool init();
    // Injeta um backend (usado nos testes).
    bool initWithBackend(std::unique_ptr<PadBackend> backend);
    void shutdown();

    bool active() const { return m_backend != nullptr; }

    // Chamar 1x por quadro. Detecta conexão/desconexão, calibra analógicos e gera eventos.
    void poll();
    // Próximo botão recém-pressionado (borda de subida). false = fila vazia.
    bool popPress(PadButton& out);

    bool held(PadButton b) const { return m_held[static_cast<int>(b)]; }
    // Analógicos já com zona morta, -1..1 (y positivo = para baixo). Mescla todas as portas.
    float leftX() const { return m_lx; }
    float leftY() const { return m_ly; }
    float rightX() const { return m_rx; }
    float rightY() const { return m_ry; }

    int connectedCount() const;
    const PadPortInfo& port(int i) const { return m_ports[i].info; }
    // Texto curto para a UI, ex.: "DualShock 4 (054C:05C4)" ou "nenhum detectado".
    std::string statusLine() const;
    // Linhas de log novas (conexão/desconexão/tipo). Esvazia ao ler.
    std::vector<std::string> takeLogLines();

    static PadKind classify(uint16_t vendorId, uint16_t productId);
    static const char* kindName(PadKind k);

private:
    struct Port {
        PadPortInfo info;
        int warmup;                       // quadros restantes de calibração
        float sumLX, sumLY, sumRX, sumRY; // acumulado durante a calibração
        float cLX, cLY, cRX, cRY;         // centros calibrados
        bool btn[static_cast<int>(PadButton::Count)];
        float lx, ly, rx, ry;
        Port();
    };

    static float normalize(uint8_t raw, float center);
    static void applyDeadzone(float& x, float& y, float deadzone, float sensitivity);
    void onConnect(int i);
    void onDisconnect(int i);
    void log(const std::string& line);

    std::unique_ptr<PadBackend> m_backend;
    Port m_ports[MAX_PORTS];
    bool m_held[static_cast<int>(PadButton::Count)];
    float m_lx, m_ly, m_rx, m_ry;
    float m_deadzone, m_sensitivity;
    std::deque<PadButton> m_events;
    std::vector<std::string> m_log;
};

#endif // STARDEWPS3_PADINPUT_H
