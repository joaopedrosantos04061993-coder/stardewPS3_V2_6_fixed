#include "Paths.h"
#include "Platform.h"
#ifdef STARDEW_ON_PS3
#include <sys/stat.h>
#endif

namespace {
#ifdef STARDEW_ON_PS3
std::string g_base = "/dev_hdd0/game/STDP00001/USRDIR";
#else
std::string g_base = ".";
#endif
}

namespace Paths {

void init(const char* argv0) {
#ifdef STARDEW_ON_PS3
    if (argv0) {
        std::string p(argv0);
        std::string::size_type slash = p.find_last_of('/');
        // argv[0] no PS3 costuma ser /dev_hdd0/game/<ID>/USRDIR/EBOOT.BIN
        if (slash != std::string::npos && p.compare(0, 5, "/dev_") == 0) g_base = p.substr(0, slash);
    }
#else
    (void)argv0;
#endif
}

std::string resource(const std::string& relative) { return g_base + "/" + relative; }

std::string saveFile(const std::string& name) {
#ifdef STARDEW_ON_PS3
    return g_base + "/saves/" + name;
#else
    return name;
#endif
}

void ensureSaveDir() {
#ifdef STARDEW_ON_PS3
    mkdir((g_base + "/saves").c_str(), 0777);   // ignora erro se já existir
#endif
}

}
