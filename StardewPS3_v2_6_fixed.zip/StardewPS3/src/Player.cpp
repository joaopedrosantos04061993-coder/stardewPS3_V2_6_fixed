#include "Player.h"
#include "Paths.h"
#include <cmath>
#include <vector>
#include <cstdio>

namespace {
    inline uint32_t packRGBA(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) {
        return (static_cast<uint32_t>(r) << 24) |
               (static_cast<uint32_t>(g) << 16) |
               (static_cast<uint32_t>(b) << 8)  |
               static_cast<uint32_t>(a);
    }
}

Player::Player()
    : m_x(0.0f), m_y(0.0f), m_inputX(0.0f), m_inputY(0.0f),
      m_speed(160.0f), m_actionTimer(0.0f), m_selectedTool(ToolType::Hoe),
      m_spriteSheet(nullptr) {
    m_anim.facing = Direction::Down;
    m_anim.currentFrame = 0;
    m_anim.maxFrames = 4;
    m_anim.frameTimer = 0.0f;
    m_anim.frameDuration = 0.13f;
    m_anim.isMoving = false;
}

Player::~Player() { shutdown(); }

bool Player::initTextures(Renderer& renderer) {
    shutdown();
    // Sprite procedural v2.2: atlas 4x4 de 32px, independente de filtro de scaling do SDL.
    buildProceduralSpritesheet(renderer);
    return (m_spriteSheet != nullptr);
}

void Player::shutdown() {
    if (m_spriteSheet) { SDL_DestroyTexture(m_spriteSheet); m_spriteSheet = nullptr; }
}

void Player::buildProceduralSpritesheet(Renderer& renderer) {
    const int sheetW = 128;
    const int sheetH = 128;
    std::vector<uint32_t> pixels(sheetW * sheetH, packRGBA(0, 0, 0, 0));

    auto fillRect = [&](int dirRow, int frameCol, int rx, int ry, int rw, int rh, uint32_t color) {
        int baseX = frameCol * 32;
        int baseY = dirRow * 32;
        for (int y = ry; y < ry + rh; ++y) {
            for (int x = rx; x < rx + rw; ++x) {
                if (x >= 0 && x < 32 && y >= 0 && y < 32) {
                    pixels[(baseY + y) * sheetW + (baseX + x)] = color;
                }
            }
        }
    };

    const uint32_t shadow = packRGBA(21, 33, 23, 130);
    const uint32_t straw = packRGBA(222, 177, 76);
    const uint32_t strawLight = packRGBA(249, 215, 126);
    const uint32_t strawShade = packRGBA(159, 111, 49);
    const uint32_t skin = packRGBA(235, 179, 132);
    const uint32_t skinLight = packRGBA(255, 213, 164);
    const uint32_t hair = packRGBA(88, 55, 37);
    const uint32_t hairLight = packRGBA(126, 78, 44);
    const uint32_t shirt = packRGBA(72, 142, 170);
    const uint32_t shirtLight = packRGBA(112, 184, 198);
    const uint32_t denim = packRGBA(47, 82, 132);
    const uint32_t denimLight = packRGBA(75, 117, 165);
    const uint32_t boots = packRGBA(82, 50, 35);
    const uint32_t outline = packRGBA(49, 42, 36);

    for (int dir = 0; dir < 4; ++dir) {
        for (int frame = 0; frame < 4; ++frame) {
            const int bob = (frame == 1 || frame == 3) ? -1 : 0;
            const int strideL = frame == 1 ? -2 : (frame == 3 ? 2 : 0);
            const int strideR = -strideL;
            auto R = [&](int x, int y, int w, int h, uint32_t c) { fillRect(dir, frame, x, y + bob, w, h, c); };

            // Boot silhouette and two-step gait.
            R(7, 27, 18, 3, shadow);
            R(10 + strideL, 23, 5, 5, denim); R(17 + strideR, 23, 5, 5, denim);
            R(9 + strideL, 27, 6, 2, boots); R(17 + strideR, 27, 6, 2, boots);
            R(10 + strideL, 27, 3, 1, packRGBA(153, 111, 71));
            R(18 + strideR, 27, 3, 1, packRGBA(153, 111, 71));

            // Torso, sleeves and overall straps.
            R(8, 15, 16, 9, shirt); R(9, 16, 14, 2, shirtLight);
            R(6, 16, 4, 7, shirt); R(22, 16, 4, 7, shirt);
            R(10, 20, 12, 5, denim); R(10, 19, 3, 6, denimLight); R(19, 19, 3, 6, denimLight);
            R(11, 19, 2, 4, packRGBA(203, 173, 93)); R(19, 19, 2, 4, packRGBA(203, 173, 93));

            // Head and hair silhouette differ by facing direction.
            if (dir == static_cast<int>(Direction::Down)) {
                R(10, 7, 12, 10, skin); R(11, 8, 10, 3, skinLight);
                R(9, 7, 2, 8, hair); R(21, 7, 2, 8, hair);
                R(12, 12, 2, 2, outline); R(19, 12, 2, 2, outline);
                R(15, 15, 3, 1, packRGBA(168, 91, 72));
            } else if (dir == static_cast<int>(Direction::Up)) {
                R(10, 7, 12, 10, hair); R(11, 9, 10, 7, hairLight);
                R(9, 7, 3, 8, hair); R(20, 7, 3, 8, hair);
            } else {
                R(10, 7, 12, 10, skin); R(dir == static_cast<int>(Direction::Right) ? 16 : 10, 8, 5, 4, skinLight);
                R(9, 6, 4, 9, hair); R(19, 6, 4, 9, hair);
                R(dir == static_cast<int>(Direction::Right) ? 20 : 11, 12, 2, 2, outline);
                R(dir == static_cast<int>(Direction::Right) ? 9 : 21, 11, 3, 3, packRGBA(205, 143, 103));
            }

            // Straw hat with dark band and bright pixel highlight.
            R(8, 4, 16, 4, straw); R(5, 6, 22, 3, strawLight);
            R(8, 7, 16, 2, strawShade); R(10, 4, 12, 1, strawLight);
            R(13, 7, 6, 1, packRGBA(124, 83, 44));
        }
    }
    m_spriteSheet = renderer.createTextureFromRGBA(pixels.data(), sheetW, sheetH);
}

void Player::setPosition(float x, float y) { m_x = x; m_y = y; }
void Player::setInputDirection(float dirX, float dirY) { m_inputX = dirX; m_inputY = dirY; }
void Player::setFacingDirection(Direction dir) { m_anim.facing = dir; }
void Player::setSelectedTool(ToolType tool) { m_selectedTool = tool; }
void Player::cycleTool() {
    int t = static_cast<int>(m_selectedTool);
    t = (t + 1) % 16;
    m_selectedTool = static_cast<ToolType>(t);
}

void Player::cycleToolPrev() {
    int t = static_cast<int>(m_selectedTool);
    t = (t + 15) % 16;
    m_selectedTool = static_cast<ToolType>(t);
}

void Player::triggerActionVisual() { m_actionTimer = 0.18f; }

void Player::getFacingTile(int& outTileX, int& outTileY) const {
    outTileX = static_cast<int>(std::floor(getCenterX() / TileMap::TILE_SIZE));
    outTileY = static_cast<int>(std::floor(getCenterY() / TileMap::TILE_SIZE));
    switch (m_anim.facing) {
        case Direction::Down:  outTileY += 1; break;
        case Direction::Up:    outTileY -= 1; break;
        case Direction::Left:  outTileX -= 1; break;
        case Direction::Right: outTileX += 1; break;
    }
}

void Player::update(float deltaTime, const TileMap& map) {
    if (m_actionTimer > 0.0f) m_actionTimer -= deltaTime;
    float len = std::sqrt(m_inputX * m_inputX + m_inputY * m_inputY);
    if (len > 1.0f) { m_inputX /= len; m_inputY /= len; }
    m_anim.isMoving = (len > 0.05f);

    if (m_anim.isMoving) {
        if (std::fabs(m_inputX) > std::fabs(m_inputY)) {
            m_anim.facing = (m_inputX > 0.0f) ? Direction::Right : Direction::Left;
        } else {
            m_anim.facing = (m_inputY > 0.0f) ? Direction::Down : Direction::Up;
        }
        float nx = m_x + m_inputX * m_speed * deltaTime;
        if (!map.checkCollision(nx + 6.0f, m_y + 16.0f, 20.0f, 14.0f)) m_x = nx;
        float ny = m_y + m_inputY * m_speed * deltaTime;
        if (!map.checkCollision(m_x + 6.0f, ny + 16.0f, 20.0f, 14.0f)) m_y = ny;
    }
    updateAnimation(deltaTime);
}

void Player::updateAnimation(float deltaTime) {
    if (!m_anim.isMoving) { m_anim.currentFrame = 0; m_anim.frameTimer = 0.0f; return; }
    m_anim.frameTimer += deltaTime;
    if (m_anim.frameTimer >= m_anim.frameDuration) {
        m_anim.frameTimer -= m_anim.frameDuration;
        m_anim.currentFrame = (m_anim.currentFrame + 1) % m_anim.maxFrames;
    }
}

void Player::render(Renderer& renderer, const Camera2D& camera) const {
    if (m_spriteSheet) {
        int srcX = m_anim.currentFrame * SPRITE_WIDTH;
        int srcY = static_cast<int>(m_anim.facing) * SPRITE_HEIGHT;
        renderer.drawSprite(m_spriteSheet, camera, srcX, srcY, SPRITE_WIDTH, SPRITE_HEIGHT, m_x, m_y, SPRITE_WIDTH, SPRITE_HEIGHT);
    }
    if (m_actionTimer > 0.0f) {
        const float swing = (m_actionTimer < 0.09f) ? 1.0f : 0.0f;
        float tx = m_x + 20.0f, ty = m_y + 3.0f;
        if (m_anim.facing == Direction::Down) { tx = m_x + 20.0f + swing * 3.0f; ty = m_y + 25.0f; }
        else if (m_anim.facing == Direction::Up) { tx = m_x + 8.0f - swing * 2.0f; ty = m_y - 2.0f; }
        else if (m_anim.facing == Direction::Left) { tx = m_x - 3.0f; ty = m_y + 14.0f + swing * 2.0f; }
        else { tx = m_x + 27.0f; ty = m_y + 12.0f - swing * 2.0f; }

        uint8_t r = 186, g = 137, b = 75;
        if (m_selectedTool == ToolType::WateringCan) { r = 83; g = 174; b = 218; }
        else if (m_selectedTool == ToolType::Axe || m_selectedTool == ToolType::Pickaxe) { r = 165; g = 177; b = 190; }
        else if (m_selectedTool == ToolType::TurnipSeeds || m_selectedTool == ToolType::PotatoSeeds || m_selectedTool == ToolType::PumpkinSeeds) { r = 111; g = 195; b = 93; }
        else if (m_selectedTool == ToolType::Hand) { r = 239; g = 190; b = 151; }

        if (m_anim.facing == Direction::Down || m_anim.facing == Direction::Up) {
            renderer.drawWorldRect(camera, tx, ty, 3.0f, 9.0f, 113, 77, 43);
            renderer.drawWorldRect(camera, tx - 2.0f, ty + (m_anim.facing == Direction::Down ? 6.0f : 1.0f), 8.0f, 4.0f, r, g, b);
            if (m_selectedTool == ToolType::WateringCan) renderer.drawWorldRect(camera, tx + 5.0f, ty + 7.0f, 2.0f, 3.0f, 139, 212, 241, 190);
        } else {
            renderer.drawWorldRect(camera, tx, ty, 9.0f, 3.0f, 113, 77, 43);
            renderer.drawWorldRect(camera, tx + (m_anim.facing == Direction::Right ? 5.0f : 0.0f), ty - 2.0f, 4.0f, 8.0f, r, g, b);
            if (m_selectedTool == ToolType::WateringCan) renderer.drawWorldRect(camera, tx + 7.0f, ty + 3.0f, 3.0f, 2.0f, 139, 212, 241, 190);
        }
    }
}
