#include "Game.h"
#include "Paths.h"
#include "Platform.h"
#include "SaveSlots.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <string>
#ifdef STARDEW_ON_PS3
#include <sysutil/sysutil.h>
#endif

namespace {

// std::to_string pode não existir no libstdc++/newlib do ps3toolchain; usa snprintf.
std::string toStr(int v) {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "%d", v);
    return std::string(buf);
}

const int SCREEN_W = Screen::WIDTH;
const int SCREEN_H = Screen::HEIGHT;

#ifdef STARDEW_ON_PS3
volatile bool g_ps3ExitRequested = false;

// Callback do XMB: recebe o pedido de saída do jogo (botão PS -> "Sair do jogo").
void ps3SysutilCallback(u64 status, u64 param, void* userdata) {
    (void)param; (void)userdata;
    if (status == SYSUTIL_EXIT_GAME) g_ps3ExitRequested = true;
}
#endif

// Ordem dos botões do DualShock 3 vista pelo SDL_Joystick (layout cru do hardware).
// Se no seu port do SDL2 a ordem for outra, ajuste só esta tabela.
const PadButton JOY_BUTTON_MAP[16] = {
    PadButton::Select, PadButton::L3, PadButton::R3, PadButton::Start,
    PadButton::Up, PadButton::Right, PadButton::Down, PadButton::Left,
    PadButton::L2, PadButton::R2, PadButton::L1, PadButton::R1,
    PadButton::Triangle, PadButton::Circle, PadButton::Cross, PadButton::Square
};

// Texto do aviso de confirmação de sono (D-pad baixo). Também identifica o diálogo de confirmação.
const char* const SLEEP_PROMPT = "Dormir e salvar? X confirma, O cancela.";
const char SAVE_MAGIC[8] = { 'S', 'D', 'V', 'P', 'S', '3', '1', '6' };
const int SAVE_VERSION = 2;

std::string saveSlotPath(int slot) {
    if (!SaveSlots::valid(slot)) slot = 1;
    return Paths::saveFile(SaveSlots::fileName(slot));
}
std::string saveSlotBackupPath(int slot) {
    if (!SaveSlots::valid(slot)) slot = 1;
    return Paths::saveFile(SaveSlots::backupFileName(slot));
}

const char* seasonName(Season s) {
    switch (s) {
        case Season::Spring: return "Primavera";
        case Season::Summer: return "Verão";
        case Season::Autumn: return "Outono";
        case Season::Winter: return "Inverno";
    }
    return "?";
}

const char* toolName(ToolType t) {
    switch (t) {
        case ToolType::Hoe: return "Enxada";
        case ToolType::WateringCan: return "Regador";
        case ToolType::Axe: return "Machado";
        case ToolType::Pickaxe: return "Picareta";
        case ToolType::FishingRod: return "Vara de pesca";
        case ToolType::TurnipSeeds: return "Sementes de nabo";
        case ToolType::PotatoSeeds: return "Sementes de batata";
        case ToolType::PumpkinSeeds: return "Sementes de abóbora";
        case ToolType::FenceBuild: return "Cerca";
        case ToolType::SprinklerBuild: return "Irrigador";
        case ToolType::FurnitureBuild: return "Móvel";
        case ToolType::KegBuild: return "Barril";
        case ToolType::ScarecrowBuild: return "Espantalho";
        case ToolType::MayoBuild: return "Máq. de maionese";
        case ToolType::CheeseBuild: return "Prensa de queijo";
        case ToolType::Hand: return "Mão";
    }
    return "?";
}

const char* ITEM_NAMES[20] = {
    "Nabo", "Batata", "Abóbora", "Peixe", "Ovo", "Leite", "Lã", "Maionese", "Queijo", "Madeira",
    "Cobre", "Ferro", "Ouro", "Irídio", "Geleia", "Vinho", "Sem. nabo", "Sem. batata", "Sem. abóbora", "Refeição"
};

// Preço de venda por item (0 = não vende). Mesma ordem de ITEM_NAMES.
const int ITEM_SELL_PRICE[20] = {
    40, 60, 120, 100, 50, 80, 120, 190, 230, 0,
    0, 0, 0, 0, 160, 300, 0, 0, 0, 0
};

std::vector<std::string> wrapText(const std::string& text, int maxChars) {
    std::vector<std::string> lines;
    std::string line, word;
    int lineChars = 0, wordChars = 0;
    auto flushWord = [&]() {
        if (word.empty()) return;
        if (lineChars > 0 && lineChars + 1 + wordChars > maxChars) {
            lines.push_back(line);
            line.clear(); lineChars = 0;
        }
        if (lineChars > 0) { line += ' '; ++lineChars; }
        line += word; lineChars += wordChars;
        word.clear(); wordChars = 0;
    };
    for (size_t i = 0; i < text.size(); ++i) {
        char c = text[i];
        if (c == ' ') { flushWord(); }
        else if (c == '\n') { flushWord(); lines.push_back(line); line.clear(); lineChars = 0; }
        else {
            word += c;
            if ((static_cast<unsigned char>(c) & 0xC0) != 0x80) ++wordChars;  // conta codepoints, não bytes
        }
    }
    flushWord();
    if (!line.empty() || lines.empty()) lines.push_back(line);
    return lines;
}

} // namespace

Game::Game()
    : m_isRunning(false), m_gameState(GameState::MainMenu), m_mainMenuSelection(0), m_showSettings(false), m_showSaveSlots(false), m_showRecoveryPrompt(false), m_confirmSlotUse(false), m_slotCandidate(1), m_saveSlot(1), m_slotSelection(0), m_settingsSelection(0), m_stickDeadzone(0.24f), m_stickSensitivity(1.0f), m_musicVolume(96), m_shopSelection(0), m_inventoryCategory(0), m_hasStarted(false), m_menuMessage(""),
      m_showInventoryMenu(false), m_showShopMenu(false),
      m_showBulletinBoard(false), m_showMineMenu(false), m_showAchievements(false), m_showQuestJournal(false),
      m_isFishingActive(false), m_isRaining(false), m_currentSeason(Season::Spring), m_activeDialogue(""), m_farmName("Minha Fazenda"),
      m_dayCount(1), m_dayOfSeason(1), m_timeOfDayMinutes(600), m_mineDepth(1), m_money(500),
      m_stamina(100.0f), m_maxStamina(100.0f), m_stepSoundTimer(0.0f), m_actionFeedbackTimer(0.0f), m_actionFeedback(""),
      m_dailyRequestClaimed(false), m_dailyHarvestCount(0), m_dailyEarnings(0),
      m_fishPos(0.5f), m_barPos(0.5f), m_barVelocity(0.0f), m_catchProgress(0.0f), m_fishHooked(false),
      m_farmingLevel(3), m_miningLevel(3), m_fishingLevel(3), m_forageLevel(3),
      m_inventoryTurnips(10), m_inventoryPotatoes(8), m_inventoryPumpkins(4), m_inventoryFish(5),
      m_inventoryEggs(4), m_inventoryMilk(3), m_inventoryWool(2), m_inventoryMayonnaise(2), m_inventoryCheese(2),
      m_inventoryWood(80), m_inventoryCopperOre(15), m_inventoryIronOre(12), m_inventoryGoldOre(6), m_inventoryIridiumOre(3),
      m_inventoryJelly(3), m_inventoryWine(3),
      m_inventoryTurnipSeeds(25), m_inventoryPotatoSeeds(15), m_inventoryPumpkinSeeds(10), m_inventoryMeals(8),
      m_achievementMillionaire(false), m_achievementMasterFarmer(false), m_achievementDeepMiner(false),
      m_coverTexture(nullptr), m_gameController(nullptr), m_joystick(nullptr), m_keyDirX(0.0f), m_keyDirY(0.0f)
#ifdef HAVE_SDL_MIXER
      , m_sfxStep(nullptr), m_sfxAction(nullptr), m_sfxHarvest(nullptr), m_sfxSleep(nullptr), m_sfxFishBite(nullptr),
      m_sfxWater(nullptr), m_sfxPlant(nullptr), m_sfxTool(nullptr), m_bgmMusic(nullptr)
#endif
{
    m_camera.x = 0.0f;
    m_camera.y = 0.0f;
    m_camera.viewportWidth = SCREEN_W;
    m_camera.viewportHeight = SCREEN_H;
}

Game::~Game() { shutdown(); }

std::array<int*, 20> Game::inventoryRefs() {
    return {{
        &m_inventoryTurnips, &m_inventoryPotatoes, &m_inventoryPumpkins, &m_inventoryFish,
        &m_inventoryEggs, &m_inventoryMilk, &m_inventoryWool, &m_inventoryMayonnaise,
        &m_inventoryCheese, &m_inventoryWood, &m_inventoryCopperOre, &m_inventoryIronOre,
        &m_inventoryGoldOre, &m_inventoryIridiumOre, &m_inventoryJelly, &m_inventoryWine,
        &m_inventoryTurnipSeeds, &m_inventoryPotatoSeeds, &m_inventoryPumpkinSeeds, &m_inventoryMeals
    }};
}

bool Game::init() {
#ifdef STARDEW_ON_PS3
    // No PS3 os controles são lidos pela libio (PadInput). O SDL não inicializa joystick/gamecontroller
    // aqui para não haver dupla inicialização de ioPadInit; só cai para o SDL se a libio falhar.
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) return false;
#else
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK | SDL_INIT_AUDIO) < 0) return false;
#endif
    if (!m_renderer.init("Stardew PS3 - Fazenda 2D (V2.6)", SCREEN_W, SCREEN_H)) return false;

#ifdef STARDEW_ON_PS3
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, ps3SysutilCallback, nullptr);
    if (!m_pad.init()) {
        std::printf("[Game] libio indisponivel, usando SDL_GameController/SDL_Joystick.\n");
        SDL_InitSubSystem(SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK);
    }
    flushPadLog();
#endif

#ifdef HAVE_SDL_MIXER
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        std::printf("[Game] Aviso: não foi possível abrir o SDL_mixer: %s\n", Mix_GetError());
    } else {
        Mix_AllocateChannels(16);
        m_sfxAction = Mix_LoadWAV(Paths::resource("assets/audio/action.wav").c_str());
        m_sfxStep = Mix_LoadWAV(Paths::resource("assets/audio/step.wav").c_str());
        m_sfxHarvest = Mix_LoadWAV(Paths::resource("assets/audio/harvest.wav").c_str());
        m_sfxSleep = Mix_LoadWAV(Paths::resource("assets/audio/sleep.wav").c_str());
        m_sfxFishBite = Mix_LoadWAV(Paths::resource("assets/audio/fishbite.wav").c_str());
        m_sfxWater = Mix_LoadWAV(Paths::resource("assets/audio/water.wav").c_str());
        m_sfxPlant = Mix_LoadWAV(Paths::resource("assets/audio/plant.wav").c_str());
        m_sfxTool = Mix_LoadWAV(Paths::resource("assets/audio/tool.wav").c_str());
    }
#endif

    // Preferência: SDL_GameController. Se o port do SDL2 não mapear o DualShock 3,
    // cai para SDL_Joystick com a tabela JOY_BUTTON_MAP.
    if (!m_pad.active()) {
        for (int i = 0; i < SDL_NumJoysticks(); ++i) {
            if (SDL_IsGameController(i)) {
                m_gameController = SDL_GameControllerOpen(i);
                if (m_gameController) break;
            }
        }
        if (!m_gameController && SDL_NumJoysticks() > 0) {
            m_joystick = SDL_JoystickOpen(0);
        }
    }

    loadSettings();
    m_coverTexture = m_renderer.loadTextureBMP(Paths::resource("assets/textures/title_screen.bmp"), false);

    if (!m_tileMap.initTextures(m_renderer) || !m_player.initTextures(m_renderer)) return false;
    m_tileMap.generateInitialFarm(40, 30);

    float startX = (m_tileMap.getPixelWidth() * 0.5f) - 16.0f;
    float startY = (m_tileMap.getPixelHeight() * 0.5f) - 16.0f;
    m_player.setPosition(startX, startY);

    m_camera.x = m_player.getCenterX() - SCREEN_W * 0.5f;
    m_camera.y = m_player.getCenterY() - SCREEN_H * 0.5f;
    playMusic(Paths::resource("assets/audio/spring.wav"));
    m_isRunning = true;
    return true;
}

void Game::run() {
    Uint64 freq = SDL_GetPerformanceFrequency();
    Uint64 last = SDL_GetPerformanceCounter();
    while (m_isRunning) {
        Uint64 now = SDL_GetPerformanceCounter();
        float dt = static_cast<float>(now - last) / static_cast<float>(freq);
        last = now;
        if (dt > 0.05f) dt = 0.05f;

#ifdef STARDEW_ON_PS3
        sysUtilCheckCallback();
        if (g_ps3ExitRequested) {
            if (m_hasStarted) saveGame();
            m_isRunning = false;
            break;
        }
#endif
        processEvents();
        update(dt);
        render();
        SDL_Delay(1);
    }
}

void Game::playSoundEffect(int soundId) {
#ifdef HAVE_SDL_MIXER
    Mix_Chunk* chunk = nullptr;
    if (soundId == 1) chunk = m_sfxAction;
    else if (soundId == 2) chunk = m_sfxHarvest;
    else if (soundId == 3) chunk = m_sfxSleep;
    else if (soundId == 4) chunk = m_sfxFishBite;
    else if (soundId == 5) chunk = m_sfxStep;
    else if (soundId == 6) chunk = m_sfxPlant;
    else if (soundId == 7) chunk = m_sfxWater;
    else if (soundId == 8) chunk = m_sfxTool;
    if (chunk) Mix_PlayChannel(-1, chunk, 0);
#else
    (void)soundId;
#endif
}

void Game::playMusic(const std::string& musicPath) {
#ifdef HAVE_SDL_MIXER
    if (m_bgmMusic) { Mix_FreeMusic(m_bgmMusic); m_bgmMusic = nullptr; }
    m_bgmMusic = Mix_LoadMUS(musicPath.c_str());
    if (m_bgmMusic) Mix_PlayMusic(m_bgmMusic, -1);
#else
    (void)musicPath;
#endif
}

bool Game::anyOverlayOpen() const {
    return m_showInventoryMenu || m_showShopMenu || m_showBulletinBoard || m_showMineMenu ||
           m_showAchievements || m_showQuestJournal || !m_activeDialogue.empty();
}

void Game::closeTopOverlay() {
    if (!m_activeDialogue.empty()) m_activeDialogue = "";
    else if (m_showInventoryMenu) m_showInventoryMenu = false;
    else if (m_showShopMenu) m_showShopMenu = false;
    else if (m_showBulletinBoard) m_showBulletinBoard = false;
    else if (m_showMineMenu) m_showMineMenu = false;
    else if (m_showAchievements) m_showAchievements = false;
    else if (m_showQuestJournal) m_showQuestJournal = false;
}

void Game::onMenuConfirm() {
    if (m_showRecoveryPrompt) {
        m_showRecoveryPrompt = false;
        const std::string savePath = saveSlotPath(m_saveSlot);
        const std::string tempPath = savePath + ".recovery.tmp";
        const bool staged = restoreCurrentBackup();
        if (staged && loadGame()) {
            std::remove(tempPath.c_str());
            m_hasStarted = true; m_gameState = GameState::Playing;
            m_activeDialogue = "Save recuperado do backup.";
            const char* tracks[4] = { "spring.wav", "summer.wav", "autumn.wav", "winter.wav" };
            playMusic(Paths::resource(std::string("assets/audio/") + tracks[static_cast<int>(m_currentSeason)]));
        } else {
            if (staged) {
                std::ifstream original(tempPath.c_str(), std::ios::binary);
                if (original.good()) { original.close(); SaveSlots::copyFile(tempPath, savePath); }
                else std::remove(savePath.c_str());
                std::remove(tempPath.c_str());
            }
            m_menuMessage = "Falha: backup invalido; arquivo original preservado.";
        }
        return;
    }
    if (m_showSaveSlots) {
        if (m_confirmSlotUse) {
            m_saveSlot = m_slotCandidate; m_confirmSlotUse = false; m_showSaveSlots = false;
            saveSettings();
            char msg[80]; std::snprintf(msg, sizeof(msg), "Slot %d ativo. O proximo save substituirá os dados existentes.", m_saveSlot); m_menuMessage = msg; return;
        }
        if (m_slotSelection >= 3) { m_showSaveSlots = false; return; }
        m_slotCandidate = m_slotSelection + 1;
        const SaveSlots::FileStatus status = SaveSlots::inspect(saveSlotPath(m_slotCandidate), SAVE_MAGIC, SAVE_VERSION);
        if (status == SaveSlots::FileStatus::Missing) {
            m_saveSlot = m_slotCandidate; m_showSaveSlots = false; saveSettings();
            char msg[64]; std::snprintf(msg, sizeof(msg), "Slot vazio %d ativo.", m_saveSlot); m_menuMessage = msg;
        } else {
            m_confirmSlotUse = true;
        }
        saveSettings();
        return;
    }
    if (m_showSettings) {
        if (m_settingsSelection == 4) { m_showSettings = false; m_menuMessage.clear(); return; }
        if (m_settingsSelection == 3) {
#ifdef HAVE_SDL_MIXER
            Mix_VolumeMusic(m_musicVolume);
#endif
            saveSettings(); m_menuMessage = "Configuracoes salvas."; return;
        }
        return;
    }
    m_menuMessage.clear();
    if (m_mainMenuSelection == 0) {
        m_hasStarted = true;
        m_gameState = GameState::Playing;
        playMusic(Paths::resource("assets/audio/spring.wav"));
    } else if (m_mainMenuSelection == 1) {
        if (loadGame()) { m_hasStarted = true; m_gameState = GameState::Playing; const char* tracks[4] = { "spring.wav", "summer.wav", "autumn.wav", "winter.wav" }; playMusic(Paths::resource(std::string("assets/audio/") + tracks[static_cast<int>(m_currentSeason)])); }
        else if (SaveSlots::inspect(saveSlotBackupPath(m_saveSlot), SAVE_MAGIC, SAVE_VERSION) == SaveSlots::FileStatus::ValidHeader) m_showRecoveryPrompt = true;
        else m_menuMessage = "Save ausente/invalido; backup valido nao encontrado.";
    } else if (m_mainMenuSelection == 2) {
        m_showSaveSlots = true; m_slotSelection = m_saveSlot - 1;
    } else if (m_mainMenuSelection == 3) {
        m_showSettings = true; m_settingsSelection = 0;
    } else {
        m_isRunning = false;
    }
}

// Ações do controle, já independentes da API de leitura (libio nativa, SDL_GameController ou SDL_Joystick).
//
// Mapeamento v1.8 (DualShock 3/4):
//   X confirma/age | O cancela/fecha | Quadrado cozinhar | Triângulo inventário (na loja: vender tudo)
//   L1/R1 ferramenta anterior/próxima | L2 diário | R2 quadro de avisos | L3 minas | R3 conquistas
//   SELECT loja | START pausa (menu principal) | D-pad: navega menus; esquerda salva;
//   direita menu principal; baixo (fora de menus) pede confirmação para dormir.
void Game::onPadButton(PadButton button) {
    if (m_gameState == GameState::MainMenu) {
        if (m_showRecoveryPrompt) {
            if (button == PadButton::Cross) onMenuConfirm();
            else if (button == PadButton::Circle) { m_showRecoveryPrompt = false; m_menuMessage = "Recuperacao cancelada."; }
        } else if (m_showSaveSlots) {
            if (m_confirmSlotUse) {
                if (button == PadButton::Cross) onMenuConfirm();
                else if (button == PadButton::Circle) m_confirmSlotUse = false;
            } else if (button == PadButton::Down) m_slotSelection = (m_slotSelection + 1) % 4;
            else if (button == PadButton::Up) m_slotSelection = (m_slotSelection + 3) % 4;
            else if (button == PadButton::Cross) onMenuConfirm();
            else if (button == PadButton::Circle) {
                if (m_confirmSlotUse) m_confirmSlotUse = false;
                else m_showSaveSlots = false;
            }
        } else if (m_showSettings) {
            if (button == PadButton::Down) m_settingsSelection = (m_settingsSelection + 1) % 5;
            else if (button == PadButton::Up) m_settingsSelection = (m_settingsSelection + 4) % 5;
            else if (button == PadButton::Left || button == PadButton::Right) {
                float d = button == PadButton::Right ? 0.01f : -0.01f;
                float s = button == PadButton::Right ? 0.05f : -0.05f;
                if (m_settingsSelection == 0) m_stickDeadzone = std::max(0.05f, std::min(0.50f, m_stickDeadzone + d));
                else if (m_settingsSelection == 1) m_stickSensitivity = std::max(0.50f, std::min(1.50f, m_stickSensitivity + s));
                else if (m_settingsSelection == 2) m_musicVolume = std::max(0, std::min(128, m_musicVolume + (button == PadButton::Right ? 8 : -8)));
                m_pad.setDeadzone(m_stickDeadzone); m_pad.setSensitivity(m_stickSensitivity);
                saveSettings();
#ifdef HAVE_SDL_MIXER
                if (m_settingsSelection == 2) Mix_VolumeMusic(m_musicVolume);
#endif
            } else if (button == PadButton::Cross) onMenuConfirm();
            else if (button == PadButton::Circle) { m_showSettings = false; m_menuMessage.clear(); }
        } else {
            if (button == PadButton::Down) m_mainMenuSelection = (m_mainMenuSelection + 1) % 5;
            else if (button == PadButton::Up) m_mainMenuSelection = (m_mainMenuSelection + 4) % 5;
            else if (button == PadButton::Cross || button == PadButton::Start) onMenuConfirm();
        }
        return;
    }

    if (m_isFishingActive) {
        if (button == PadButton::Cross) m_barVelocity -= 3.5f;
        return;
    }

    if (!m_activeDialogue.empty()) {
        if (m_activeDialogue == SLEEP_PROMPT) {          // confirmação de sono: X dorme, O cancela
            if (button == PadButton::Cross) { m_activeDialogue = ""; sleepInBed(); }
            else if (button == PadButton::Circle) m_activeDialogue = "";
            return;
        }
        if (button == PadButton::Cross || button == PadButton::Circle) m_activeDialogue = "";
        return;
    }

    if (m_showInventoryMenu) {
        if (button == PadButton::Left || button == PadButton::L1) m_inventoryCategory = (m_inventoryCategory + 6) % 7;
        else if (button == PadButton::Right || button == PadButton::R1) m_inventoryCategory = (m_inventoryCategory + 1) % 7;
        else if (button == PadButton::Triangle || button == PadButton::Circle) m_showInventoryMenu = false;
        return;
    }
    if (m_showBulletinBoard && button == PadButton::Cross) {
        deliverDailyRequest();
        return;
    }

    if (m_showMineMenu) {
        if (button == PadButton::Up) m_mineDepth = std::min(100, m_mineDepth + 1);
        else if (button == PadButton::Down) m_mineDepth = std::max(1, m_mineDepth - 1);
    }
    if (m_showShopMenu) {
        if (button == PadButton::Up) { m_shopSelection = (m_shopSelection + 3) % 4; return; }
        if (button == PadButton::Down) { m_shopSelection = (m_shopSelection + 1) % 4; return; }
        if (button == PadButton::Cross) { if (m_shopSelection == 3) sellAll(); else buyShopItem(m_shopSelection); return; }
        if (button == PadButton::Triangle) { sellAll(); return; }
    }

    switch (button) {
        case PadButton::Cross:
            if (!anyOverlayOpen()) {
                int tx, ty; m_player.getFacingTile(tx, ty);
                handleToolAction(tx, ty);
            }
            break;
        case PadButton::Circle:   if (anyOverlayOpen()) closeTopOverlay(); else talkOrCareAtTarget(); break;
        case PadButton::Square:   if (!anyOverlayOpen()) cookMeal(); break;
        case PadButton::Triangle: m_showInventoryMenu = !m_showInventoryMenu; break;
        case PadButton::L1:       if (!anyOverlayOpen()) m_player.cycleToolPrev(); break;
        case PadButton::R1:       if (!anyOverlayOpen()) m_player.cycleTool(); break;
        case PadButton::L2:       m_showQuestJournal = !m_showQuestJournal; break;
        case PadButton::R2:       m_showBulletinBoard = !m_showBulletinBoard; break;
        case PadButton::L3:       m_showMineMenu = !m_showMineMenu; break;
        case PadButton::R3:       m_showAchievements = !m_showAchievements; break;
        case PadButton::Select:   m_showShopMenu = !m_showShopMenu; break;
        case PadButton::Start:    if (!anyOverlayOpen()) m_gameState = GameState::MainMenu; break;
        case PadButton::Left:     if (!anyOverlayOpen()) saveGame(); break;
        case PadButton::Right:    if (!anyOverlayOpen()) m_gameState = GameState::MainMenu; break;
        case PadButton::Down:     if (!anyOverlayOpen()) m_activeDialogue = SLEEP_PROMPT; break;
        default: break;
    }
}

void Game::flushPadLog() {
    std::vector<std::string> lines = m_pad.takeLogLines();
    if (lines.empty()) return;
    Paths::ensureSaveDir();
    std::FILE* f = std::fopen(Paths::saveFile("pad_log.txt").c_str(), "a");
    if (!f) return;
    for (size_t i = 0; i < lines.size(); ++i) std::fprintf(f, "%s\n", lines[i].c_str());
    std::fclose(f);
}

void Game::processEvents() {
    if (m_pad.active()) {
        m_pad.poll();
        PadButton pb;
        while (m_pad.popPress(pb)) onPadButton(pb);
        flushPadLog();
    }

    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        switch (e.type) {
            case SDL_QUIT: m_isRunning = false; break;
            case SDL_CONTROLLERDEVICEADDED:
                if (!m_gameController) {
                    m_gameController = SDL_GameControllerOpen(e.cdevice.which);
                    if (m_gameController && m_joystick) { SDL_JoystickClose(m_joystick); m_joystick = nullptr; }
                }
                break;
            case SDL_CONTROLLERDEVICEREMOVED:
                if (m_gameController && SDL_GameControllerFromInstanceID(e.cdevice.which) == m_gameController) {
                    SDL_GameControllerClose(m_gameController);
                    m_gameController = nullptr;
                }
                break;
            case SDL_CONTROLLERBUTTONDOWN:
                switch (e.cbutton.button) {
                    case SDL_CONTROLLER_BUTTON_A: onPadButton(PadButton::Cross); break;
                    case SDL_CONTROLLER_BUTTON_B: onPadButton(PadButton::Circle); break;
                    case SDL_CONTROLLER_BUTTON_X: onPadButton(PadButton::Square); break;
                    case SDL_CONTROLLER_BUTTON_Y: onPadButton(PadButton::Triangle); break;
                    case SDL_CONTROLLER_BUTTON_START: onPadButton(PadButton::Start); break;
                    case SDL_CONTROLLER_BUTTON_BACK: onPadButton(PadButton::Select); break;
                    case SDL_CONTROLLER_BUTTON_LEFTSHOULDER: onPadButton(PadButton::L1); break;
                    case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER: onPadButton(PadButton::R1); break;
                    case SDL_CONTROLLER_BUTTON_LEFTSTICK: onPadButton(PadButton::L3); break;
                    case SDL_CONTROLLER_BUTTON_RIGHTSTICK: onPadButton(PadButton::R3); break;
                    case SDL_CONTROLLER_BUTTON_DPAD_UP: onPadButton(PadButton::Up); break;
                    case SDL_CONTROLLER_BUTTON_DPAD_DOWN: onPadButton(PadButton::Down); break;
                    case SDL_CONTROLLER_BUTTON_DPAD_LEFT: onPadButton(PadButton::Left); break;
                    case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: onPadButton(PadButton::Right); break;
                    default: break;
                }
                break;
            case SDL_JOYBUTTONDOWN:
                if (m_joystick && !m_gameController && e.jbutton.button < 16) {
                    onPadButton(JOY_BUTTON_MAP[e.jbutton.button]);
                }
                break;
            case SDL_KEYDOWN:
                if (e.key.keysym.sym == SDLK_ESCAPE) {
                    if (m_gameState == GameState::MainMenu && m_showRecoveryPrompt) { m_showRecoveryPrompt = false; m_menuMessage = "Recuperacao cancelada."; }
                    else if (m_gameState == GameState::MainMenu && m_showSaveSlots && m_confirmSlotUse) m_confirmSlotUse = false;
                    else if (m_gameState == GameState::MainMenu && m_showSettings) { m_showSettings = false; m_menuMessage.clear(); }
                    else if (m_gameState == GameState::MainMenu && m_showSaveSlots) m_showSaveSlots = false;
                    else if (m_gameState == GameState::MainMenu) m_isRunning = false;
                    else if (anyOverlayOpen()) closeTopOverlay();
                    else m_gameState = GameState::MainMenu;
                } else if (m_gameState == GameState::MainMenu) {
                    if (e.key.keysym.sym == SDLK_DOWN) onPadButton(PadButton::Down);
                    else if (e.key.keysym.sym == SDLK_UP) onPadButton(PadButton::Up);
                    else if (m_showSettings && e.key.keysym.sym == SDLK_LEFT) onPadButton(PadButton::Left);
                    else if (m_showSettings && e.key.keysym.sym == SDLK_RIGHT) onPadButton(PadButton::Right);
                    else if (m_showSettings && e.key.keysym.sym == SDLK_ESCAPE) onPadButton(PadButton::Circle);
                    else if (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_SPACE) onPadButton(PadButton::Cross);
                } else if (m_isFishingActive) {
                    if (e.key.keysym.sym == SDLK_SPACE) m_barVelocity -= 3.5f;
                } else {
                    if (m_showInventoryMenu && (e.key.keysym.sym == SDLK_LEFT || e.key.keysym.sym == SDLK_RIGHT)) {
                        m_inventoryCategory = (m_inventoryCategory + (e.key.keysym.sym == SDLK_RIGHT ? 1 : 6)) % 7;
                    }
                    else if (m_showInventoryMenu && (e.key.keysym.sym == SDLK_ESCAPE || e.key.keysym.sym == SDLK_i)) m_showInventoryMenu = false;
                    else if (m_showInventoryMenu) { /* atalhos numéricos não alteram ferramenta no inventário */ }
                    else if (m_showBulletinBoard && (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_SPACE)) deliverDailyRequest();
                    else if (m_showShopMenu && (e.key.keysym.sym == SDLK_UP || e.key.keysym.sym == SDLK_DOWN)) {
                        m_shopSelection = (m_shopSelection + (e.key.keysym.sym == SDLK_UP ? 3 : 1)) % 4;
                    }
                    else if (m_showShopMenu && (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_SPACE)) {
                        if (m_shopSelection == 3) sellAll(); else buyShopItem(m_shopSelection);
                    }
                    else if (m_showShopMenu && e.key.keysym.sym == SDLK_v) sellAll();
                    else if (e.key.keysym.sym == SDLK_i) m_showInventoryMenu = !m_showInventoryMenu;
                    else if (e.key.keysym.sym == SDLK_p) m_showShopMenu = !m_showShopMenu;
                    else if (e.key.keysym.sym == SDLK_b) m_showBulletinBoard = !m_showBulletinBoard;
                    else if (e.key.keysym.sym == SDLK_m) m_showMineMenu = !m_showMineMenu;
                    else if (e.key.keysym.sym == SDLK_a) m_showAchievements = !m_showAchievements;
                    else if (e.key.keysym.sym == SDLK_j) m_showQuestJournal = !m_showQuestJournal;
                    else if (e.key.keysym.sym == SDLK_t) talkOrCareAtTarget();
                    else if (e.key.keysym.sym == SDLK_TAB) m_player.cycleTool();
                    else if (e.key.keysym.sym == SDLK_c) cookMeal();
                    else if (e.key.keysym.sym == SDLK_e) sleepInBed();
                    else if (e.key.keysym.sym == SDLK_F5) saveGame();
                    else if (e.key.keysym.sym == SDLK_1) m_player.setSelectedTool(ToolType::Hoe);
                    else if (e.key.keysym.sym == SDLK_2) m_player.setSelectedTool(ToolType::WateringCan);
                    else if (e.key.keysym.sym == SDLK_3) m_player.setSelectedTool(ToolType::Axe);
                    else if (e.key.keysym.sym == SDLK_4) m_player.setSelectedTool(ToolType::Pickaxe);
                    else if (e.key.keysym.sym == SDLK_5) m_player.setSelectedTool(ToolType::FishingRod);
                    else if (e.key.keysym.sym == SDLK_6) m_player.setSelectedTool(ToolType::TurnipSeeds);
                    else if (e.key.keysym.sym == SDLK_7) m_player.setSelectedTool(ToolType::PotatoSeeds);
                    else if (e.key.keysym.sym == SDLK_8) m_player.setSelectedTool(ToolType::PumpkinSeeds);
                    else if (e.key.keysym.sym == SDLK_9) m_player.setSelectedTool(ToolType::FenceBuild);
                    else if (e.key.keysym.sym == SDLK_0) m_player.setSelectedTool(ToolType::SprinklerBuild);
                    else if (e.key.keysym.sym == SDLK_k) m_player.setSelectedTool(ToolType::KegBuild);
                    else if (e.key.keysym.sym == SDLK_s) m_player.setSelectedTool(ToolType::ScarecrowBuild);
                    else if (e.key.keysym.sym == SDLK_SPACE || e.key.keysym.sym == SDLK_RETURN) {
                        if (!m_activeDialogue.empty()) m_activeDialogue = "";
                        else if (m_showShopMenu) sellAll();
                        else if (!anyOverlayOpen()) {
                            int tx, ty; m_player.getFacingTile(tx, ty);
                            handleToolAction(tx, ty);
                        }
                    }
                    else if (m_showMineMenu && e.key.keysym.sym == SDLK_UP) m_mineDepth = std::min(100, m_mineDepth + 1);
                    else if (m_showMineMenu && e.key.keysym.sym == SDLK_DOWN) m_mineDepth = std::max(1, m_mineDepth - 1);
                }
                break;
            default: break;
        }
    }

    float padDirX = 0.0f;
    float padDirY = 0.0f;
    if (m_gameState == GameState::Playing) {
        Sint16 axisX = 0, axisY = 0;
        if (m_pad.active()) {
            padDirX = m_pad.leftX();     // já calibrado e com zona morta (PadInput)
            padDirY = m_pad.leftY();
        } else if (m_gameController) {
            axisX = SDL_GameControllerGetAxis(m_gameController, SDL_CONTROLLER_AXIS_LEFTX);
            axisY = SDL_GameControllerGetAxis(m_gameController, SDL_CONTROLLER_AXIS_LEFTY);
        } else if (m_joystick) {
            axisX = SDL_JoystickGetAxis(m_joystick, 0);
            axisY = SDL_JoystickGetAxis(m_joystick, 1);
        }
        if (!m_pad.active()) {
            padDirX = axisX / 32767.0f; padDirY = axisY / 32767.0f;
            float magnitude = std::sqrt(padDirX * padDirX + padDirY * padDirY);
            if (magnitude <= m_stickDeadzone) padDirX = padDirY = 0.0f;
            else {
                float scaled = std::min(1.0f, (magnitude - m_stickDeadzone) / (1.0f - m_stickDeadzone) * m_stickSensitivity);
                float factor = scaled / magnitude; padDirX *= factor; padDirY *= factor;
            }
        }
    }

    const Uint8* keys = SDL_GetKeyboardState(nullptr);
    m_keyDirX = 0.0f; m_keyDirY = 0.0f;
    if (keys) {
        if (keys[SDL_SCANCODE_LEFT]) m_keyDirX -= 1.0f;
        if (keys[SDL_SCANCODE_RIGHT]) m_keyDirX += 1.0f;
        if (keys[SDL_SCANCODE_UP]) m_keyDirY -= 1.0f;
        if (keys[SDL_SCANCODE_DOWN]) m_keyDirY += 1.0f;
    }

    float finalDirX = (padDirX != 0.0f) ? padDirX : m_keyDirX;
    float finalDirY = (padDirY != 0.0f) ? padDirY : m_keyDirY;
    if (m_gameState == GameState::Playing && !m_isFishingActive && !anyOverlayOpen()) {
        m_player.setInputDirection(finalDirX, finalDirY);
    } else if (m_gameState == GameState::Playing) {
        m_player.setInputDirection(0.0f, 0.0f);
    }
}

// Preferencias independentes do formato dos saves da fazenda.
void Game::loadSettings() {
    std::ifstream f(Paths::saveFile("settings_v1.9.cfg").c_str());
    int version = 0; float dz = 0.24f, sens = 1.0f; int volume = 96;
    int slot = 1;
    if (f >> version >> dz >> sens >> volume && (version == 1 || version == 2)) {
        m_stickDeadzone = std::max(0.05f, std::min(0.50f, dz));
        m_stickSensitivity = std::max(0.50f, std::min(1.50f, sens));
        m_musicVolume = std::max(0, std::min(128, volume));
        if (version == 2 && f >> slot && SaveSlots::valid(slot)) m_saveSlot = slot;
    }
    m_pad.setDeadzone(m_stickDeadzone); m_pad.setSensitivity(m_stickSensitivity);
#ifdef HAVE_SDL_MIXER
    Mix_VolumeMusic(m_musicVolume);
#endif
}

void Game::saveSettings() {
    Paths::ensureSaveDir();
    std::ofstream f(Paths::saveFile("settings_v1.9.cfg").c_str(), std::ios::trunc);
    if (f) f << "2 " << m_stickDeadzone << " " << m_stickSensitivity << " " << m_musicVolume << " " << m_saveSlot << "\n";
}

// ---------------------------------------------------------------- save / load

bool Game::saveGame() {
    Paths::ensureSaveDir();
    const std::string savePath = saveSlotPath(m_saveSlot);
    const std::string backupPath = saveSlotBackupPath(m_saveSlot);
    {
        if (SaveSlots::inspect(savePath, SAVE_MAGIC, SAVE_VERSION) == SaveSlots::FileStatus::ValidHeader &&
            !SaveSlots::copyFile(savePath, backupPath)) {
            m_activeDialogue = "Erro ao salvar: nao foi possivel criar o backup; save anterior mantido.";
            return false;
        }
    }
    std::ofstream file(savePath.c_str(), std::ios::binary | std::ios::trunc);
    if (!file.is_open()) {
        m_activeDialogue = "Erro ao salvar: não foi possível abrir o arquivo de save.";
        return false;
    }

    auto writeInt = [&file](int v) { file.write(reinterpret_cast<const char*>(&v), sizeof(v)); };
    file.write(SAVE_MAGIC, sizeof(SAVE_MAGIC));
    writeInt(SAVE_VERSION);
    writeInt(m_money);
    writeInt(m_dayCount);
    writeInt(m_dayOfSeason);
    writeInt(static_cast<int>(m_currentSeason));
    writeInt(m_isRaining ? 1 : 0);
    writeInt(m_mineDepth);
    writeInt(m_farmingLevel); writeInt(m_miningLevel); writeInt(m_fishingLevel); writeInt(m_forageLevel);
    writeInt(m_achievementMillionaire ? 1 : 0);
    writeInt(m_achievementMasterFarmer ? 1 : 0);
    writeInt(m_achievementDeepMiner ? 1 : 0);
    for (int* item : inventoryRefs()) writeInt(*item);

    int width = m_tileMap.getWidthInTiles();
    int height = m_tileMap.getHeightInTiles();
    writeInt(width);
    writeInt(height);
    auto& tiles = m_tileMap.getTilesRef();
    auto& crops = m_tileMap.getCropsRef();
    file.write(reinterpret_cast<const char*>(tiles.data()), static_cast<std::streamsize>(tiles.size() * sizeof(TileType)));
    file.write(reinterpret_cast<const char*>(crops.data()), static_cast<std::streamsize>(crops.size() * sizeof(CropData)));
    auto& props = m_tileMap.getPropsRef();
    writeInt(static_cast<int>(props.size()));
    file.write(reinterpret_cast<const char*>(props.data()), static_cast<std::streamsize>(props.size() * sizeof(PropObject)));

    file.flush();
    if (!file.good()) {
        m_activeDialogue = "Erro ao salvar: falha na escrita do arquivo.";
        return false;
    }
    file.close();
    saveDailyRequestState();
    m_activeDialogue = "Jogo salvo com sucesso!";
    playSoundEffect(3);
    return true;
}

bool Game::loadGame() {
    std::ifstream file(saveSlotPath(m_saveSlot).c_str(), std::ios::binary);
    if (!file.is_open()) return false;

    char magic[8];
    file.read(magic, sizeof(magic));
    if (!file.good() || !std::equal(magic, magic + 8, SAVE_MAGIC)) return false;

    auto readInt = [&file](int& v) { file.read(reinterpret_cast<char*>(&v), sizeof(v)); return file.good(); };
    int version = 0;
    if (!readInt(version) || version != SAVE_VERSION) return false;

    // Lê tudo para variáveis temporárias; só aplica se o arquivo inteiro for válido.
    int money, day, dayOfSeason, season, raining, mineDepth, lvF, lvM, lvFi, lvFo, achM, achF, achD;
    if (!(readInt(money) && readInt(day) && readInt(dayOfSeason) && readInt(season) && readInt(raining) &&
          readInt(mineDepth) && readInt(lvF) && readInt(lvM) && readInt(lvFi) && readInt(lvFo) &&
          readInt(achM) && readInt(achF) && readInt(achD))) return false;
    if (season < 0 || season > 3) return false;

    int inv[20];
    for (int i = 0; i < 20; ++i) if (!readInt(inv[i])) return false;

    int width = 0, height = 0;
    if (!readInt(width) || !readInt(height)) return false;
    if (width != m_tileMap.getWidthInTiles() || height != m_tileMap.getHeightInTiles()) return false;

    size_t count = static_cast<size_t>(width) * static_cast<size_t>(height);
    std::vector<TileType> tiles(count);
    std::vector<CropData> crops(count);
    file.read(reinterpret_cast<char*>(tiles.data()), static_cast<std::streamsize>(count * sizeof(TileType)));
    file.read(reinterpret_cast<char*>(crops.data()), static_cast<std::streamsize>(count * sizeof(CropData)));
    if (!file.good()) return false;

    int propCount = 0;
    if (!readInt(propCount) || propCount < 0 || propCount > 100000) return false;
    std::vector<PropObject> props(static_cast<size_t>(propCount));
    file.read(reinterpret_cast<char*>(props.data()), static_cast<std::streamsize>(props.size() * sizeof(PropObject)));
    if (!file.good() && !file.eof()) return false;
    if (file.gcount() != static_cast<std::streamsize>(props.size() * sizeof(PropObject))) return false;

    m_money = money; m_dayCount = day; m_dayOfSeason = dayOfSeason;
    m_currentSeason = static_cast<Season>(season);
    m_isRaining = (raining != 0);
    m_mineDepth = mineDepth;
    m_farmingLevel = lvF; m_miningLevel = lvM; m_fishingLevel = lvFi; m_forageLevel = lvFo;
    m_achievementMillionaire = (achM != 0); m_achievementMasterFarmer = (achF != 0); m_achievementDeepMiner = (achD != 0);
    std::array<int*, 20> refs = inventoryRefs();
    for (int i = 0; i < 20; ++i) *refs[i] = inv[i];
    m_tileMap.getTilesRef() = tiles;
    m_tileMap.getCropsRef() = crops;
    m_tileMap.getPropsRef() = props;
    m_timeOfDayMinutes = 600;
    m_stamina = m_maxStamina;
    m_dailyHarvestCount = 0;
    m_dailyEarnings = 0;
    loadDailyRequestState();
    m_activeDialogue = "Jogo carregado!";
    return true;
}

int Game::dailyRequestItemIndex() const {
    static const int items[5] = { 0, 1, 2, 4, 5 };
    const int day = std::max(1, m_dayCount);
    return items[(day - 1) % 5];
}

int Game::dailyRequestQuantity() const {
    return 2 + (std::max(1, m_dayCount) % 2);
}

std::string Game::dailyRequestItemName() const {
    return ITEM_NAMES[dailyRequestItemIndex()];
}

bool Game::saveDailyRequestState() const {
    if (!SaveSlots::valid(m_saveSlot)) return false;
    Paths::ensureSaveDir();
    const std::string path = Paths::saveFile("daily_request_slot" + toStr(m_saveSlot) + ".cfg");
    const std::string tempPath = path + ".tmp";
    std::remove(tempPath.c_str());
    std::ofstream f(tempPath.c_str(), std::ios::trunc);
    if (!f) return false;
    f << "1 " << m_dayCount << " " << (m_dailyRequestClaimed ? 1 : 0) << "\n";
    f.flush();
    if (!f.good()) { f.close(); std::remove(tempPath.c_str()); return false; }
    f.close();
    if (!f.good() || std::rename(tempPath.c_str(), path.c_str()) != 0) {
        std::remove(tempPath.c_str());
        return false;
    }
    return true;
}

void Game::loadDailyRequestState() {
    m_dailyRequestClaimed = false;
    if (!SaveSlots::valid(m_saveSlot)) return;
    const std::string path = Paths::saveFile("daily_request_slot" + toStr(m_saveSlot) + ".cfg");
    std::ifstream f(path.c_str());
    int version = 0, day = 0, claimed = 0;
    if (f >> version >> day >> claimed && version == 1 && day == m_dayCount)
        m_dailyRequestClaimed = claimed != 0;
}

void Game::deliverDailyRequest() {
    if (m_dailyRequestClaimed) {
        m_activeDialogue = "O pedido de hoje já foi concluído. Volte amanhã.";
        return;
    }
    const int item = dailyRequestItemIndex();
    const int quantity = dailyRequestQuantity();
    std::array<int*, 20> refs = inventoryRefs();
    if (*refs[item] < quantity) {
        m_activeDialogue = "Pedido: " + toStr(quantity) + "x " + dailyRequestItemName() + ". Estoque insuficiente.";
        return;
    }
    static const int value[6] = { 40, 60, 120, 0, 50, 80 };
    const int reward = value[item] * quantity + 50;
    *refs[item] -= quantity;
    m_money += reward;
    m_dailyEarnings += reward;
    m_dailyRequestClaimed = true;
    if (!saveDailyRequestState() || !saveGame()) {
        *refs[item] += quantity;
        m_money -= reward;
        m_dailyEarnings -= reward;
        m_dailyRequestClaimed = false;
        saveDailyRequestState();
        m_activeDialogue = "Não foi possível registrar a recompensa; itens devolvidos.";
        return;
    }
    m_activeDialogue = "Pedido concluído: " + toStr(reward) + "g recebidos!";
    m_showBulletinBoard = false;
    playSoundEffect(2);
}

bool Game::restoreCurrentBackup() {
    const std::string savePath = saveSlotPath(m_saveSlot);
    const std::string backupPath = saveSlotBackupPath(m_saveSlot);
    const std::string tempPath = savePath + ".recovery.tmp";
    if (SaveSlots::inspect(backupPath, SAVE_MAGIC, SAVE_VERSION) != SaveSlots::FileStatus::ValidHeader) return false;
    std::remove(tempPath.c_str());
    std::ifstream current(savePath.c_str(), std::ios::binary);
    const bool hadOriginal = current.good(); current.close();
    if (hadOriginal && !SaveSlots::copyFile(savePath, tempPath)) return false;
    if (!SaveSlots::copyFile(backupPath, savePath)) {
        if (hadOriginal) SaveSlots::copyFile(tempPath, savePath);
        std::remove(tempPath.c_str());
        return false;
    }
    return true; // caller performs full load validation, then removes temp or rolls back
}

void Game::buyShopItem(int item) {
    static const int prices[3] = {20, 50, 100};
    int* stock[3] = { &m_inventoryTurnipSeeds, &m_inventoryPotatoSeeds, &m_inventoryPumpkinSeeds };
    static const char* names[3] = { "Sementes de nabo", "Sementes de batata", "Sementes de abobora" };
    if (item < 0 || item >= 3) return;
    if (m_money < prices[item]) { m_activeDialogue = "Ouro insuficiente para comprar."; return; }
    if (*stock[item] > 994) { m_activeDialogue = "Voce ja tem sementes suficientes."; return; }
    m_money -= prices[item]; *stock[item] += 5;
    m_activeDialogue = std::string("Comprou 5x ") + names[item] + "!";
    playSoundEffect(1);
}

void Game::sellAll() {
    std::array<int*, 20> refs = inventoryRefs();
    int total = 0;
    for (int i = 0; i < 20; ++i) {
        if (ITEM_SELL_PRICE[i] > 0 && *refs[i] > 0) {
            total += ITEM_SELL_PRICE[i] * (*refs[i]);
            *refs[i] = 0;
        }
    }
    if (total > 0) {
        const bool festival = m_dayOfSeason == 7;
        if (festival) total = total * 3 / 2;
        m_money += total;
        m_dailyEarnings += total;
        playSoundEffect(2);
        checkAchievements();
        if (m_activeDialogue.empty()) m_activeDialogue = std::string("Vendido por ") + toStr(total) + " de ouro!" + (festival ? " (feira +50%)" : "");
    } else {
        m_activeDialogue = "Você não tem nada para vender.";
    }
    m_showShopMenu = false;
}

void Game::cookMeal() {
    if (m_inventoryTurnips >= 1 && m_inventoryEggs >= 1) {
        m_inventoryTurnips--; m_inventoryEggs--; m_inventoryMeals++;
        m_stamina = std::min(m_maxStamina, m_stamina + 50.0f);
        m_activeDialogue = "Refeição preparada! +50 Stamina.";
        playSoundEffect(2);
    } else {
        m_activeDialogue = "Faltam ingredientes (1 Nabo + 1 Ovo).";
    }
}

void Game::sleepInBed() {
    const int endedDay = m_dayCount;
    const int harvested = m_dailyHarvestCount;
    const int earned = m_dailyEarnings;
    m_dayCount++; m_dayOfSeason++;
    m_dailyRequestClaimed = false;
    if (m_dayOfSeason > 7) {
        m_dayOfSeason = 1;
        m_currentSeason = static_cast<Season>((static_cast<int>(m_currentSeason) + 1) % 4);
        const char* tracks[4] = { "spring.wav", "summer.wav", "autumn.wav", "winter.wav" };
        playMusic(Paths::resource(std::string("assets/audio/") + tracks[static_cast<int>(m_currentSeason)]));
    }
    m_stamina = m_maxStamina; m_timeOfDayMinutes = 600;
    m_isRaining = (m_dayCount % 3 == 0) && (m_currentSeason != Season::Winter);
    processArtisanMachines();
    m_tileMap.nextDay(m_isRaining, m_currentSeason);
    checkAchievements();
    saveGame();
    char summary[160];
    std::snprintf(summary, sizeof(summary), "Resumo Dia %d: coletas %d | ganhos %dg. Novo dia: %s %d/7.",
                  endedDay, harvested, earned, seasonName(m_currentSeason), m_dayOfSeason);
    m_activeDialogue = summary;
    m_dailyHarvestCount = 0;
    m_dailyEarnings = 0;
}

void Game::processArtisanMachines() {
    if (m_inventoryEggs >= 1) { m_inventoryEggs--; m_inventoryMayonnaise++; }
    if (m_inventoryMilk >= 1) { m_inventoryMilk--; m_inventoryCheese++; }
    if (m_inventoryTurnips >= 1) { m_inventoryTurnips--; m_inventoryWine++; }
}

void Game::checkAchievements() {
    if (m_money >= 15000 && !m_achievementMillionaire) { m_achievementMillionaire = true; m_activeDialogue = "Conquista: Magnata da Fazenda!"; }
}

void Game::handleToolAction(int tx, int ty) {
    if (m_stamina <= 0.0f) return;
    m_player.triggerActionVisual();

    ToolType tool = m_player.getSelectedTool();
    if ((tool == ToolType::TurnipSeeds && m_inventoryTurnipSeeds <= 0) ||
        (tool == ToolType::PotatoSeeds && m_inventoryPotatoSeeds <= 0) ||
        (tool == ToolType::PumpkinSeeds && m_inventoryPumpkinSeeds <= 0)) {
        m_actionFeedback = "Sem sementes deste tipo";
        m_actionFeedbackTimer = 1.4f;
        return;
    }
    bool spentStamina = false;

    std::string missingMaterials;
    if (tool == ToolType::FenceBuild && m_inventoryWood < 2) missingMaterials = "Cerca: precisa de 2 madeiras";
    else if (tool == ToolType::SprinklerBuild && (m_inventoryCopperOre < 1 || m_inventoryIronOre < 1)) missingMaterials = "Irrigador: precisa de cobre e ferro";
    else if (tool == ToolType::FurnitureBuild && m_inventoryWood < 5) missingMaterials = "Móvel: precisa de 5 madeiras";
    else if (tool == ToolType::KegBuild && (m_inventoryWood < 5 || m_inventoryCopperOre < 2)) missingMaterials = "Barril: 5 madeiras + 2 cobres";
    else if (tool == ToolType::ScarecrowBuild && (m_inventoryWood < 10 || m_inventoryGoldOre < 1)) missingMaterials = "Espantalho: 10 madeiras + 1 ouro";
    else if (tool == ToolType::MayoBuild && (m_inventoryWood < 10 || m_inventoryIronOre < 5)) missingMaterials = "Máquina: 10 madeiras + 5 ferros";
    else if (tool == ToolType::CheeseBuild && (m_inventoryWood < 10 || m_inventoryGoldOre < 3)) missingMaterials = "Prensa: 10 madeiras + 3 ouros";
    if (!missingMaterials.empty()) {
        m_actionFeedback = missingMaterials;
        m_actionFeedbackTimer = 2.0f;
        return;
    }

    for (const auto& npc : m_tileMap.getNPCs()) {
        int ntileX = static_cast<int>(std::floor((npc.x + 16.0f) / TileMap::TILE_SIZE));
        int ntileY = static_cast<int>(std::floor((npc.y + 16.0f) / TileMap::TILE_SIZE));
        if (std::abs(ntileX - tx) <= 1 && std::abs(ntileY - ty) <= 1) {
            if (tool == ToolType::Hand && (m_inventoryTurnips > 0 || m_inventoryPumpkins > 0)) {
                std::string gift, resp;
                if (m_inventoryTurnips > 0) { gift = "Nabo"; --m_inventoryTurnips; }
                else { gift = "Abóbora"; --m_inventoryPumpkins; }
                m_tileMap.giveGiftToNPC(ntileX, ntileY, gift, resp);
                m_activeDialogue = resp.empty() ? (npc.name + ": " + npc.dialogue) : resp;
                playSoundEffect(1);
            } else {
                m_activeDialogue = npc.name + ": " + npc.dialogue;
            }
            return;
        }
    }

    if (tool == ToolType::Hoe) {
        if (m_tileMap.hoeTile(tx, ty)) { spentStamina = true; m_farmingLevel++; }
    } else if (tool == ToolType::WateringCan) {
        if (m_tileMap.waterTile(tx, ty)) spentStamina = true;
    } else if (tool == ToolType::Axe) {
        if (m_tileMap.chopProp(tx, ty)) { m_inventoryWood += 2; spentStamina = true; m_forageLevel++; }
    } else if (tool == ToolType::Pickaxe) {
        int ore = 0;
        if (m_tileMap.mineRock(tx, ty, m_mineDepth, ore)) {
            if (ore == 1) m_inventoryCopperOre++;
            else if (ore == 2) m_inventoryIronOre++;
            else if (ore == 3) m_inventoryGoldOre++;
            else if (ore == 4) m_inventoryIridiumOre++;
            spentStamina = true; m_miningLevel++;
        }
    } else if (tool == ToolType::FishingRod) {
        if (m_tileMap.getTileAt(tx, ty) == TileType::Water) {
            m_isFishingActive = true; m_fishPos = 0.5f; m_barPos = 0.5f; m_barVelocity = 0.0f; m_catchProgress = 0.2f;
            playSoundEffect(4); spentStamina = true; m_fishingLevel++;
            return;
        }
    } else if (tool == ToolType::TurnipSeeds && m_inventoryTurnipSeeds > 0) {
        if (!m_tileMap.isCropPlantableInSeason(tx, ty, CropType::Turnip, m_currentSeason)) {
            m_actionFeedback = "Fora de estação: plante na estufa"; m_actionFeedbackTimer = 1.8f;
        } else if (m_tileMap.plantCrop(tx, ty, CropType::Turnip, m_currentSeason)) { m_inventoryTurnipSeeds--; spentStamina = true; }
        else { m_actionFeedback = "Prepare um solo vazio primeiro"; m_actionFeedbackTimer = 1.4f; }
    } else if (tool == ToolType::PotatoSeeds && m_inventoryPotatoSeeds > 0) {
        if (!m_tileMap.isCropPlantableInSeason(tx, ty, CropType::Potato, m_currentSeason)) {
            m_actionFeedback = "Fora de estação: plante na estufa"; m_actionFeedbackTimer = 1.8f;
        } else if (m_tileMap.plantCrop(tx, ty, CropType::Potato, m_currentSeason)) { m_inventoryPotatoSeeds--; spentStamina = true; }
        else { m_actionFeedback = "Prepare um solo vazio primeiro"; m_actionFeedbackTimer = 1.4f; }
    } else if (tool == ToolType::PumpkinSeeds && m_inventoryPumpkinSeeds > 0) {
        if (!m_tileMap.isCropPlantableInSeason(tx, ty, CropType::Pumpkin, m_currentSeason)) {
            m_actionFeedback = "Fora de estação: plante na estufa"; m_actionFeedbackTimer = 1.8f;
        } else if (m_tileMap.plantCrop(tx, ty, CropType::Pumpkin, m_currentSeason)) { m_inventoryPumpkinSeeds--; spentStamina = true; }
        else { m_actionFeedback = "Prepare um solo vazio primeiro"; m_actionFeedbackTimer = 1.4f; }
    } else if (tool == ToolType::FenceBuild && m_inventoryWood >= 2) {
        if (m_tileMap.placeFence(tx, ty)) { m_inventoryWood -= 2; spentStamina = true; }
    } else if (tool == ToolType::SprinklerBuild && m_inventoryCopperOre >= 1 && m_inventoryIronOre >= 1) {
        if (m_tileMap.placeSprinkler(tx, ty)) { m_inventoryCopperOre--; m_inventoryIronOre--; spentStamina = true; }
    } else if (tool == ToolType::FurnitureBuild && m_inventoryWood >= 5) {
        if (m_tileMap.placeFurniture(tx, ty)) { m_inventoryWood -= 5; spentStamina = true; }
    } else if (tool == ToolType::KegBuild && m_inventoryWood >= 5 && m_inventoryCopperOre >= 2) {
        if (m_tileMap.placeKeg(tx, ty)) { m_inventoryWood -= 5; m_inventoryCopperOre -= 2; spentStamina = true; }
    } else if (tool == ToolType::ScarecrowBuild && m_inventoryWood >= 10 && m_inventoryGoldOre >= 1) {
        if (m_tileMap.placeScarecrow(tx, ty)) { m_inventoryWood -= 10; m_inventoryGoldOre--; spentStamina = true; }
    } else if (tool == ToolType::MayoBuild && m_inventoryWood >= 10 && m_inventoryIronOre >= 5) {
        if (m_tileMap.placeMayonnaiseMachine(tx, ty)) { m_inventoryWood -= 10; m_inventoryIronOre -= 5; spentStamina = true; }
    } else if (tool == ToolType::CheeseBuild && m_inventoryWood >= 10 && m_inventoryGoldOre >= 3) {
        if (m_tileMap.placeCheesePress(tx, ty)) { m_inventoryWood -= 10; m_inventoryGoldOre -= 3; spentStamina = true; }
    } else if (tool == ToolType::Hand) {
        CropType harvested; std::string product;
        if (m_tileMap.harvestCrop(tx, ty, harvested)) {
            if (harvested == CropType::Turnip) { m_inventoryTurnips++; m_money += 70; m_dailyEarnings += 70; }
            else if (harvested == CropType::Potato) { m_inventoryPotatoes++; m_money += 140; m_dailyEarnings += 140; }
            else if (harvested == CropType::Pumpkin) { m_inventoryPumpkins++; m_money += 350; m_dailyEarnings += 350; }
            m_dailyHarvestCount++;
            spentStamina = true;
        } else if (m_tileMap.collectEgg(tx, ty)) {
            m_inventoryEggs++; m_money += 80; m_dailyEarnings += 80; m_dailyHarvestCount++; spentStamina = true;
        } else if (m_tileMap.interactLivestock(tx, ty, product)) {
            if (product == "Vaca") { m_inventoryMilk++; m_money += 180; m_dailyEarnings += 180; }
            else if (product == "Ovelha") { m_inventoryWool++; m_money += 120; m_dailyEarnings += 120; }
            m_dailyHarvestCount++;
            spentStamina = true;
        }
    }

    if (spentStamina) {
        m_stamina -= 3.5f;
        if (m_stamina < 0.0f) m_stamina = 0.0f;
        m_player.triggerActionVisual();
        m_actionFeedbackTimer = 1.0f;
        switch (tool) {
            case ToolType::Hoe: m_actionFeedback = "Terra preparada"; break;
            case ToolType::WateringCan: m_actionFeedback = "Cultivo regado"; break;
            case ToolType::TurnipSeeds: case ToolType::PotatoSeeds: case ToolType::PumpkinSeeds: m_actionFeedback = "Semente plantada"; break;
            case ToolType::Hand: m_actionFeedback = "Coleta realizada"; break;
            case ToolType::Axe: m_actionFeedback = "Machado!"; break;
            case ToolType::Pickaxe: m_actionFeedback = "Picareta!"; break;
            default: m_actionFeedback = "Construção concluída"; break;
        }
        if (tool == ToolType::Hand) playSoundEffect(2);
        else if (tool == ToolType::WateringCan) playSoundEffect(7);
        else if (tool == ToolType::TurnipSeeds || tool == ToolType::PotatoSeeds || tool == ToolType::PumpkinSeeds) playSoundEffect(6);
        else playSoundEffect(8);
    }
}

void Game::talkOrCareAtTarget() {
    int tx, ty; m_player.getFacingTile(tx, ty);
    for (const auto& npc : m_tileMap.getNPCs()) {
        const int nx = static_cast<int>(std::floor((npc.x + 16.0f) / TileMap::TILE_SIZE));
        const int ny = static_cast<int>(std::floor((npc.y + 16.0f) / TileMap::TILE_SIZE));
        if (std::abs(nx - tx) <= 1 && std::abs(ny - ty) <= 1) {
            m_activeDialogue = npc.name + ": " + npc.dialogue;
            return;
        }
    }
    for (const auto& chicken : m_tileMap.getChickens()) {
        const int cx = static_cast<int>(std::floor((chicken.x + 16.0f) / TileMap::TILE_SIZE));
        const int cy = static_cast<int>(std::floor((chicken.y + 16.0f) / TileMap::TILE_SIZE));
        if (std::abs(cx - tx) <= 1 && std::abs(cy - ty) <= 1) {
            m_activeDialogue = chicken.hasEgg ? "Você cuidou da galinha. Há um ovo para recolher com X." : "Você fez carinho na galinha. Volte amanhã para o próximo ovo.";
            return;
        }
    }
    for (const auto& animal : m_tileMap.getLivestock()) {
        const int ax = static_cast<int>(std::floor((animal.x + 16.0f) / TileMap::TILE_SIZE));
        const int ay = static_cast<int>(std::floor((animal.y + 16.0f) / TileMap::TILE_SIZE));
        if (std::abs(ax - tx) <= 1 && std::abs(ay - ty) <= 1) {
            const bool cow = animal.type == "Vaca";
            const std::string product = cow ? "leite" : (animal.type == "Ovelha" ? "lã" : "produto");
            m_activeDialogue = animal.readyToHarvest
                ? ("Você cuidou do animal. Use X para recolher " + product + ".")
                : ("Você fez carinho no animal. O próximo produto (" + product + ") fica pronto amanhã.");
            return;
        }
    }
    m_activeDialogue = "Ninguém por perto para conversar ou cuidar.";
}

void Game::updateFishingMinigame(float dt) {
    m_barVelocity += 0.4f * dt;
    m_barPos += m_barVelocity * dt;
    if (m_barPos < 0.0f) { m_barPos = 0.0f; m_barVelocity = 0.0f; }
    if (m_barPos > 0.8f) { m_barPos = 0.8f; m_barVelocity = 0.0f; }

    m_fishPos += (static_cast<float>((std::rand() % 100) - 50) / 300.0f) * dt;
    m_fishPos = std::max(0.0f, std::min(1.0f, m_fishPos));

    if (m_fishPos >= m_barPos && m_fishPos <= (m_barPos + 0.2f)) m_catchProgress += 0.35f * dt;
    else m_catchProgress -= 0.25f * dt;

    if (m_catchProgress >= 1.0f) {
        m_inventoryFish++; m_money += 150; m_dailyEarnings += 150; m_dailyHarvestCount++;
        m_activeDialogue = "Você capturou um peixe!";
        m_isFishingActive = false; playSoundEffect(2);
    } else if (m_catchProgress <= 0.0f) {
        m_activeDialogue = "O peixe escapou!";
        m_isFishingActive = false;
    }
}

void Game::update(float dt) {
    if (m_gameState == GameState::MainMenu) return;
    if (dt < 0.0f) dt = 0.0f;
    if (m_actionFeedbackTimer > 0.0f) {
        m_actionFeedbackTimer = std::max(0.0f, m_actionFeedbackTimer - dt);
        if (m_actionFeedbackTimer <= 0.0f) m_actionFeedback.clear();
    }
    if (m_isFishingActive) { updateFishingMinigame(dt); return; }

    if (!anyOverlayOpen()) {
        m_player.update(dt, m_tileMap);
        m_tileMap.updateWeather(dt, SCREEN_W, SCREEN_H, m_camera, m_timeOfDayMinutes);
        if (m_player.isMoving()) {
            m_stepSoundTimer += dt;
            if (m_stepSoundTimer >= 0.52f) {
                m_stepSoundTimer = 0.0f;
                playSoundEffect(5);
            }
        } else m_stepSoundTimer = 0.0f;

        m_timeOfDayMinutes += static_cast<int>(dt * 15.0f);
        if (m_timeOfDayMinutes >= 2600) m_timeOfDayMinutes = 600;

        float tx = m_player.getCenterX() - SCREEN_W * 0.5f;
        float ty = m_player.getCenterY() - SCREEN_H * 0.5f;
        m_camera.x += (tx - m_camera.x) * (1.0f - std::exp(-10.0f * dt));
        m_camera.y += (ty - m_camera.y) * (1.0f - std::exp(-10.0f * dt));
        // Se o mapa for menor que a tela, o limite máximo vira 0 (mapa colado ao canto).
        float maxX = std::max(0.0f, static_cast<float>(m_tileMap.getPixelWidth() - SCREEN_W));
        float maxY = std::max(0.0f, static_cast<float>(m_tileMap.getPixelHeight() - SCREEN_H));
        m_camera.x = std::max(0.0f, std::min(m_camera.x, maxX));
        m_camera.y = std::max(0.0f, std::min(m_camera.y, maxY));
    }
}

void Game::render() {
    if (m_gameState == GameState::MainMenu) {
        drawMainMenu();
        m_renderer.present();
        return;
    }

    uint8_t skyR = 42, skyG = 78, skyB = 38;
    if (m_currentSeason == Season::Autumn) { skyR = 110; skyG = 65; skyB = 30; }
    else if (m_currentSeason == Season::Winter) { skyR = 140; skyG = 160; skyB = 185; }
    else if (m_currentSeason == Season::Summer) { skyR = 35; skyG = 95; skyB = 45; }

    m_renderer.clear(skyR, skyG, skyB);
    m_tileMap.render(m_renderer, m_camera, m_currentSeason, m_isRaining);
    m_player.render(m_renderer, m_camera);
    if (m_isRaining) m_renderer.drawLightingOverlay(0.07f, 64, 86, 116);

    float lightingIntensity = 0.0f;
    if (m_timeOfDayMinutes >= 1100 && m_timeOfDayMinutes < 1300) {
        lightingIntensity = static_cast<float>(m_timeOfDayMinutes - 1100) / 200.0f * 0.45f;
        m_renderer.drawLightingOverlay(lightingIntensity, 180, 80, 40);
    } else if (m_timeOfDayMinutes >= 1300 || m_timeOfDayMinutes < 600) {
        m_renderer.drawLightingOverlay(0.65f, 20, 30, 70);
    } else if (m_timeOfDayMinutes >= 600 && m_timeOfDayMinutes < 800) {
        lightingIntensity = (1.0f - static_cast<float>(m_timeOfDayMinutes - 600) / 200.0f) * 0.35f;
        m_renderer.drawLightingOverlay(lightingIntensity, 220, 140, 60);
    }

    drawHUD();
    drawQuickbar();
    drawControlsHint();

    if (m_isFishingActive) drawFishingMinigame();
    if (m_showBulletinBoard) drawBulletinBoard();
    if (m_showMineMenu) drawMineLevelSelector();
    if (m_showAchievements) drawAchievementsOverlay();
    if (m_showQuestJournal) drawQuestJournal();
    if (m_showInventoryMenu) drawInventoryMenu();
    if (m_showShopMenu) drawShopMenu();
    if (!m_activeDialogue.empty()) drawDialogueBox();

    m_renderer.present();
}

// Painel de madeira com título (usado por todos os menus).
void Game::drawPanel(int x, int y, int w, int h, const std::string& title) {
    m_renderer.drawScreenRect(x, y, w, h, 40, 28, 18, 238);
    m_renderer.drawScreenRectOutline(x, y, w, h, 220, 184, 112, 255);
    m_renderer.drawScreenRectOutline(x + 3, y + 3, w - 6, h - 6, 120, 84, 44, 255);
    if (!title.empty()) {
        m_renderer.drawTextCentered(title, x + w / 2, y + 14, 2, 255, 220, 120);
        m_renderer.drawScreenRect(x + 20, y + 50, w - 40, 2, 220, 184, 112, 255);
    }
}

void Game::drawMainMenu() {
    if (m_coverTexture) {
        m_renderer.drawFullscreenTexture(m_coverTexture);
    } else {
        m_renderer.clear(58, 140, 202);
        m_renderer.drawScreenRect(0, 400, SCREEN_W, 320, 94, 172, 74);
    }
    // Leve vinheta para manter contraste sem ocultar a nova arte de fundo.
    m_renderer.drawScreenRect(0, 0, SCREEN_W, SCREEN_H, 12, 20, 20, 42);
    m_renderer.drawTextShadow("STARDEW PS3", 62, 74, 5, 255, 224, 128);
    m_renderer.drawTextShadow("FAZENDA INDEPENDENTE  |  V2.6", 70, 124, 1, 255, 248, 220);
    if (m_showRecoveryPrompt) { drawRecoveryPrompt(); return; }
    if (m_showSettings) { drawSettingsMenu(); return; }
    if (m_showSaveSlots) { drawSaveSlotsMenu(); return; }
    // Painel translúcido em madeira: a ilustração continua visível por trás.
    const int px = 56, py = 250, pw = 428, ph = 348;
    m_renderer.drawScreenRect(px, py, pw, ph, 34, 27, 20, 218);
    m_renderer.drawScreenRectOutline(px, py, pw, ph, 236, 194, 116, 255);
    m_renderer.drawScreenRectOutline(px + 4, py + 4, pw - 8, ph - 8, 120, 84, 44, 255);
    m_renderer.drawText("BEM-VINDO A FAZENDA", px + 26, py + 18, 2, 255, 230, 166);
    m_renderer.drawScreenRect(px + 20, py + 52, pw - 40, 2, 180, 142, 82, 255);
    const char* options[5] = { m_hasStarted ? "Continuar" : "Novo Jogo", "Carregar slot ativo", "Selecionar slot", "Configuracoes", "Sair" };
    for (int i = 0; i < 5; ++i) {
        int oy = py + 66 + i * 49;
        bool sel = (m_mainMenuSelection == i);
        if (sel) {
            m_renderer.drawScreenRect(px + 20, oy - 4, pw - 40, 40, 194, 137, 48, 245);
            m_renderer.drawScreenRectOutline(px + 20, oy - 4, pw - 40, 40, 255, 218, 128, 255);
            m_renderer.drawText(">", px + 34, oy + 2, 2, 255, 255, 225);
        }
        m_renderer.drawTextShadow(options[i], px + 62, oy + 2, 2, 255, 244, 218);
    }
    if (!m_menuMessage.empty()) {
        m_renderer.drawScreenRect(px, py - 38, pw + 160, 32, 20, 12, 6, 225);
        m_renderer.drawText(m_menuMessage, px + 10, py - 34, 1, 255, 230, 160);
    }
    char slotline[64]; std::snprintf(slotline, sizeof(slotline), "Slot ativo: %d", m_saveSlot);
    m_renderer.drawTextShadow(slotline, SCREEN_W - 150, SCREEN_H - 26, 1, 255, 240, 190);
    m_renderer.drawTextShadow("D-pad/Setas: escolher   X/Enter: confirmar   O/Esc: voltar", 30, SCREEN_H - 27, 1, 255, 255, 240);
    if (m_pad.active()) m_renderer.drawTextShadow("Controle: " + m_pad.statusLine(), 30, SCREEN_H - 50, 1, 255, 255, 240);
    else if (m_gameController || m_joystick) m_renderer.drawTextShadow("Controle: SDL conectado", 30, SCREEN_H - 50, 1, 255, 255, 240);
    else m_renderer.drawTextShadow("Controle: nenhum detectado", 30, SCREEN_H - 50, 1, 255, 255, 240);
}

void Game::drawSaveSlotsMenu() {
    if (m_confirmSlotUse) {
        const int x = 220, y = 210, w = 840, h = 300;
        drawPanel(x, y, w, h, "Confirmar uso de slot ocupado");
        m_renderer.drawText("O proximo salvamento pode substituir os dados atuais.", x + 36, y + 100, 2, 255, 235, 205);
        const SaveSlots::FileStatus status = SaveSlots::inspect(saveSlotPath(m_slotCandidate), SAVE_MAGIC, SAVE_VERSION);
        if (status == SaveSlots::FileStatus::ValidHeader)
            m_renderer.drawText("Backup .bak sera tentado para o formato reconhecido.", x + 36, y + 140, 2, 220, 235, 200);
        else
            m_renderer.drawText("Formato nao reconhecido: nao ha garantia de backup automatico.", x + 36, y + 140, 2, 220, 235, 200);
        m_renderer.drawText("X: continuar e ativar slot   O: cancelar", x + 36, y + 220, 2, 255, 220, 120);
        return;
    }
    const int x = 250, y = 190, w = 780, h = 340;
    drawPanel(x, y, w, h, "Slots de salvamento");
    for (int i = 0; i < 3; ++i) {
        const int slot = i + 1;
        const SaveSlots::FileStatus primary = SaveSlots::inspect(saveSlotPath(slot), SAVE_MAGIC, SAVE_VERSION);
        const SaveSlots::FileStatus backup = SaveSlots::inspect(saveSlotBackupPath(slot), SAVE_MAGIC, SAVE_VERSION);
        const char* mainStatus = primary == SaveSlots::FileStatus::Missing ? "vazio" :
            primary == SaveSlots::FileStatus::ValidHeader ? "cabecalho reconhecido; validacao completa ao carregar" :
            primary == SaveSlots::FileStatus::UnsupportedVersion ? "versao nao suportada" : "arquivo/cabecalho invalido";
        const char* backupStatus = backup == SaveSlots::FileStatus::ValidHeader ? "backup disponivel" :
            backup == SaveSlots::FileStatus::Missing ? "sem backup" : "backup invalido ou incompativel";
        char label[128]; std::snprintf(label, sizeof(label), "Slot %d%s", slot, slot == 1 ? " (legado)" : "");
        char detail[144]; std::snprintf(detail, sizeof(detail), "%s | %s", mainStatus, backupStatus);
        const int rowY = y + 72 + i * 62;
        if (m_slotSelection == i) m_renderer.drawScreenRect(x + 20, rowY - 4, w - 40, 56, 112, 76, 38, 255);
        m_renderer.drawText(label, x + 38, rowY, 1, 255, 240, 210);
        m_renderer.drawText(detail, x + 38, rowY + 22, 1, 220, 220, 200);
    }
    const int backY = y + 82 + 3 * 52;
    if (m_slotSelection == 3) m_renderer.drawScreenRect(x + 24, backY - 5, w - 48, 38, 112, 76, 38, 255);
    m_renderer.drawText("Voltar", x + 48, backY, 2, 255, 240, 210);
    m_renderer.drawText("X ativa o slot para carregar e salvar; O/Escape volta.", x + 28, y + h - 30, 1, 230, 220, 190);
}

void Game::drawRecoveryPrompt() {
    const int x = 210, y = 220, w = 860, h = 270;
    drawPanel(x, y, w, h, "Recuperar backup?");
    m_renderer.drawText("O save principal nao passou na validacao completa.", x + 36, y + 94, 2, 255, 235, 205);
    m_renderer.drawText("Tentar copiar o backup para o slot ativo e validar novamente?", x + 36, y + 136, 2, 220, 235, 200);
    m_renderer.drawText("O original sera mantido temporariamente e restaurado se falhar.", x + 36, y + 178, 1, 220, 220, 190);
    m_renderer.drawText("X: tentar recuperacao   O: cancelar", x + 36, y + 220, 2, 255, 220, 120);
}

void Game::drawSettingsMenu() {
    const int x = 56, y = 90, w = SCREEN_W - 112, h = SCREEN_H - 180;
    drawPanel(x, y, w, h, "Configuracoes — v2.6");
    char a[96], b[96], c[96];
    std::snprintf(a, sizeof(a), "Zona morta: %d%%", static_cast<int>(m_stickDeadzone * 100.0f + 0.5f));
    std::snprintf(b, sizeof(b), "Sensibilidade: %d%%", static_cast<int>(m_stickSensitivity * 100.0f + 0.5f));
    std::snprintf(c, sizeof(c), "Volume da musica: %d/128", m_musicVolume);
    const char* rows[5] = { a, b, c, "Salvar preferencias agora", "Voltar" };
    for (int i = 0; i < 5; ++i) {
        int ry = y + 70 + i * 48;
        if (i == m_settingsSelection) m_renderer.drawScreenRect(x + 22, ry - 4, w - 44, 34, 112, 76, 38, 255);
        m_renderer.drawText(i == m_settingsSelection ? ">" : " ", x + 32, ry, 2, 255, 220, 120);
        m_renderer.drawText(rows[i], x + 58, ry, 2, 255, 240, 210);
    }
    m_renderer.drawText("Esquerda/direita ajustam; X seleciona; O volta.", x + 24, y + h - 38, 1, 230, 220, 190);
    if (m_pad.active()) {
        char diag[128];
        std::snprintf(diag, sizeof(diag), "Portas: %d | L: %+.2f,%+.2f | R: %+.2f,%+.2f", m_pad.connectedCount(), m_pad.leftX(), m_pad.leftY(), m_pad.rightX(), m_pad.rightY());
        m_renderer.drawText(diag, x + 24, y + h - 58, 1, 190, 220, 255);
    } else {
        m_renderer.drawText("Diagnostico: conecte o controle antes de iniciar.", x + 24, y + h - 58, 1, 190, 220, 255);
    }
}

void Game::drawHUD() {
    int hour = (m_timeOfDayMinutes / 100) % 24;
    int minute = ((m_timeOfDayMinutes % 100) * 60) / 100;

    m_renderer.drawScreenRect(12, 12, 420, 184, 40, 28, 18, 220);
    m_renderer.drawScreenRectOutline(12, 12, 420, 184, 220, 184, 112, 255);

    char buf[96];
    std::snprintf(buf, sizeof(buf), "Dia %d  %s  %02d:%02d", m_dayCount, seasonName(m_currentSeason), hour, minute);
    m_renderer.drawTextShadow(buf, 24, 22, 2, 255, 230, 160);

    std::snprintf(buf, sizeof(buf), "Ouro: %d   %s", m_money, m_isRaining ? "Chuva" : "Sol");
    m_renderer.drawTextShadow(buf, 24, 56, 2, 255, 255, 255);

    std::snprintf(buf, sizeof(buf), "Item: %s", toolName(m_player.getSelectedTool()));
    m_renderer.drawScreenRect(18, 84, 322, 30, 31, 50, 65, 235);
    m_renderer.drawScreenRectOutline(18, 84, 322, 30, 123, 190, 230, 255);
    m_renderer.drawTextShadow(buf, 24, 90, 2, 200, 235, 255);

    float ratio = std::max(0.0f, std::min(1.0f, m_stamina / m_maxStamina));
    m_renderer.drawText("Energia", 24, 124, 1, 255, 255, 255);
    m_renderer.drawScreenRect(88, 128, 328, 16, 60, 40, 30);
    m_renderer.drawScreenRect(88, 128, static_cast<int>(328.0f * ratio), 16, 74, 192, 96);
    m_renderer.drawScreenRectOutline(88, 128, 328, 16, 20, 12, 6);
    m_renderer.drawText(m_farmName, 24, 150, 1, 220, 200, 150);
    if (m_dayOfSeason == 7) m_renderer.drawText("Hoje: feira sazonal (+50% nas vendas)", 24, 168, 1, 255, 205, 112);
    else {
        char event[64]; std::snprintf(event, sizeof(event), "Feira sazonal em %d dia(s)", 7 - m_dayOfSeason);
        m_renderer.drawText(event, 24, 168, 1, 214, 202, 158);
    }
}

void Game::drawQuickbar() {
    static const ToolType tools[10] = {
        ToolType::Hoe, ToolType::WateringCan, ToolType::Axe, ToolType::Pickaxe, ToolType::FishingRod,
        ToolType::TurnipSeeds, ToolType::PotatoSeeds, ToolType::PumpkinSeeds, ToolType::FenceBuild, ToolType::SprinklerBuild
    };
    static const char* labels[10] = { "ENX", "REG", "MAC", "PIC", "PES", "NAB", "BAT", "ABO", "CER", "IRR" };
    const int cellW = 44, gap = 4, totalW = 10 * cellW + 9 * gap;
    const int x0 = (SCREEN_W - totalW) / 2, y0 = SCREEN_H - 86;
    const ToolType selected = m_player.getSelectedTool();
    if (selected == ToolType::TurnipSeeds || selected == ToolType::PotatoSeeds || selected == ToolType::PumpkinSeeds) {
        const char* guide = m_currentSeason == Season::Winter
            ? "Inverno: nabo, batata e abóbora só podem ser plantados na estufa"
            : "Estação atual: nabo, batata e abóbora podem ser plantados";
        m_renderer.drawScreenRect(x0 + 18, y0 - 22, totalW - 36, 18, 20, 27, 21, 218);
        m_renderer.drawTextCentered(guide, SCREEN_W / 2, y0 - 20, 1, 232, 239, 205);
    }
    m_renderer.drawScreenRect(x0 - 6, y0 - 5, totalW + 12, 66, 19, 23, 21, 225);
    m_renderer.drawScreenRectOutline(x0 - 6, y0 - 5, totalW + 12, 66, 118, 92, 59, 245);
    for (int i = 0; i < 10; ++i) {
        const int x = x0 + i * (cellW + gap);
        const bool selected = m_player.getSelectedTool() == tools[i];
        m_renderer.drawScreenRect(x, y0, cellW, 54, selected ? 112 : 46, selected ? 78 : 40, selected ? 37 : 31, 255);
        m_renderer.drawScreenRectOutline(x, y0, cellW, 54, selected ? 246 : 130, selected ? 202 : 104, selected ? 112 : 71, 255);
        m_renderer.drawText(i == 9 ? "0" : toStr(i + 1), x + 3, y0 + 2, 1, selected ? 255 : 185, selected ? 230 : 185, selected ? 153 : 185);
        m_renderer.drawText(labels[i], x + 5, y0 + 20, 1, 244, 232, 205);
        int quantity = -1;
        if (i == 5) quantity = m_inventoryTurnipSeeds;
        else if (i == 6) quantity = m_inventoryPotatoSeeds;
        else if (i == 7) quantity = m_inventoryPumpkinSeeds;
        else if (i == 8) quantity = m_inventoryWood / 2;
        else if (i == 9) quantity = std::min(m_inventoryCopperOre, m_inventoryIronOre);
        char amount[12];
        if (quantity < 0) std::snprintf(amount, sizeof(amount), "--");
        else std::snprintf(amount, sizeof(amount), "%d", quantity);
        m_renderer.drawText(amount, x + 5, y0 + 38, 1, quantity == 0 ? 180 : 218, quantity == 0 ? 120 : 205, quantity == 0 ? 100 : 160);
    }
}

void Game::drawControlsHint() {
    m_renderer.drawScreenRect(0, SCREEN_H - 24, SCREEN_W, 24, 0, 0, 0, 170);
    m_renderer.drawText("X Agir  O/T Conversar  1-0 Atalhos  L1/R1 Ferramenta  Tri Inventario  Start Menu  F5 Salvar",
                        6, SCREEN_H - 20, 1, 255, 255, 255, 230);
    if (m_actionFeedbackTimer > 0.0f && !m_actionFeedback.empty()) {
        m_renderer.drawScreenRect(488, SCREEN_H - 162, 304, 28, 31, 47, 34, 220);
        m_renderer.drawScreenRectOutline(488, SCREEN_H - 162, 304, 28, 226, 196, 113, 240);
        m_renderer.drawTextCentered(m_actionFeedback, SCREEN_W / 2, SCREEN_H - 156, 1, 255, 235, 175);
    } else if (m_gameState == GameState::Playing && !anyOverlayOpen()) {
        int tx, ty; m_player.getFacingTile(tx, ty);
        const CropData crop = m_tileMap.getCropAt(tx, ty);
        const TileType tile = m_tileMap.getTileAt(tx, ty);
        const ToolType tool = m_player.getSelectedTool();
        CropType selectedCrop = CropType::None;
        if (tool == ToolType::TurnipSeeds) selectedCrop = CropType::Turnip;
        else if (tool == ToolType::PotatoSeeds) selectedCrop = CropType::Potato;
        else if (tool == ToolType::PumpkinSeeds) selectedCrop = CropType::Pumpkin;
        const int maxStage = crop.type == CropType::Turnip ? 2 : (crop.type == CropType::Potato ? 3 : 4);
        const char* tip = nullptr;
        if (crop.type != CropType::None && crop.growthStage >= maxStage && tool == ToolType::Hand) tip = "X: colher plantação madura";
        else if (crop.type != CropType::None && tool == ToolType::WateringCan && !crop.watered) tip = "X: regar plantação";
        else if (selectedCrop != CropType::None && !m_tileMap.isCropPlantableInSeason(tx, ty, selectedCrop, m_currentSeason)) tip = "Inverno: plante sementes somente na estufa";
        else if (selectedCrop != CropType::None && ((tile == TileType::Dirt || tile == TileType::WateredDirt) && crop.type == CropType::None)) tip = "Estação adequada: X para plantar";
        else if ((tile == TileType::Dirt || tile == TileType::WateredDirt) && crop.type == CropType::None &&
                 (tool == ToolType::TurnipSeeds || tool == ToolType::PotatoSeeds || tool == ToolType::PumpkinSeeds)) tip = "X: plantar semente";
        else if ((tile == TileType::Grass || tile == TileType::TallGrass) && tool == ToolType::Hoe) tip = "X: preparar terra";
        if (tip) {
            m_renderer.drawScreenRect(458, SCREEN_H - 162, 364, 28, 31, 47, 34, 220);
            m_renderer.drawScreenRectOutline(458, SCREEN_H - 162, 364, 28, 104, 173, 116, 230);
            m_renderer.drawTextCentered(tip, SCREEN_W / 2, SCREEN_H - 156, 1, 219, 248, 206);
        }
    }
}

void Game::drawFishingMinigame() {
    const int px = (SCREEN_W - 220) / 2, py = 150, pw = 220, ph = 400;
    m_renderer.drawScreenRect(px, py, pw, ph, 20, 30, 50, 245);
    m_renderer.drawScreenRectOutline(px, py, pw, ph, 120, 200, 255, 255);
    m_renderer.drawTextCentered("Pescaria", SCREEN_W / 2, py + 8, 2, 200, 235, 255);

    const int trackTop = py + 50, trackH = 280;
    int barY = trackTop + static_cast<int>(m_barPos * static_cast<float>(trackH));
    int fishY = trackTop + static_cast<int>(m_fishPos * static_cast<float>(trackH));
    int barH = static_cast<int>(0.2f * static_cast<float>(trackH));
    m_renderer.drawScreenRect(px + 80, trackTop, 60, trackH + barH, 30, 50, 80, 255);
    m_renderer.drawScreenRect(px + 80, barY, 60, barH, 80, 200, 120);
    m_renderer.drawScreenRect(px + 100, fishY, 20, 20, 220, 80, 60);
    m_renderer.drawScreenRect(px + 30, py + 355, pw - 60, 16, 40, 40, 40);
    float prog = std::max(0.0f, std::min(1.0f, m_catchProgress));
    m_renderer.drawScreenRect(px + 30, py + 355, static_cast<int>(static_cast<float>(pw - 60) * prog), 16, 60, 220, 90);
    m_renderer.drawTextCentered("X: subir a barra", SCREEN_W / 2, py + 376, 1, 255, 255, 255);
}

void Game::drawDialogueBox() {
    const int x = 140, y = SCREEN_H - 220, w = SCREEN_W - 280, h = 180;
    m_renderer.drawScreenRect(x, y, w, h, 20, 20, 30, 242);
    m_renderer.drawScreenRectOutline(x, y, w, h, 220, 200, 120, 255);
    std::vector<std::string> lines = wrapText(m_activeDialogue, (w - 40) / 16);
    int ty = y + 16;
    for (size_t i = 0; i < lines.size() && i < 4; ++i) {
        m_renderer.drawText(lines[i], x + 20, ty, 2, 255, 255, 255);
        ty += 32;
    }
    m_renderer.drawText("X / O: fechar", x + w - 130, y + h - 22, 1, 200, 200, 160);
}

void Game::drawInventoryMenu() {
    const int w = 860, h = 540, x = (SCREEN_W - w) / 2, y = 70;
    static const char* categories[7] = { "Cultivos", "Pesca", "Animais", "Recursos", "Processados", "Sementes", "Refeições" };
    static const int itemIds[7][5] = {
        {0, 1, 2, -1, -1}, {3, -1, -1, -1, -1}, {4, 5, 6, -1, -1},
        {9, 10, 11, 12, 13}, {7, 8, 14, 15, -1}, {16, 17, 18, -1, -1}, {19, -1, -1, -1, -1}
    };
    drawPanel(x, y, w, h, std::string("Inventário — ") + categories[m_inventoryCategory]);
    std::array<int*, 20> refs = inventoryRefs();
    const int slotW = 150, slotH = 92, gap = 12;
    const int startX = x + (w - (5 * slotW + 4 * gap)) / 2;
    const int startY = y + 88;
    for (int i = 0; i < 5; ++i) {
        const int id = itemIds[m_inventoryCategory][i];
        if (id < 0) continue;
        int sx = startX + i * (slotW + gap);
        int sy = startY;
        bool has = *refs[id] > 0;
        m_renderer.drawScreenRect(sx, sy, slotW, slotH, has ? 62 : 44, has ? 48 : 36, has ? 34 : 28, 255);
        m_renderer.drawScreenRectOutline(sx, sy, slotW, slotH, 180, 140, 90, 255);
        m_renderer.drawText(ITEM_NAMES[id], sx + 8, sy + 8, 1, 255, 235, 190);
        char q[16]; std::snprintf(q, sizeof(q), "x%d", *refs[id]);
        m_renderer.drawText(q, sx + 8, sy + 44, 2, has ? 255 : 130, has ? 255 : 130, has ? 255 : 130);
    }
    for (int c = 0; c < 7; ++c) {
        int tx = x + 24 + c * 116;
        m_renderer.drawText(categories[c], tx, y + 492, 1, c == m_inventoryCategory ? 255 : 175,
                            c == m_inventoryCategory ? 220 : 175, c == m_inventoryCategory ? 130 : 175);
    }
    m_renderer.drawTextCentered("Esquerda/Direita ou L1/R1: categoria   Triângulo/O: fechar", x + w / 2, y + h - 28, 1, 220, 200, 150);
}

void Game::drawShopMenu() {
    const int w = 700, h = 540, x = (SCREEN_W - w) / 2, y = 80;
    drawPanel(x, y, w, h, "Loja da Fazenda");
    const char* options[4] = { "Comprar 5 sementes de nabo - 20g", "Comprar 5 sementes de batata - 50g", "Comprar 5 sementes de abobora - 100g", "Vender todo o inventario elegivel" };
    for (int i = 0; i < 4; ++i) {
        int yy = y + 100 + i * 58;
        if (i == m_shopSelection) {
            m_renderer.drawScreenRect(x + 24, yy - 8, w - 48, 42, 111, 78, 42, 255);
            m_renderer.drawScreenRectOutline(x + 24, yy - 8, w - 48, 42, 240, 196, 105, 255);
        }
        m_renderer.drawText(options[i], x + 40, yy, 1, 255, 240, 205);
    }
    char gold[48]; std::snprintf(gold, sizeof(gold), "Seu ouro: %dg", m_money);
    m_renderer.drawTextShadow(gold, x + 36, y + h - 86, 2, 255, 220, 120);
    m_renderer.drawTextCentered("Cima/Baixo: escolher  X: confirmar  Triangulo: vender tudo  O: fechar", x + w / 2, y + h - 34, 1, 220, 200, 150);
}

void Game::drawBulletinBoard() {
    const int w = 780, h = 430, x = (SCREEN_W - w) / 2, y = 130;
    drawPanel(x, y, w, h, "Quadro de Avisos");
    char request[144];
    std::snprintf(request, sizeof(request), "Pedido do dia: %d x %s", dailyRequestQuantity(), dailyRequestItemName().c_str());
    m_renderer.drawText(request, x + 30, y + 78, 2, 255, 230, 150);
    const int item = dailyRequestItemIndex();
    const int available = *inventoryRefs()[item];
    if (m_dailyRequestClaimed) m_renderer.drawText("Status: concluído — volte amanhã.", x + 30, y + 120, 2, 132, 230, 146);
    else if (available < dailyRequestQuantity()) m_renderer.drawText("Status: faltam materiais no inventário.", x + 30, y + 120, 2, 250, 154, 124);
    else m_renderer.drawText("Status: pronto para entregar (X / Enter).", x + 30, y + 120, 2, 132, 230, 146);
    static const int rewardValue[6] = { 40, 60, 120, 0, 50, 80 };
    char reward[80]; std::snprintf(reward, sizeof(reward), "Recompensa: %dg", rewardValue[item] * dailyRequestQuantity() + 50);
    m_renderer.drawText(reward, x + 30, y + 164, 2, 255, 220, 120);
    m_renderer.drawText("- Feira sazonal no dia 7: venda com bônus de 50%.", x + 30, y + 225, 1, 225, 230, 205);
    m_renderer.drawText("- Pierre: venda suas colheitas na loja (SELECT).", x + 30, y + 255, 1, 225, 230, 205);
    m_renderer.drawText("- Pesca: use a vara e aperte X perto da água.", x + 30, y + 285, 1, 225, 230, 205);
    m_renderer.drawTextCentered("X/Enter: entregar pedido   O/Esc: fechar", x + w / 2, y + h - 30, 1, 220, 200, 150);
}

void Game::drawMineLevelSelector() {
    const int w = 520, h = 300, x = (SCREEN_W - w) / 2, y = 180;
    drawPanel(x, y, w, h, "Minas");
    char buf[64];
    std::snprintf(buf, sizeof(buf), "Profundidade: %d", m_mineDepth);
    m_renderer.drawTextCentered(buf, x + w / 2, y + 90, 3, 255, 255, 255);
    m_renderer.drawTextCentered("Cima/Baixo: ajustar   O: fechar", x + w / 2, y + 170, 1, 220, 200, 150);
    m_renderer.drawTextCentered("Profundidade maior = minérios mais raros.", x + w / 2, y + 200, 1, 200, 200, 200);
}

void Game::drawAchievementsOverlay() {
    const int w = 720, h = 430, x = (SCREEN_W - w) / 2, y = 145;
    drawPanel(x, y, w, h, "Conquistas e estatisticas");
    m_renderer.drawText(m_achievementMillionaire ? "[x] Magnata da Fazenda (15000g)" : "[ ] Magnata da Fazenda (15000g)", x + 30, y + 80, 2, 255, 255, 255);
    m_renderer.drawText(m_achievementMasterFarmer ? "[x] Mestre Fazendeiro" : "[ ] Mestre Fazendeiro", x + 30, y + 120, 2, 255, 255, 255);
    m_renderer.drawText(m_achievementDeepMiner ? "[x] Mineiro das Profundezas" : "[ ] Mineiro das Profundezas", x + 30, y + 160, 2, 255, 255, 255);
    int activeCrops = 0, matureCrops = 0;
    for (const CropData& crop : m_tileMap.getCropsRef()) {
        if (crop.type != CropType::None) { ++activeCrops;
            int stage = crop.type == CropType::Turnip ? 2 : (crop.type == CropType::Potato ? 3 : 4);
            if (crop.growthStage >= stage) ++matureCrops;
        }
    }
    int friendship = 0;
    for (const NPC& npc : m_tileMap.getNPCs()) friendship += npc.friendshipLevel;
    char stats[128];
    std::snprintf(stats, sizeof(stats), "Fazenda: %dx%d tiles | cultivos ativos: %d (%d prontos)", m_tileMap.getWidthInTiles(), m_tileMap.getHeightInTiles(), activeCrops, matureCrops);
    m_renderer.drawText(stats, x + 30, y + 215, 1, 220, 235, 200);
    std::snprintf(stats, sizeof(stats), "Objetos: %lu | Galinhas: %lu | Outros animais: %lu", static_cast<unsigned long>(m_tileMap.getPropsRef().size()), static_cast<unsigned long>(m_tileMap.getChickens().size()), static_cast<unsigned long>(m_tileMap.getLivestock().size()));
    m_renderer.drawText(stats, x + 30, y + 242, 1, 220, 235, 200);
    std::snprintf(stats, sizeof(stats), "Moradores: %lu | amizade total: %d | Slot: %d", static_cast<unsigned long>(m_tileMap.getNPCs().size()), friendship, m_saveSlot);
    m_renderer.drawText(stats, x + 30, y + 269, 1, 220, 235, 200);
    m_renderer.drawTextCentered("O: fechar", x + w / 2, y + h - 28, 1, 220, 200, 150);
}

void Game::drawQuestJournal() {
    const int w = 640, h = 380, x = (SCREEN_W - w) / 2, y = 150;
    drawPanel(x, y, w, h, "Diário");
    char buf[96];
    std::snprintf(buf, sizeof(buf), "Nível de agricultura: %d", m_farmingLevel);
    m_renderer.drawText(buf, x + 30, y + 80, 2, 255, 255, 255);
    std::snprintf(buf, sizeof(buf), "Nível de mineração: %d", m_miningLevel);
    m_renderer.drawText(buf, x + 30, y + 115, 2, 255, 255, 255);
    std::snprintf(buf, sizeof(buf), "Nível de pesca: %d", m_fishingLevel);
    m_renderer.drawText(buf, x + 30, y + 150, 2, 255, 255, 255);
    std::snprintf(buf, sizeof(buf), "Nível de coleta: %d", m_forageLevel);
    m_renderer.drawText(buf, x + 30, y + 185, 2, 255, 255, 255);
    std::snprintf(buf, sizeof(buf), "Meta: chegar a 15000g (você tem %dg)", m_money);
    m_renderer.drawText(buf, x + 30, y + 240, 2, 255, 220, 120);
    m_renderer.drawTextCentered("O: fechar", x + w / 2, y + h - 30, 1, 220, 200, 150);
}

void Game::shutdown() {
#ifdef HAVE_SDL_MIXER
    if (m_sfxStep) { Mix_FreeChunk(m_sfxStep); m_sfxStep = nullptr; }
    if (m_sfxAction) { Mix_FreeChunk(m_sfxAction); m_sfxAction = nullptr; }
    if (m_sfxHarvest) { Mix_FreeChunk(m_sfxHarvest); m_sfxHarvest = nullptr; }
    if (m_sfxSleep) { Mix_FreeChunk(m_sfxSleep); m_sfxSleep = nullptr; }
    if (m_sfxFishBite) { Mix_FreeChunk(m_sfxFishBite); m_sfxFishBite = nullptr; }
    if (m_sfxWater) { Mix_FreeChunk(m_sfxWater); m_sfxWater = nullptr; }
    if (m_sfxPlant) { Mix_FreeChunk(m_sfxPlant); m_sfxPlant = nullptr; }
    if (m_sfxTool) { Mix_FreeChunk(m_sfxTool); m_sfxTool = nullptr; }
    if (m_bgmMusic) { Mix_FreeMusic(m_bgmMusic); m_bgmMusic = nullptr; }
    Mix_CloseAudio();
#endif
    m_pad.shutdown();
    if (m_gameController) {
        SDL_GameControllerClose(m_gameController);
        m_gameController = nullptr;
    }
    if (m_joystick) {
        SDL_JoystickClose(m_joystick);
        m_joystick = nullptr;
    }
    if (m_coverTexture) {
        SDL_DestroyTexture(m_coverTexture);
        m_coverTexture = nullptr;
    }
    m_player.shutdown();
    m_tileMap.shutdown();
    m_renderer.shutdown();
    SDL_Quit();
}
