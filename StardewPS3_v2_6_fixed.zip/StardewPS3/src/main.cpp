#include "Game.h"
#include "Paths.h"
#include "Platform.h"
#include <cstdio>
#ifdef STARDEW_ON_PS3
#include <sysmodule/sysmodule.h>
#endif

int main(int argc, char* argv[]) {
#ifdef STARDEW_ON_PS3
    // Os IDs disponíveis variam entre versões do PSL1GHT; carrega só os que existirem.
#ifdef SYSMODULE_FS
    sysModuleLoad(SYSMODULE_FS);
#endif
#ifdef SYSMODULE_IO
    sysModuleLoad(SYSMODULE_IO);
#endif
#ifdef SYSMODULE_AUDIO
    sysModuleLoad(SYSMODULE_AUDIO);
#endif
#endif
    Paths::init(argc > 0 ? argv[0] : nullptr);

    Game game;
    if (!game.init()) {
        std::printf("[Stardew] Falha ao inicializar o jogo.\n");
        return 1;
    }
    game.run();
    game.shutdown();
    return 0;
}
