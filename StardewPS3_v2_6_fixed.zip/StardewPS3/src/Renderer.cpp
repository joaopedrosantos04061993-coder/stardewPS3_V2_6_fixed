#include "Renderer.h"
#include "Font.h"
#include <cstdio>
#include <cmath>
#include <vector>

Renderer::Renderer()
    : m_window(nullptr), m_renderer(nullptr), m_width(Screen::WIDTH), m_height(Screen::HEIGHT), m_fontTexture(nullptr),
      m_drawR(0), m_drawG(0), m_drawB(0), m_drawA(0), m_drawColorCacheValid(false) {
    for (int i = 0; i < 256; ++i) m_glyphForLatin1[i] = -1;
}

Renderer::~Renderer() { shutdown(); }

bool Renderer::init(const char* title, int width, int height) {
    m_width = width;
    m_height = height;
    m_drawColorCacheValid = false;

    Uint32 windowFlags = SDL_WINDOW_SHOWN;
#ifdef STARDEW_ON_PS3
    windowFlags |= SDL_WINDOW_FULLSCREEN;
#endif

    m_window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, m_width, m_height, windowFlags);
    if (!m_window) return false;

    m_renderer = SDL_CreateRenderer(m_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!m_renderer) m_renderer = SDL_CreateRenderer(m_window, -1, 0);
    if (!m_renderer) return false;

    SDL_RenderSetLogicalSize(m_renderer, m_width, m_height);
    SDL_SetRenderDrawBlendMode(m_renderer, SDL_BLENDMODE_BLEND);
    if (!initFont()) std::printf("[Renderer] Aviso: falha ao criar a fonte.\n");
    return true;
}

void Renderer::shutdown() {
    if (m_fontTexture) { SDL_DestroyTexture(m_fontTexture); m_fontTexture = nullptr; }
    if (m_renderer) { SDL_DestroyRenderer(m_renderer); m_renderer = nullptr; }
    if (m_window) { SDL_DestroyWindow(m_window); m_window = nullptr; }
}

void Renderer::setDrawColor(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    if (m_drawColorCacheValid && r == m_drawR && g == m_drawG && b == m_drawB && a == m_drawA) return;
    SDL_SetRenderDrawColor(m_renderer, r, g, b, a);
    m_drawR = r; m_drawG = g; m_drawB = b; m_drawA = a;
    m_drawColorCacheValid = true;
}

void Renderer::clear(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    setDrawColor(r, g, b, a);
    SDL_RenderClear(m_renderer);
}

void Renderer::present() { SDL_RenderPresent(m_renderer); }

SDL_Texture* Renderer::loadTextureBMP(const std::string& path, bool useColorKey, uint8_t keyR, uint8_t keyG, uint8_t keyB) {
    SDL_Surface* surface = SDL_LoadBMP(path.c_str());
    if (!surface) return nullptr;
    if (useColorKey) {
        Uint32 key = SDL_MapRGB(surface->format, keyR, keyG, keyB);
        SDL_SetColorKey(surface, SDL_TRUE, key);
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
    SDL_FreeSurface(surface);
    if (texture) SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    return texture;
}

SDL_Texture* Renderer::createTextureFromRGBA(const uint32_t* pixels, int width, int height) {
    SDL_Texture* texture = SDL_CreateTexture(m_renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STATIC, width, height);
    if (!texture) return nullptr;
    SDL_UpdateTexture(texture, nullptr, pixels, width * static_cast<int>(sizeof(uint32_t)));
    SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    return texture;
}

void Renderer::drawSprite(SDL_Texture* texture, const Camera2D& camera, int srcX, int srcY, int srcW, int srcH, float worldX, float worldY, float dstW, float dstH) {
    if (!texture) return;
    SDL_Rect dst;
    dst.x = static_cast<int>(std::floor(worldX - camera.x));
    dst.y = static_cast<int>(std::floor(worldY - camera.y));
    dst.w = static_cast<int>(dstW);
    dst.h = static_cast<int>(dstH);

    if (dst.x + dst.w < 0 || dst.x > m_width || dst.y + dst.h < 0 || dst.y > m_height) return;
    SDL_Rect src = { srcX, srcY, srcW, srcH };
    SDL_RenderCopy(m_renderer, texture, &src, &dst);
}

void Renderer::drawWorldRect(const Camera2D& camera, float worldX, float worldY, float w, float h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_Rect dst;
    dst.x = static_cast<int>(std::floor(worldX - camera.x));
    dst.y = static_cast<int>(std::floor(worldY - camera.y));
    dst.w = static_cast<int>(w);
    dst.h = static_cast<int>(h);

    if (dst.x + dst.w < 0 || dst.x > m_width || dst.y + dst.h < 0 || dst.y > m_height) return;
    setDrawColor(r, g, b, a);
    SDL_RenderFillRect(m_renderer, &dst);
}

void Renderer::drawWorldRectOutline(const Camera2D& camera, float worldX, float worldY, float w, float h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_Rect dst;
    dst.x = static_cast<int>(std::floor(worldX - camera.x));
    dst.y = static_cast<int>(std::floor(worldY - camera.y));
    dst.w = static_cast<int>(w);
    dst.h = static_cast<int>(h);

    if (dst.x + dst.w < 0 || dst.x > m_width || dst.y + dst.h < 0 || dst.y > m_height) return;
    setDrawColor(r, g, b, a);
    SDL_RenderDrawRect(m_renderer, &dst);
}

void Renderer::drawScreenRect(int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_Rect dst = { x, y, w, h };
    setDrawColor(r, g, b, a);
    SDL_RenderFillRect(m_renderer, &dst);
}

void Renderer::drawScreenRectOutline(int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_Rect dst = { x, y, w, h };
    setDrawColor(r, g, b, a);
    SDL_RenderDrawRect(m_renderer, &dst);
}

void Renderer::drawLightingOverlay(float intensity, uint8_t r, uint8_t g, uint8_t b) {
    if (intensity <= 0.0f) return;
    uint8_t alpha = static_cast<uint8_t>(intensity * 220.0f);
    drawScreenRect(0, 0, m_width, m_height, r, g, b, alpha);
}

void Renderer::windowToLogical(int winX, int winY, int& logicalX, int& logicalY) const {
    int winW = m_width;
    int winH = m_height;
    SDL_GetWindowSize(m_window, &winW, &winH);
    if (winW <= 0 || winH <= 0) { logicalX = winX; logicalY = winY; return; }
    logicalX = (winX * m_width) / winW;
    logicalY = (winY * m_height) / winH;
}

// ---------------------------------------------------------------- texto

bool Renderer::initFont() {
    if (m_fontTexture) return true;
    const int cols = 16;
    const int rows = (Font::GLYPH_COUNT + cols - 1) / cols;
    const int atlasW = cols * Font::CELL_W;
    const int atlasH = rows * Font::CELL_H;
    std::vector<uint32_t> pixels(static_cast<size_t>(atlasW) * atlasH, 0x00000000u);

    for (int i = 0; i < Font::GLYPH_COUNT; ++i) {
        int gx = (i % cols) * Font::CELL_W;
        int gy = (i / cols) * Font::CELL_H;
        for (int y = 0; y < Font::CELL_H; ++y) {
            uint8_t row = Font::GLYPHS[i][y];
            for (int x = 0; x < Font::CELL_W; ++x) {
                if (row & (0x80 >> x)) pixels[static_cast<size_t>(gy + y) * atlasW + gx + x] = 0xFFFFFFFFu;
            }
        }
        uint16_t cp = Font::CODEPOINTS[i];
        if (cp < 256) m_glyphForLatin1[cp] = i;
    }
    m_fontTexture = createTextureFromRGBA(pixels.data(), atlasW, atlasH);
    return m_fontTexture != nullptr;
}

int Renderer::glyphFor(uint32_t cp) const {
    if (cp < 256 && m_glyphForLatin1[cp] >= 0) return m_glyphForLatin1[cp];
    for (int i = 0; i < Font::GLYPH_COUNT; ++i) {
        if (Font::CODEPOINTS[i] == cp) return i;
    }
    return m_glyphForLatin1[static_cast<int>('?')];
}

namespace {
// Decodifica um codepoint UTF-8 e avança o índice. Sequências inválidas viram '?'.
uint32_t nextCodepoint(const std::string& s, size_t& i) {
    unsigned char c = static_cast<unsigned char>(s[i++]);
    if (c < 0x80) return c;
    int extra = 0;
    uint32_t cp = 0;
    if ((c & 0xE0) == 0xC0) { extra = 1; cp = c & 0x1F; }
    else if ((c & 0xF0) == 0xE0) { extra = 2; cp = c & 0x0F; }
    else if ((c & 0xF8) == 0xF0) { extra = 3; cp = c & 0x07; }
    else return '?';
    for (int k = 0; k < extra; ++k) {
        if (i >= s.size() || (static_cast<unsigned char>(s[i]) & 0xC0) != 0x80) return '?';
        cp = (cp << 6) | (static_cast<unsigned char>(s[i++]) & 0x3F);
    }
    return cp;
}
}

int Renderer::textWidth(const std::string& text, int scale) const {
    int count = 0;
    size_t i = 0;
    while (i < text.size()) { nextCodepoint(text, i); ++count; }
    return count * Font::CELL_W * scale;
}

void Renderer::drawText(const std::string& text, int x, int y, int scale, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    if (!m_fontTexture || scale < 1) return;
    SDL_SetTextureColorMod(m_fontTexture, r, g, b);
    SDL_SetTextureAlphaMod(m_fontTexture, a);
    const int cols = 16;
    int penX = x;
    size_t i = 0;
    while (i < text.size()) {
        uint32_t cp = nextCodepoint(text, i);
        if (cp == '\n') { penX = x; y += (Font::CELL_H + 2) * scale; continue; }
        int gi = glyphFor(cp);
        if (gi >= 0 && cp != ' ') {
            SDL_Rect src = { (gi % cols) * Font::CELL_W, (gi / cols) * Font::CELL_H, Font::CELL_W, Font::CELL_H };
            SDL_Rect dst = { penX, y, Font::CELL_W * scale, Font::CELL_H * scale };
            SDL_RenderCopy(m_renderer, m_fontTexture, &src, &dst);
        }
        penX += Font::CELL_W * scale;
    }
}

void Renderer::drawTextShadow(const std::string& text, int x, int y, int scale, uint8_t r, uint8_t g, uint8_t b) {
    drawText(text, x + scale, y + scale, scale, 20, 12, 6, 200);
    drawText(text, x, y, scale, r, g, b, 255);
}

void Renderer::drawTextCentered(const std::string& text, int centerX, int y, int scale, uint8_t r, uint8_t g, uint8_t b) {
    drawTextShadow(text, centerX - textWidth(text, scale) / 2, y, scale, r, g, b);
}

void Renderer::drawFullscreenTexture(SDL_Texture* texture) {
    if (texture) SDL_RenderCopy(m_renderer, texture, nullptr, nullptr);
}
