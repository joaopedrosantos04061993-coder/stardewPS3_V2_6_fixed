#include "PadInput.h"
#include "Platform.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <utility>

#ifdef STARDEW_ON_PS3
#include <io/pad.h>
#endif

namespace {

const int NBTN = static_cast<int>(PadButton::Count);
const int WARMUP_FRAMES = 6;        // quadros ignorados após conectar (calibração dos analógicos)
const float DEADZONE = 0.24f;       // zona morta radial (equivale ao 8000/32767 do código original)
const float CENTER_MIN = 96.0f;     // centro calibrado fora de [96,160] => analógico suspeito, usa 128
const float CENTER_MAX = 160.0f;
const int GARBAGE_BUTTONS = 11;     // >= 11 botões "apertados" ao mesmo tempo = quadro inválido (clone)

char hex4(unsigned v) { return "0123456789ABCDEF"[v & 0xF]; }

// std::to_string pode faltar no newlib do PS3; usa snprintf.
std::string itos(int v) {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "%d", v);
    return buf;
}

std::string hexId(uint16_t v) {
    std::string s(4, '0');
    s[0] = hex4(v >> 12); s[1] = hex4(v >> 8); s[2] = hex4(v >> 4); s[3] = hex4(v);
    return s;
}

#ifdef STARDEW_ON_PS3

// Nomes dos tipos variam entre versões do PSL1GHT. O Makefile.ps3 detecta no io/pad.h e define
// STARDEW_PAD_LEGACY_TYPES (PadInfo/PadData) quando for o caso.
#ifdef STARDEW_PAD_LEGACY_TYPES
typedef PadInfo Ps3PadInfo;
typedef PadData Ps3PadData;
#else
typedef padInfo Ps3PadInfo;
typedef padData Ps3PadData;
#endif

const unsigned ERR_ALREADY_INITIALIZED = 0x80121104u;  // CELL_PAD_ERROR_ALREADY_INITIALIZED
const int PRESSURE_THRESHOLD = 0x80;

// Leitura nativa via libio (a mesma API que o XMB/jogos nativos usam para DualShock 3 e para
// o que o sistema expõe como pad). Não usa SDL, então não há dupla inicialização.
class Ps3PadBackend : public PadBackend {
public:
    Ps3PadBackend() : m_ownsInit(false), m_ready(false) { std::memset(&m_info, 0, sizeof(m_info)); }

    bool init() override {
        s32 r = ioPadInit(PadInput::MAX_PORTS);
        if (r == 0) m_ownsInit = true;
        else if (static_cast<unsigned>(r) != ERR_ALREADY_INITIALIZED) {
            std::printf("[Pad] ioPadInit falhou: 0x%08X\n", static_cast<unsigned>(r));
            return false;
        }
        // Valida de verdade: se não conseguir ler a lista de portas, o backend não serve.
        m_ready = (ioPadGetInfo(&m_info) == 0);
        if (!m_ready) {
            std::printf("[Pad] ioPadGetInfo falhou apos init\n");
            if (m_ownsInit) { ioPadEnd(); m_ownsInit = false; }
        }
        return m_ready;
    }

    void shutdown() override {
        if (m_ownsInit) { ioPadEnd(); m_ownsInit = false; }   // só encerra o que nós iniciamos
        m_ready = false;
    }

    int maxPorts() const override { return PadInput::MAX_PORTS; }

    bool refresh() override {
        if (!m_ready) return false;
        std::memset(&m_info, 0, sizeof(m_info));
        return ioPadGetInfo(&m_info) == 0;
    }

    bool portInfo(int port, bool& connected, uint16_t& vendorId, uint16_t& productId) override {
        connected = (m_info.status[port] != 0);
        vendorId = 0; productId = 0;
#ifdef STARDEW_PAD_HAS_VIDPID
        vendorId = static_cast<uint16_t>(m_info.vendor_id[port]);
        productId = static_cast<uint16_t>(m_info.product_id[port]);
#endif
        return true;
    }

    bool portData(int port, PadRawData& out) override {
        Ps3PadData d;
        std::memset(&d, 0, sizeof(d));
        out.valid = false;
        if (ioPadGetData(port, &d) != 0) return false;
        if (d.len <= 0) return false;                         // sem dados novos
#ifdef STARDEW_PAD_HAS_PRESSURE
        const bool l2 = d.BTN_L2 || d.PRE_L2 > PRESSURE_THRESHOLD;
        const bool r2 = d.BTN_R2 || d.PRE_R2 > PRESSURE_THRESHOLD;
#else
        const bool l2 = d.BTN_L2 != 0;
        const bool r2 = d.BTN_R2 != 0;
#endif
        out.btn[static_cast<int>(PadButton::Cross)] = d.BTN_CROSS;
        out.btn[static_cast<int>(PadButton::Circle)] = d.BTN_CIRCLE;
        out.btn[static_cast<int>(PadButton::Square)] = d.BTN_SQUARE;
        out.btn[static_cast<int>(PadButton::Triangle)] = d.BTN_TRIANGLE;
        out.btn[static_cast<int>(PadButton::Start)] = d.BTN_START;
        out.btn[static_cast<int>(PadButton::Select)] = d.BTN_SELECT;
        out.btn[static_cast<int>(PadButton::L1)] = d.BTN_L1;
        out.btn[static_cast<int>(PadButton::R1)] = d.BTN_R1;
        out.btn[static_cast<int>(PadButton::L2)] = l2;
        out.btn[static_cast<int>(PadButton::R2)] = r2;
        out.btn[static_cast<int>(PadButton::L3)] = d.BTN_L3;
        out.btn[static_cast<int>(PadButton::R3)] = d.BTN_R3;
        out.btn[static_cast<int>(PadButton::Up)] = d.BTN_UP;
        out.btn[static_cast<int>(PadButton::Down)] = d.BTN_DOWN;
        out.btn[static_cast<int>(PadButton::Left)] = d.BTN_LEFT;
        out.btn[static_cast<int>(PadButton::Right)] = d.BTN_RIGHT;
        out.lx = static_cast<uint8_t>(d.ANA_L_H);
        out.ly = static_cast<uint8_t>(d.ANA_L_V);
        out.rx = static_cast<uint8_t>(d.ANA_R_H);
        out.ry = static_cast<uint8_t>(d.ANA_R_V);
        out.valid = true;
        return true;
    }

private:
    Ps3PadInfo m_info;
    bool m_ownsInit;
    bool m_ready;
};

#endif // STARDEW_ON_PS3

}  // namespace

PadRawData::PadRawData() : valid(false), lx(128), ly(128), rx(128), ry(128) {
    for (int i = 0; i < NBTN; ++i) btn[i] = false;
}

PadInput::Port::Port()
    : warmup(0), sumLX(0), sumLY(0), sumRX(0), sumRY(0),
      cLX(128), cLY(128), cRX(128), cRY(128), lx(0), ly(0), rx(0), ry(0) {
    for (int i = 0; i < NBTN; ++i) btn[i] = false;
}

PadInput::PadInput() : m_lx(0), m_ly(0), m_rx(0), m_ry(0), m_deadzone(DEADZONE), m_sensitivity(1.0f) {
    for (int i = 0; i < NBTN; ++i) m_held[i] = false;
}

PadInput::~PadInput() { shutdown(); }

void PadInput::setDeadzone(float value) { m_deadzone = value < 0.05f ? 0.05f : (value > 0.50f ? 0.50f : value); }
void PadInput::setSensitivity(float value) { m_sensitivity = value < 0.50f ? 0.50f : (value > 1.50f ? 1.50f : value); }

bool PadInput::init() {
#ifdef STARDEW_ON_PS3
    return initWithBackend(std::unique_ptr<PadBackend>(new Ps3PadBackend()));
#else
    return false;   // fora do PS3 o jogo usa SDL_GameController/SDL_Joystick como antes
#endif
}

bool PadInput::initWithBackend(std::unique_ptr<PadBackend> backend) {
    shutdown();
    if (!backend || !backend->init()) return false;
    m_backend = std::move(backend);
    log("[Pad] backend nativo iniciado");
    return true;
}

void PadInput::shutdown() {
    if (m_backend) { m_backend->shutdown(); m_backend.reset(); }
    for (int i = 0; i < MAX_PORTS; ++i) m_ports[i] = Port();
    for (int i = 0; i < NBTN; ++i) m_held[i] = false;
    m_lx = m_ly = m_rx = m_ry = 0.0f;
    m_events.clear();
}

PadKind PadInput::classify(uint16_t vendorId, uint16_t productId) {
    if (vendorId == 0 && productId == 0) return PadKind::Unknown;   // libio não informou
    if (vendorId == 0x054C) {
        if (productId == 0x0268) return PadKind::DualShock3;
        if (productId == 0x05C4 || productId == 0x09CC) return PadKind::DualShock4;
    }
    // Observação: clones ("paralelos") frequentemente copiam o VID/PID da Sony, então este
    // valor NÃO distingue original de paralelo; a robustez vem da calibração/validação.
    return PadKind::Generic;
}

const char* PadInput::kindName(PadKind k) {
    switch (k) {
        case PadKind::DualShock3: return "DualShock 3";
        case PadKind::DualShock4: return "DualShock 4";
        case PadKind::Generic: return "Generico";
        default: return "Controle";
    }
}

float PadInput::normalize(uint8_t raw, float center) {
    float v = static_cast<float>(raw);
    float span = (v >= center) ? (255.0f - center) : center;
    if (span < 1.0f) span = 1.0f;
    float n = (v - center) / span;
    if (n > 1.0f) n = 1.0f;
    if (n < -1.0f) n = -1.0f;
    return n;
}

void PadInput::applyDeadzone(float& x, float& y, float deadzone, float sensitivity) {
    float mag = std::sqrt(x * x + y * y);
    if (mag < deadzone) { x = 0.0f; y = 0.0f; return; }
    float scaled = (mag - deadzone) / (1.0f - deadzone) * sensitivity;
    if (scaled > 1.0f) scaled = 1.0f;
    float k = scaled / mag;
    x *= k; y *= k;
}

void PadInput::log(const std::string& line) {
    m_log.push_back(line);
    std::printf("%s\n", line.c_str());
}

std::vector<std::string> PadInput::takeLogLines() {
    std::vector<std::string> out;
    out.swap(m_log);
    return out;
}

void PadInput::onConnect(int i) {
    Port& p = m_ports[i];
    p.warmup = WARMUP_FRAMES;
    p.sumLX = p.sumLY = p.sumRX = p.sumRY = 0.0f;
    p.cLX = p.cLY = p.cRX = p.cRY = 128.0f;
    p.lx = p.ly = p.rx = p.ry = 0.0f;
    for (int b = 0; b < NBTN; ++b) p.btn[b] = false;
    std::string s = "[Pad] porta " + itos(i) + " conectada: " + kindName(p.info.kind);
    s += " VID:PID=" + hexId(p.info.vendorId) + ":" + hexId(p.info.productId);
    log(s);
}

void PadInput::onDisconnect(int i) {
    Port& p = m_ports[i];
    log("[Pad] porta " + itos(i) + " desconectada");
    p = Port();
}

int PadInput::connectedCount() const {
    int n = 0;
    for (int i = 0; i < MAX_PORTS; ++i) if (m_ports[i].info.connected) ++n;
    return n;
}

std::string PadInput::statusLine() const {
    int n = connectedCount();
    if (!m_backend) return "API nativa indisponivel";
    if (n == 0) return "nenhum detectado";
    for (int i = 0; i < MAX_PORTS; ++i) {
        if (!m_ports[i].info.connected) continue;
        std::string s = kindName(m_ports[i].info.kind);
        if (m_ports[i].info.vendorId || m_ports[i].info.productId)
            s += " (" + hexId(m_ports[i].info.vendorId) + ":" + hexId(m_ports[i].info.productId) + ")";
        if (n > 1) s += " +" + itos(n - 1);
        return s;
    }
    return "nenhum detectado";
}

bool PadInput::popPress(PadButton& out) {
    if (m_events.empty()) return false;
    out = m_events.front();
    m_events.pop_front();
    return true;
}

void PadInput::poll() {
    if (!m_backend) return;
    if (!m_backend->refresh()) return;   // erro momentâneo: mantém o último estado

    const int ports = m_backend->maxPorts() < MAX_PORTS ? m_backend->maxPorts() : MAX_PORTS;
    for (int i = 0; i < ports; ++i) {
        bool connected = false;
        uint16_t vid = 0, pid = 0;
        m_backend->portInfo(i, connected, vid, pid);
        Port& p = m_ports[i];

        if (connected && !p.info.connected) {
            p.info.connected = true;
            p.info.vendorId = vid; p.info.productId = pid;
            p.info.kind = classify(vid, pid);
            onConnect(i);
        } else if (!connected && p.info.connected) {
            onDisconnect(i);
            continue;
        }
        if (!p.info.connected) continue;

        PadRawData d;
        if (!m_backend->portData(i, d) || !d.valid) continue;   // sem dados novos: mantém estado

        // Clones podem mandar quadros lixo (todos os botões ligados) ao conectar/acordar.
        int pressed = 0;
        for (int b = 0; b < NBTN; ++b) if (d.btn[b]) ++pressed;
        if (pressed >= GARBAGE_BUTTONS) continue;

        if (p.warmup > 0) {   // calibra o centro dos analógicos e ignora botões neste período
            p.sumLX += d.lx; p.sumLY += d.ly; p.sumRX += d.rx; p.sumRY += d.ry;
            if (--p.warmup == 0) {
                const float n = static_cast<float>(WARMUP_FRAMES);
                float c[4] = { p.sumLX / n, p.sumLY / n, p.sumRX / n, p.sumRY / n };
                bool ok = true;
                for (int k = 0; k < 4; ++k) if (c[k] < CENTER_MIN || c[k] > CENTER_MAX) ok = false;
                if (ok) { p.cLX = c[0]; p.cLY = c[1]; p.cRX = c[2]; p.cRY = c[3]; }
                else log("[Pad] porta " + itos(i) + ": centro dos analogicos fora do esperado, usando 128");
            }
            continue;
        }

        for (int b = 0; b < NBTN; ++b) p.btn[b] = d.btn[b];
        p.lx = normalize(d.lx, p.cLX); p.ly = normalize(d.ly, p.cLY);
        p.rx = normalize(d.rx, p.cRX); p.ry = normalize(d.ry, p.cRY);
        applyDeadzone(p.lx, p.ly, m_deadzone, m_sensitivity);
        applyDeadzone(p.rx, p.ry, m_deadzone, m_sensitivity);
    }

    // Mescla todas as portas conectadas: botão ligado em qualquer uma vale; analógico de maior módulo vence.
    bool now[NBTN];
    for (int b = 0; b < NBTN; ++b) now[b] = false;
    float bestL = 0.0f, bestR = 0.0f, lx = 0, ly = 0, rx = 0, ry = 0;
    for (int i = 0; i < MAX_PORTS; ++i) {
        const Port& p = m_ports[i];
        if (!p.info.connected) continue;
        for (int b = 0; b < NBTN; ++b) if (p.btn[b]) now[b] = true;
        float ml = p.lx * p.lx + p.ly * p.ly, mr = p.rx * p.rx + p.ry * p.ry;
        if (ml > bestL) { bestL = ml; lx = p.lx; ly = p.ly; }
        if (mr > bestR) { bestR = mr; rx = p.rx; ry = p.ry; }
    }
    for (int b = 0; b < NBTN; ++b) {
        if (now[b] && !m_held[b]) m_events.push_back(static_cast<PadButton>(b));
        m_held[b] = now[b];
    }
    m_lx = lx; m_ly = ly; m_rx = rx; m_ry = ry;
}
