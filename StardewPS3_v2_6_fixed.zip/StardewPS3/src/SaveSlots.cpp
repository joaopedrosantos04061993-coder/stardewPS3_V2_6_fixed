#include "SaveSlots.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>

namespace SaveSlots {

bool valid(int slot) { return slot >= 1 && slot <= COUNT; }

std::string fileName(int slot) {
    if (!valid(slot)) return std::string();
    if (slot == 1) return "save_v1.6.dat";
    char name[32];
    std::snprintf(name, sizeof(name), "save_slot%d.dat", slot);
    return name;
}

std::string backupFileName(int slot) {
    if (!valid(slot)) return std::string();
    if (slot == 1) return "save_v1.6.bak";
    char name[32];
    std::snprintf(name, sizeof(name), "save_slot%d.bak", slot);
    return name;
}

FileStatus inspect(const std::string& path, const char magic[8], int version) {
    std::ifstream f(path.c_str(), std::ios::binary);
    if (!f) return FileStatus::Missing;
    char actualMagic[8];
    int actualVersion = 0;
    if (!f.read(actualMagic, sizeof(actualMagic)) || !f.read(reinterpret_cast<char*>(&actualVersion), sizeof(actualVersion)))
        return FileStatus::InvalidHeader;
    if (!std::equal(actualMagic, actualMagic + 8, magic)) return FileStatus::InvalidHeader;
    if (actualVersion != version) return FileStatus::UnsupportedVersion;
    f.seekg(0, std::ios::end);
    if (!f || f.tellg() <= static_cast<std::streamoff>(sizeof(actualMagic) + sizeof(actualVersion)))
        return FileStatus::InvalidHeader;
    return FileStatus::ValidHeader;
}

bool copyFile(const std::string& source, const std::string& destination) {
    std::ifstream in(source.c_str(), std::ios::binary);
    if (!in) return false;
    std::ofstream out(destination.c_str(), std::ios::binary | std::ios::trunc);
    if (!out) return false;
    char buffer[4096];
    while (in) {
        in.read(buffer, sizeof(buffer));
        const std::streamsize count = in.gcount();
        if (count > 0) out.write(buffer, count);
    }
    if (!in.eof() || in.bad()) return false;
    out.flush();
    if (!out.good()) return false;
    in.close(); out.close();
    if (out.fail()) return false;
    std::ifstream verifySource(source.c_str(), std::ios::binary);
    std::ifstream verifyDestination(destination.c_str(), std::ios::binary);
    if (!verifySource || !verifyDestination) return false;
    char a[4096], b[4096];
    for (;;) {
        verifySource.read(a, sizeof(a)); verifyDestination.read(b, sizeof(b));
        const std::streamsize na = verifySource.gcount(), nb = verifyDestination.gcount();
        if (na != nb || na < 0 || (na > 0 && std::memcmp(a, b, static_cast<size_t>(na)) != 0)) return false;
        if (na == 0) return verifySource.eof() && verifyDestination.eof();
    }
}

}
