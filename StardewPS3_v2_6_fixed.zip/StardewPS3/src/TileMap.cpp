#include "TileMap.h"
#include "Paths.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace {
    inline uint32_t packRGBA(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) {
        return (static_cast<uint32_t>(r) << 24) |
               (static_cast<uint32_t>(g) << 16) |
               (static_cast<uint32_t>(b) << 8)  |
               static_cast<uint32_t>(a);
    }
}

TileMap::TileMap() : m_width(0), m_height(0), m_tilesetTexture(nullptr), m_actorTexture(nullptr), m_visualTime(0.0f) {}

TileMap::~TileMap() { shutdown(); }

bool TileMap::initTextures(Renderer& renderer) {
    shutdown();
    // Atlas procedural v2.3: mantém as células 32x32 e os índices legados.
    buildProceduralTileset(renderer);
    buildActorAtlas(renderer);
    return (m_tilesetTexture != nullptr && m_actorTexture != nullptr);
}

void TileMap::shutdown() {
    if (m_tilesetTexture) { SDL_DestroyTexture(m_tilesetTexture); m_tilesetTexture = nullptr; }
    if (m_actorTexture) { SDL_DestroyTexture(m_actorTexture); m_actorTexture = nullptr; }
}

void TileMap::buildActorAtlas(Renderer& renderer) {
    const int width = 5 * TILE_SIZE;
    std::vector<uint32_t> pixels(static_cast<size_t>(width) * TILE_SIZE, packRGBA(0, 0, 0, 0));
    auto px = [&](int sprite, int x, int y, uint32_t color) {
        if (sprite >= 0 && sprite < 5 && x >= 0 && x < 32 && y >= 0 && y < 32)
            pixels[static_cast<size_t>(y) * width + sprite * TILE_SIZE + x] = color;
    };
    auto rect = [&](int sprite, int x, int y, int w, int h, uint32_t color) {
        for (int yy = y; yy < y + h; ++yy) for (int xx = x; xx < x + w; ++xx) px(sprite, xx, yy, color);
    };
    const uint32_t outline = packRGBA(54, 48, 39), shadow = packRGBA(28, 36, 27, 95);
    // Hen: clean silhouette, feather clusters, comb, beak and legs.
    rect(0, 8, 25, 16, 3, shadow); rect(0, 10, 12, 14, 13, packRGBA(244, 239, 222));
    rect(0, 7, 15, 5, 7, packRGBA(224, 215, 194)); rect(0, 12, 14, 9, 6, packRGBA(255, 251, 236));
    rect(0, 18, 8, 9, 9, packRGBA(249, 244, 227)); rect(0, 20, 6, 5, 3, packRGBA(198, 60, 53));
    rect(0, 25, 12, 4, 3, packRGBA(237, 174, 61)); rect(0, 13, 25, 2, 5, packRGBA(195, 127, 43)); rect(0, 21, 25, 2, 5, packRGBA(195, 127, 43));
    px(0, 22, 10, outline); px(0, 23, 10, outline); px(0, 12, 17, packRGBA(180, 156, 123));
    // Cow: larger cream body, shaded patchwork, ears/horns and muzzle.
    rect(1, 4, 25, 24, 3, shadow); rect(1, 4, 13, 20, 12, packRGBA(239, 234, 218));
    rect(1, 18, 11, 11, 13, packRGBA(248, 241, 225)); rect(1, 20, 18, 9, 6, packRGBA(224, 151, 145));
    rect(1, 5, 14, 6, 6, packRGBA(99, 64, 54)); rect(1, 12, 18, 5, 5, packRGBA(116, 75, 60));
    rect(1, 19, 7, 3, 5, packRGBA(194, 151, 105)); rect(1, 25, 8, 3, 5, packRGBA(194, 151, 105));
    rect(1, 21, 5, 2, 4, packRGBA(244, 226, 186)); rect(1, 25, 5, 2, 4, packRGBA(244, 226, 186));
    rect(1, 7, 24, 3, 5, packRGBA(87, 65, 51)); rect(1, 22, 24, 3, 5, packRGBA(87, 65, 51));
    px(1, 22, 15, outline); px(1, 26, 15, outline); px(1, 23, 20, packRGBA(108, 57, 58)); px(1, 26, 20, packRGBA(108, 57, 58));
    // Sheep: layered wool clusters with a distinct warm face and dark feet.
    rect(2, 3, 25, 26, 3, shadow);
    for (int y = 10; y <= 22; y += 4) for (int x = 4 + ((y / 4) & 1) * 3; x <= 23; x += 6)
        rect(2, x, y, 7, 6, packRGBA(247, 244, 230));
    rect(2, 20, 12, 9, 11, packRGBA(207, 178, 157)); rect(2, 22, 8, 5, 6, packRGBA(232, 205, 185));
    rect(2, 6, 23, 3, 6, packRGBA(79, 68, 61)); rect(2, 22, 23, 3, 6, packRGBA(79, 68, 61));
    px(2, 23, 13, outline); px(2, 26, 13, outline); rect(2, 24, 18, 3, 2, packRGBA(154, 104, 103));
    // Two villager sprites: recognizable outfits, hair shapes and facial features.
    for (int s = 3; s <= 4; ++s) {
        const bool robin = s == 4;
        const uint32_t shirt = robin ? packRGBA(186, 92, 69) : packRGBA(76, 128, 174);
        const uint32_t hair = robin ? packRGBA(158, 79, 48) : packRGBA(104, 68, 44);
        rect(s, 5, 26, 22, 3, shadow); rect(s, 9, 21, 5, 8, packRGBA(62, 79, 112)); rect(s, 18, 21, 5, 8, packRGBA(62, 79, 112));
        rect(s, 7, 12, 19, 12, shirt); rect(s, 10, 5, 13, 11, packRGBA(232, 189, 151));
        rect(s, 8, 3, 17, 5, hair); rect(s, 7, 6, 4, 8, hair); rect(s, 21, 6, 4, 7, hair);
        rect(s, 10, 13, 13, 3, packRGBA(247, 211, 169));
        px(s, 12, 9, outline); px(s, 20, 9, outline); rect(s, 15, 12, 3, 1, packRGBA(156, 80, 66));
        rect(s, 7, 13, 3, 8, robin ? packRGBA(164, 75, 59) : packRGBA(62, 108, 153));
        rect(s, 23, 13, 3, 8, robin ? packRGBA(164, 75, 59) : packRGBA(62, 108, 153));
    }
    m_actorTexture = renderer.createTextureFromRGBA(pixels.data(), width, TILE_SIZE);
}

void TileMap::buildProceduralTileset(Renderer& renderer) {
    const int sheetW = 36 * 32;
    const int sheetH = 32;
    std::vector<uint32_t> pixels(sheetW * sheetH, packRGBA(0, 0, 0, 0));

    auto putPx = [&](int tileIdx, int x, int y, uint32_t color) {
        if (x >= 0 && x < 32 && y >= 0 && y < 32) {
            pixels[y * sheetW + (tileIdx * 32 + x)] = color;
        }
    };
    auto rect = [&](int t, int x, int y, int w, int h, uint32_t c) {
        for (int py = y; py < y + h; ++py) for (int px = x; px < x + w; ++px) putPx(t, px, py, c);
    };
    auto hash = [](int x, int y, int seed) -> uint32_t {
        uint32_t n = static_cast<uint32_t>(x * 374761393u + y * 668265263u + seed * 2246822519u);
        n = (n ^ (n >> 13)) * 1274126177u;
        return n ^ (n >> 16);
    };
    auto base = [&](int t, uint32_t c) { rect(t, 0, 0, 32, 32, c); };

    // Earth and floor tiles: restrained pixel clusters with clean, repeatable edges.
    base(0, packRGBA(55, 125, 58));
    base(1, packRGBA(139, 91, 53));
    base(2, packRGBA(88, 70, 58));
    base(3, packRGBA(55, 128, 53));
    base(4, packRGBA(52, 123, 174));
    base(5, packRGBA(60, 66, 76));
    base(6, packRGBA(128, 83, 52));
    base(7, packRGBA(134, 158, 139));
    for (int y = 0; y < 32; ++y) for (int x = 0; x < 32; ++x) {
        uint32_t n = hash(x, y, 3);
        if ((n % 100) < 18) {
            int dx = static_cast<int>((n >> 8) % 3);
            putPx(0, x, y, packRGBA(82 + dx * 8, 145 + dx * 8, 66 + dx * 4));
        }
        if ((n % 100) < 16) putPx(1, x, y, (n & 256) ? packRGBA(163, 112, 64) : packRGBA(112, 73, 47));
        if ((n % 100) < 12) putPx(2, x, y, (n & 256) ? packRGBA(113, 92, 73) : packRGBA(65, 59, 54));
        if ((n % 100) < 20) putPx(3, x, y, (n & 256) ? packRGBA(73, 151, 58) : packRGBA(43, 105, 48));
        if ((n % 100) < 8) putPx(4, x, y, packRGBA(86, 159, 198));
        if ((n % 100) < 13) putPx(5, x, y, (n & 256) ? packRGBA(89, 96, 105) : packRGBA(43, 49, 59));
        if ((n % 100) < 14) putPx(6, x, y, (n & 256) ? packRGBA(156, 105, 67) : packRGBA(100, 62, 45));
        if ((n % 100) < 12) putPx(7, x, y, (n & 256) ? packRGBA(170, 188, 165) : packRGBA(107, 135, 124));
    }
    // Subtle, tile-contained motifs help readability at 32px scale.
    for (int x = 3; x < 32; x += 8) { putPx(0, x, (x * 3) % 29 + 1, packRGBA(142, 186, 91)); putPx(3, x + 1, (x * 5) % 28 + 2, packRGBA(165, 194, 91)); }
    for (int y = 5; y < 32; y += 8) { rect(6, 0, y, 32, 1, packRGBA(105, 66, 45)); rect(7, 0, y, 32, 1, packRGBA(102, 129, 119)); }
    for (int y = 4; y < 32; y += 8) { rect(4, 0, y, 32, 1, packRGBA(43, 104, 158)); for (int x = 5 + (y % 7); x < 32; x += 13) rect(4, x, y - 1, 5, 1, packRGBA(134, 191, 215)); }
    for (int y = 7; y < 30; y += 9) for (int x = 5 + (y % 6); x < 30; x += 12) {
        putPx(5, x, y, packRGBA(129, 133, 139)); putPx(5, x + 1, y, packRGBA(129, 133, 139));
    }
    // Tree (8), fence (9), stump (10), rock (11), flower patch (12).
    rect(8, 14, 17, 5, 13, packRGBA(105, 65, 38));
    for (int y = 4; y < 23; ++y) for (int x = 4; x < 28; ++x) {
        int dx = x - 16, dy = y - 13;
        if (dx * dx + dy * dy < 150 && ((hash(x, y, 8) % 100) < 85))
            putPx(8, x, y, (y < 12) ? packRGBA(58, 145, 61) : packRGBA(43, 117, 53));
    }
    for (int x = 8; x < 25; x += 8) putPx(8, x, 9, packRGBA(119, 182, 76));
    rect(9, 4, 9, 4, 20, packRGBA(128, 82, 48)); rect(9, 24, 9, 4, 20, packRGBA(128, 82, 48));
    rect(9, 2, 12, 28, 4, packRGBA(176, 125, 73)); rect(9, 2, 20, 28, 4, packRGBA(151, 100, 59));
    rect(9, 3, 12, 26, 1, packRGBA(207, 157, 94)); rect(9, 3, 20, 26, 1, packRGBA(187, 130, 73));
    rect(10, 7, 13, 18, 13, packRGBA(126, 76, 44)); rect(10, 6, 11, 20, 4, packRGBA(160, 105, 62));
    rect(10, 10, 17, 2, 9, packRGBA(89, 53, 37)); rect(10, 15, 12, 2, 13, packRGBA(188, 132, 74));
    for (int y = 9; y < 27; ++y) for (int x = 5; x < 28; ++x) {
        int dx = x - 16, dy = y - 18;
        if (dx * dx / 2 + dy * dy < 100) putPx(11, x, y, ((x + y) % 5 == 0) ? packRGBA(176, 180, 177) : packRGBA(117, 125, 132));
    }
    rect(11, 11, 12, 8, 2, packRGBA(206, 211, 207)); rect(11, 9, 17, 2, 2, packRGBA(85, 93, 102));
    base(12, packRGBA(70, 119, 51));
    for (int x = 4; x < 30; x += 8) { rect(12, x, 9 + (x % 5), 2, 15, packRGBA(46, 96, 47)); putPx(12, x - 2, 10 + (x % 5), packRGBA(235, 187, 71)); putPx(12, x + 2, 13 + (x % 5), packRGBA(242, 218, 132)); }
    // Sprinkler, furniture, keg, scarecrow, mayonnaise machine, cheese press.
    rect(13, 13, 9, 6, 5, packRGBA(82, 119, 142)); rect(13, 10, 14, 12, 4, packRGBA(112, 151, 165));
    rect(13, 15, 18, 2, 8, packRGBA(82, 95, 100));
    putPx(13, 8, 11, packRGBA(123, 207, 227)); putPx(13, 23, 11, packRGBA(123, 207, 227));
    rect(14, 7, 11, 18, 3, packRGBA(157, 104, 65)); rect(14, 9, 14, 14, 9, packRGBA(184, 123, 76));
    rect(14, 10, 23, 3, 6, packRGBA(103, 68, 48)); rect(14, 20, 23, 3, 6, packRGBA(103, 68, 48));
    rect(15, 9, 7, 14, 20, packRGBA(119, 66, 39)); rect(15, 7, 9, 18, 3, packRGBA(166, 101, 55));
    rect(15, 7, 23, 18, 3, packRGBA(166, 101, 55)); rect(15, 14, 8, 2, 19, packRGBA(91, 50, 36));
    rect(16, 14, 8, 4, 17, packRGBA(116, 78, 47)); rect(16, 9, 6, 14, 3, packRGBA(210, 173, 111));
    rect(16, 8, 7, 16, 3, packRGBA(211, 166, 87)); rect(16, 11, 12, 10, 8, packRGBA(168, 104, 65));
    rect(16, 12, 15, 2, 2, packRGBA(54, 45, 38)); rect(16, 18, 15, 2, 2, packRGBA(54, 45, 38));
    rect(16, 10, 21, 12, 3, packRGBA(78, 116, 57)); rect(16, 14, 25, 4, 5, packRGBA(87, 63, 43));
    rect(17, 7, 12, 18, 14, packRGBA(209, 207, 190)); rect(17, 10, 7, 12, 6, packRGBA(229, 224, 206));
    rect(17, 9, 15, 14, 8, packRGBA(153, 171, 166)); rect(17, 12, 17, 8, 4, packRGBA(104, 145, 146));
    rect(17, 12, 23, 8, 3, packRGBA(86, 67, 48)); rect(17, 13, 9, 6, 2, packRGBA(255, 227, 148));
    rect(18, 7, 11, 18, 16, packRGBA(193, 155, 79)); rect(18, 10, 8, 12, 5, packRGBA(220, 187, 104));
    rect(18, 9, 14, 14, 9, packRGBA(234, 208, 132)); rect(18, 12, 18, 8, 3, packRGBA(255, 234, 169));
    rect(18, 12, 23, 8, 4, packRGBA(104, 72, 45));
    rect(19, 7, 10, 18, 16, packRGBA(128, 94, 65)); rect(19, 10, 12, 12, 12, packRGBA(177, 139, 89));
    rect(19, 12, 14, 8, 8, packRGBA(229, 205, 151));

    // Four seasonal palettes with four deterministic variants each.
    const uint8_t seasonal[4][3] = { {63, 137, 62}, {70, 151, 58}, {157, 119, 57}, {177, 199, 207} };
    for (int s = 0; s < 4; ++s) {
        for (int v = 0; v < 4; ++v) {
            const int t = 20 + s * 4 + v;
            base(t, packRGBA(seasonal[s][0], seasonal[s][1], seasonal[s][2]));
            for (int y = 0; y < 32; ++y) for (int x = 0; x < 32; ++x) {
                const uint32_t n = hash(x, y, 80 + s * 4 + v);
                if ((n % 100) < 17) {
                    const int k = static_cast<int>((n >> 8) % 25) - 12;
                    const int r = std::max(0, std::min(255, static_cast<int>(seasonal[s][0]) + k));
                    const int g = std::max(0, std::min(255, static_cast<int>(seasonal[s][1]) + k));
                    const int b = std::max(0, std::min(255, static_cast<int>(seasonal[s][2]) + k));
                    putPx(t, x, y, packRGBA(static_cast<uint8_t>(r), static_cast<uint8_t>(g), static_cast<uint8_t>(b)));
                }
            }
            // Compact tufts/flowers/snow flecks vary by tile but stay away from the border seam.
            for (int k = 0; k < 4 + v; ++k) {
                const int x = 3 + static_cast<int>(hash(k, v, s + 5) % 26);
                const int y = 3 + static_cast<int>(hash(v, k, s + 11) % 26);
                if (s == 3) {
                    putPx(t, x, y, packRGBA(237, 245, 247));
                    putPx(t, x + 1, y, packRGBA(210, 226, 230));
                } else if (s == 2) {
                    putPx(t, x, y, (v & 1) ? packRGBA(205, 151, 68) : packRGBA(179, 90, 48));
                } else if (s == 0 && v == 3) {
                    putPx(t, x, y, packRGBA(242, 218, 135));
                    putPx(t, x + 1, y, packRGBA(242, 218, 135));
                } else {
                    putPx(t, x, y, packRGBA(39, 101, 48));
                    putPx(t, x, y - 1, packRGBA(117, 173, 72));
                }
            }
        }
    }

    m_tilesetTexture = renderer.createTextureFromRGBA(pixels.data(), sheetW, sheetH);
}

void TileMap::generateInitialFarm(int widthInTiles, int heightInTiles) {
    m_visualTime = 0.0f;
    m_width = widthInTiles;
    m_height = heightInTiles;
    m_tiles.assign(m_width * m_height, TileType::Grass);
    m_crops.assign(m_width * m_height, { CropType::None, 0, false });
    m_props.clear();
    m_chickens.clear();
    m_livestock.clear();
    m_npcs.clear();
    m_chickenHomes.clear();
    m_livestockHomes.clear();
    m_npcHomes.clear();
    m_weatherParticles.clear();

    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            if (x >= 2 && x <= 8 && y >= 2 && y <= 7) {
                setTileAt(x, y, TileType::GreenhouseFloor);
            } else if (x >= 30 && x <= 38 && y >= 2 && y <= 8) {
                setTileAt(x, y, TileType::CaveFloor);
            } else if (x >= 4 && x <= 12 && y >= 20 && y <= 26) {
                setTileAt(x, y, TileType::BarnFloor);
            }
        }
    }

    m_props.push_back({ 20, 10, 4, false, 1 });
    m_props.push_back({ 14, 11, 7, true, 1 });
    m_props.push_back({ 11, 10, 8, true, 1 });
    m_props.push_back({ 15, 15, 9, true, 1 }); // Mayo Machine
    m_props.push_back({ 17, 15, 10, true, 1 }); // Cheese Press

    for (int x = 10; x < m_width - 3; x += 4) {
        m_props.push_back({ x, 3, 0, true, 3 });
    }
    m_props.push_back({ 32, 4, 3, true, 3 });
    m_props.push_back({ 35, 5, 3, true, 3 });

    m_chickens.push_back({ 12.0f * TILE_SIZE, 16.0f * TILE_SIZE, true });
    m_chickenHomes.push_back({ 12.0f * TILE_SIZE, 16.0f * TILE_SIZE });
    m_livestock.push_back({ "Vaca", 6.0f * TILE_SIZE, 22.0f * TILE_SIZE, true });
    m_livestockHomes.push_back({ 6.0f * TILE_SIZE, 22.0f * TILE_SIZE });

    m_npcs.push_back({ "Prefeito Lewis", 18.0f * TILE_SIZE, 12.0f * TILE_SIZE, "Que bom ver você! Como vai a fazenda?", 0, "Abóbora", "Abacate" });
    m_npcs.push_back({ "Robin (Carpinteira)", 8.0f * TILE_SIZE, 24.0f * TILE_SIZE, "Precisa de mais madeira ou construções?", 0, "Abóbora", "Nabo" });
    m_npcHomes.push_back({ 18.0f * TILE_SIZE, 12.0f * TILE_SIZE });
    m_npcHomes.push_back({ 8.0f * TILE_SIZE, 24.0f * TILE_SIZE });

    for (int i = 0; i < 60; ++i) {
        m_weatherParticles.push_back({
            static_cast<float>(std::rand() % (m_width * TILE_SIZE)),
            static_cast<float>(std::rand() % (m_height * TILE_SIZE)),
            280.0f + static_cast<float>(std::rand() % 180),
            -24.0f - static_cast<float>(std::rand() % 34)
        });
    }
}

TileType TileMap::getTileAt(int tileX, int tileY) const {
    if (tileX < 0 || tileX >= m_width || tileY < 0 || tileY >= m_height) return TileType::Grass;
    return m_tiles[tileY * m_width + tileX];
}

void TileMap::setTileAt(int tileX, int tileY, TileType type) {
    if (tileX < 0 || tileX >= m_width || tileY < 0 || tileY >= m_height) return;
    m_tiles[tileY * m_width + tileX] = type;
}

CropData TileMap::getCropAt(int tileX, int tileY) const {
    if (tileX < 0 || tileX >= m_width || tileY < 0 || tileY >= m_height) return { CropType::None, 0, false };
    return m_crops[tileY * m_width + tileX];
}

bool TileMap::hasCropAt(int tileX, int tileY) const {
    return getCropAt(tileX, tileY).type != CropType::None;
}

bool TileMap::hoeTile(int tileX, int tileY) {
    TileType t = getTileAt(tileX, tileY);
    if (t == TileType::Grass || t == TileType::TallGrass || t == TileType::GreenhouseFloor) {
        setTileAt(tileX, tileY, TileType::Dirt);
        return true;
    }
    return false;
}

bool TileMap::waterTile(int tileX, int tileY) {
    TileType t = getTileAt(tileX, tileY);
    if (t == TileType::Dirt || t == TileType::WateredDirt) {
        setTileAt(tileX, tileY, TileType::WateredDirt);
        m_crops[tileY * m_width + tileX].watered = true;
        return true;
    }
    return false;
}

bool TileMap::isCropPlantableInSeason(int tileX, int tileY, CropType cropType, Season season) const {
    const bool inGreenhouse = (tileX >= 2 && tileX <= 8 && tileY >= 2 && tileY <= 7);
    return season != Season::Winter || inGreenhouse || cropType == CropType::AncientFruit;
}

bool TileMap::plantCrop(int tileX, int tileY, CropType cropType, Season season) {
    if (!isCropPlantableInSeason(tileX, tileY, cropType, season)) return false;
    TileType t = getTileAt(tileX, tileY);
    if ((t == TileType::Dirt || t == TileType::WateredDirt) && !hasCropAt(tileX, tileY)) {
        bool wasWatered = (t == TileType::WateredDirt);
        m_crops[tileY * m_width + tileX] = { cropType, 0, wasWatered };
        return true;
    }
    return false;
}

bool TileMap::harvestCrop(int tileX, int tileY, CropType& outHarvestedType) {
    int idx = tileY * m_width + tileX;
    CropData& crop = m_crops[idx];
    int maxStage = 2;
    if (crop.type == CropType::Potato) maxStage = 3;
    else if (crop.type == CropType::Pumpkin) maxStage = 4;
    else if (crop.type == CropType::AncientFruit) maxStage = 4;

    if (crop.type != CropType::None && crop.growthStage >= maxStage) {
        outHarvestedType = crop.type;
        crop.type = CropType::None;
        crop.growthStage = 0;
        crop.watered = false;
        return true;
    }
    return false;
}

bool TileMap::chopProp(int tileX, int tileY) {
    for (auto it = m_props.begin(); it != m_props.end(); ++it) {
        if (it->solid && it->type == 0 && it->tileX == tileX && it->tileY == tileY) {
            it->health--;
            if (it->health <= 0) m_props.erase(it);
            return true;
        }
    }
    return false;
}

bool TileMap::mineRock(int tileX, int tileY, int mineDepth, int& outOreType) {
    for (auto it = m_props.begin(); it != m_props.end(); ++it) {
        if (it->solid && it->type == 3 && it->tileX == tileX && it->tileY == tileY) {
            it->health--;
            if (mineDepth >= 50 && (it->health % 5 == 0)) outOreType = 4;
            else outOreType = (it->health % 3) + 1;
            if (it->health <= 0) m_props.erase(it);
            return true;
        }
    }
    return false;
}

bool TileMap::placeFence(int tileX, int tileY) {
    if (getTileAt(tileX, tileY) == TileType::Grass && !isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 1, true, 2 });
        return true;
    }
    return false;
}

bool TileMap::placeSprinkler(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 5, true, 1 });
        return true;
    }
    return false;
}

bool TileMap::placeFurniture(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 6, false, 1 });
        return true;
    }
    return false;
}

bool TileMap::placeKeg(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 7, true, 1 });
        return true;
    }
    return false;
}

bool TileMap::placeScarecrow(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 8, true, 1 });
        return true;
    }
    return false;
}

bool TileMap::placeMayonnaiseMachine(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 9, true, 1 });
        return true;
    }
    return false;
}

bool TileMap::placeCheesePress(int tileX, int tileY) {
    if (!isTileBlocked(tileX, tileY)) {
        m_props.push_back({ tileX, tileY, 10, true, 1 });
        return true;
    }
    return false;
}

bool TileMap::collectEgg(int tileX, int tileY) {
    for (auto& chicken : m_chickens) {
        int cx = static_cast<int>(std::floor((chicken.x + 16.0f) / TILE_SIZE));
        int cy = static_cast<int>(std::floor((chicken.y + 16.0f) / TILE_SIZE));
        if (cx == tileX && cy == tileY && chicken.hasEgg) {
            chicken.hasEgg = false;
            return true;
        }
    }
    return false;
}

bool TileMap::interactLivestock(int tileX, int tileY, std::string& outProduct) {
    for (auto& animal : m_livestock) {
        int ax = static_cast<int>(std::floor((animal.x + 16.0f) / TILE_SIZE));
        int ay = static_cast<int>(std::floor((animal.y + 16.0f) / TILE_SIZE));
        if (ax == tileX && ay == tileY && animal.readyToHarvest) {
            animal.readyToHarvest = false;
            outProduct = animal.type;
            return true;
        }
    }
    return false;
}

bool TileMap::giveGiftToNPC(int tileX, int tileY, std::string giftName, std::string& outResponse) {
    for (auto& npc : m_npcs) {
        int nx = static_cast<int>(std::floor((npc.x + 16.0f) / TILE_SIZE));
        int ny = static_cast<int>(std::floor((npc.y + 16.0f) / TILE_SIZE));
        if (nx == tileX && ny == tileY) {
            if (giftName == npc.lovedGift) {
                npc.friendshipLevel += 2;
                outResponse = npc.name + ": \"Uau! Eu amo " + giftName + "! Muito obrigado!\"";
            } else if (giftName == npc.hatedGift) {
                npc.friendshipLevel -= 1;
                outResponse = npc.name + ": \"Eca... Eu detesto " + giftName + ".\"";
            } else {
                npc.friendshipLevel += 1;
                outResponse = npc.name + ": \"Obrigado pelo presente! Agradável.\"";
            }
            return true;
        }
    }
    return false;
}

void TileMap::nextDay(bool isRaining, Season season) {
    (void)season;
    for (const auto& prop : m_props) {
        if (prop.type == 5) {
            for (int dy = -1; dy <= 1; ++dy) {
                for (int dx = -1; dx <= 1; ++dx) {
                    waterTile(prop.tileX + dx, prop.tileY + dy);
                }
            }
        }
    }

    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            int idx = y * m_width + x;
            CropData& crop = m_crops[idx];
            TileType& t = m_tiles[idx];

            if (isRaining && t == TileType::Dirt) {
                t = TileType::WateredDirt;
                crop.watered = true;
            }

            if (crop.type != CropType::None) {
                int maxStage = 2;
                if (crop.type == CropType::Potato) maxStage = 3;
                else if (crop.type == CropType::Pumpkin || crop.type == CropType::AncientFruit) maxStage = 4;

                if (crop.watered && crop.growthStage < maxStage) {
                    crop.growthStage++;
                }
            }
            if (t == TileType::WateredDirt && !isRaining) t = TileType::Dirt;
            crop.watered = isRaining;
        }
    }

    for (auto& chicken : m_chickens) chicken.hasEgg = true;
    for (auto& animal : m_livestock) animal.readyToHarvest = true;
}

bool TileMap::isTileBlocked(int tileX, int tileY) const {
    if (tileX < 0 || tileX >= m_width || tileY < 0 || tileY >= m_height) return true;
    if (getTileAt(tileX, tileY) == TileType::Water) return true;
    for (const auto& prop : m_props) {
        if (prop.solid && prop.tileX == tileX && prop.tileY == tileY) return true;
    }
    return false;
}

bool TileMap::checkCollision(float worldX, float worldY, float boxW, float boxH) const {
    if (worldX < 0.0f || worldY < 0.0f ||
        (worldX + boxW) > static_cast<float>(getPixelWidth()) ||
        (worldY + boxH) > static_cast<float>(getPixelHeight())) {
        return true;
    }

    int left   = static_cast<int>(std::floor(worldX / TILE_SIZE));
    int right  = static_cast<int>(std::floor((worldX + boxW - 0.01f) / TILE_SIZE));
    int top    = static_cast<int>(std::floor(worldY / TILE_SIZE));
    int bottom = static_cast<int>(std::floor((worldY + boxH - 0.01f) / TILE_SIZE));

    for (int ty = top; ty <= bottom; ++ty) {
        for (int tx = left; tx <= right; ++tx) {
            if (isTileBlocked(tx, ty)) return true;
        }
    }
    // Personagens e animais ocupam um retângulo simples; esses estados são transitórios
    // e não participam do formato binário dos saves.
    auto overlapsActor = [&](float actorX, float actorY, float actorW, float actorH) {
        return worldX < actorX + actorW && worldX + boxW > actorX &&
               worldY < actorY + actorH && worldY + boxH > actorY;
    };
    for (const auto& chicken : m_chickens)
        if (overlapsActor(chicken.x + 5.0f, chicken.y + 9.0f, 23.0f, 18.0f)) return true;
    for (const auto& animal : m_livestock)
        if (overlapsActor(animal.x + 2.0f, animal.y + 7.0f, 30.0f, 22.0f)) return true;
    for (const auto& npc : m_npcs)
        if (overlapsActor(npc.x + 6.0f, npc.y + 3.0f, 22.0f, 26.0f)) return true;
    return false;
}

void TileMap::updateWeather(float deltaTime, int screenW, int screenH, const Camera2D& camera, int timeOfDayMinutes) {
    if (deltaTime < 0.0f) deltaTime = 0.0f;
    if (deltaTime > 0.1f) deltaTime = 0.1f;
    m_visualTime += deltaTime;
    const float hour = static_cast<float>(timeOfDayMinutes) / 100.0f;
    const bool resting = hour >= 21.0f || hour < 6.0f;
    for (size_t i = 0; i < m_chickens.size() && i < m_chickenHomes.size(); ++i) {
        const float phase = m_visualTime * 0.52f + static_cast<float>(i) * 2.1f;
        m_chickens[i].x = m_chickenHomes[i].x + (resting ? 0.0f : std::sin(phase) * 11.0f);
        m_chickens[i].y = m_chickenHomes[i].y + (resting ? 0.0f : std::cos(phase * 0.73f) * 5.0f);
    }
    for (size_t i = 0; i < m_livestock.size() && i < m_livestockHomes.size(); ++i) {
        const float phase = m_visualTime * 0.26f + static_cast<float>(i) * 1.4f;
        m_livestock[i].x = m_livestockHomes[i].x + (resting ? 0.0f : std::sin(phase) * 8.0f);
        m_livestock[i].y = m_livestockHomes[i].y + (resting ? 0.0f : std::cos(phase * 0.6f) * 4.0f);
    }
    for (size_t i = 0; i < m_npcs.size() && i < m_npcHomes.size(); ++i) {
        const float phase = m_visualTime * 0.13f + static_cast<float>(i) * 2.7f;
        m_npcs[i].x = m_npcHomes[i].x + (resting ? 0.0f : std::sin(phase) * 24.0f);
        m_npcs[i].y = m_npcHomes[i].y + (resting ? 0.0f : std::cos(phase * 0.75f) * 13.0f);
    }
    if (screenW < 1) screenW = 1;
    if (screenH < 1) screenH = 1;
    for (auto& p : m_weatherParticles) {
        p.y += p.speedY * deltaTime;
        p.x += p.speedX * deltaTime;
        if (p.y > camera.y + screenH + 12.0f) {
            p.y = camera.y - 12.0f;
            p.x = camera.x + static_cast<float>(std::rand() % screenW);
        }
    }
}

void TileMap::render(Renderer& renderer, const Camera2D& camera, Season season, bool isRaining) const {
    int startCol = std::max(0, static_cast<int>(std::floor(camera.x / TILE_SIZE)));
    int endCol   = std::min(m_width - 1, static_cast<int>(std::floor((camera.x + camera.viewportWidth) / TILE_SIZE)) + 1);
    int startRow = std::max(0, static_cast<int>(std::floor(camera.y / TILE_SIZE)));
    int endRow   = std::min(m_height - 1, static_cast<int>(std::floor((camera.y + camera.viewportHeight) / TILE_SIZE)) + 1);

    for (int y = startRow; y <= endRow; ++y) {
        for (int x = startCol; x <= endCol; ++x) {
            float wx = static_cast<float>(x * TILE_SIZE);
            float wy = static_cast<float>(y * TILE_SIZE);
            TileType tile = getTileAt(x, y);

            if (tile == TileType::Grass) {
                if (m_tilesetTexture) {
                    const int seasonIndex = std::max(0, std::min(3, static_cast<int>(season)));
                    const int variant = (x * 13 + y * 7 + (x * y) % 5) & 3;
                    const int seasonTile = 20 + seasonIndex * 4 + variant;
                    renderer.drawSprite(m_tilesetTexture, camera, seasonTile * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE, wx, wy, TILE_SIZE, TILE_SIZE);
                } else if (season == Season::Autumn) renderer.drawWorldRect(camera, wx, wy, TILE_SIZE, TILE_SIZE, 195, 130, 50);
                else if (season == Season::Winter) renderer.drawWorldRect(camera, wx, wy, TILE_SIZE, TILE_SIZE, 225, 235, 245);
                else if (season == Season::Summer) renderer.drawWorldRect(camera, wx, wy, TILE_SIZE, TILE_SIZE, 75, 165, 65);
                else renderer.drawWorldRect(camera, wx, wy, TILE_SIZE, TILE_SIZE, 94, 172, 74);
            } else if (m_tilesetTexture) {
                int srcX = static_cast<int>(tile) * TILE_SIZE;
                renderer.drawSprite(m_tilesetTexture, camera, srcX, 0, TILE_SIZE, TILE_SIZE, wx, wy, TILE_SIZE, TILE_SIZE);
            }

            // Narrow edge accents break the hard color boundary at tilled soil and shorelines.
            if (tile == TileType::Dirt || tile == TileType::WateredDirt) {
                const bool wet = tile == TileType::WateredDirt;
                const uint8_t edgeR = wet ? 114 : 190, edgeG = wet ? 91 : 139, edgeB = wet ? 70 : 83;
                if (y > 0 && getTileAt(x, y - 1) == TileType::Grass) renderer.drawWorldRect(camera, wx, wy, 32, 2, edgeR, edgeG, edgeB);
                if (y + 1 < m_height && getTileAt(x, y + 1) == TileType::Grass) renderer.drawWorldRect(camera, wx, wy + 30, 32, 2, edgeR, edgeG, edgeB);
                if (x > 0 && getTileAt(x - 1, y) == TileType::Grass) renderer.drawWorldRect(camera, wx, wy, 2, 32, edgeR, edgeG, edgeB);
                if (x + 1 < m_width && getTileAt(x + 1, y) == TileType::Grass) renderer.drawWorldRect(camera, wx + 30, wy, 2, 32, edgeR, edgeG, edgeB);
            } else if (tile == TileType::Water) {
                const uint8_t foamR = 125, foamG = 190, foamB = 207;
                if (getTileAt(x, y - 1) != TileType::Water) renderer.drawWorldRect(camera, wx + 2, wy, 28, 2, foamR, foamG, foamB, 165);
                if (getTileAt(x, y + 1) != TileType::Water) renderer.drawWorldRect(camera, wx + 2, wy + 30, 28, 2, 44, 96, 137, 170);
                if (getTileAt(x - 1, y) != TileType::Water) renderer.drawWorldRect(camera, wx, wy + 2, 2, 28, 74, 143, 179, 150);
                if (getTileAt(x + 1, y) != TileType::Water) renderer.drawWorldRect(camera, wx + 30, wy + 2, 2, 28, foamR, foamG, foamB, 120);
            }

            CropData crop = getCropAt(x, y);
            if (tile == TileType::WateredDirt) {
                renderer.drawWorldRect(camera, wx + 2, wy + 2, 3, 3, 115, 199, 225, 175);
                renderer.drawWorldRect(camera, wx + 3, wy + 5, 2, 2, 84, 164, 206, 150);
            }
            if (crop.type != CropType::None) {
                int maxStage = 2;
                if (crop.type == CropType::Potato) maxStage = 3;
                else if (crop.type == CropType::Pumpkin || crop.type == CropType::AncientFruit) maxStage = 4;

                const int stage = std::max(0, std::min(maxStage, crop.growthStage));
                const float stemH = 7.0f + stage * 3.5f;
                const float stemX = wx + 15.0f;
                const float stemY = wy + 27.0f - stemH;
                renderer.drawWorldRect(camera, wx + 8.0f, wy + 26.0f, 16.0f, 3.0f, 31, 44, 26, 85);
                renderer.drawWorldRect(camera, stemX, stemY, 3.0f, stemH, 46, 112, 49);
                const uint8_t leafG = static_cast<uint8_t>(128 + stage * 10);
                if (crop.type == CropType::Turnip) {
                    renderer.drawWorldRect(camera, stemX - 8, stemY + 4, 9, 4, 51, leafG, 56);
                    renderer.drawWorldRect(camera, stemX + 2, stemY + 1, 9, 4, 65, leafG, 52);
                    if (stage >= 1) renderer.drawWorldRect(camera, stemX - 4, stemY - 4, 6, 5, 71, 160, 68);
                } else if (crop.type == CropType::Potato) {
                    renderer.drawWorldRect(camera, stemX - 9, stemY + 2, 8, 5, 61, leafG, 55);
                    renderer.drawWorldRect(camera, stemX + 3, stemY + 2, 8, 5, 61, leafG, 55);
                    if (stage >= 1) {
                        renderer.drawWorldRect(camera, stemX - 6, stemY - 3, 6, 5, 79, 171, 69);
                        renderer.drawWorldRect(camera, stemX + 3, stemY - 5, 6, 5, 75, 163, 63);
                    }
                    if (stage >= 2) renderer.drawWorldRect(camera, stemX - 2, stemY - 9, 6, 5, 236, 226, 189);
                } else if (crop.type == CropType::Pumpkin) {
                    renderer.drawWorldRect(camera, wx + 5, wy + 17, 9, 3, 56, 133, 55);
                    renderer.drawWorldRect(camera, wx + 18, wy + 20, 9, 3, 56, 133, 55);
                    renderer.drawWorldRect(camera, wx + 6, wy + 12, 7, 5, 75, 162, 65);
                    renderer.drawWorldRect(camera, wx + 19, wy + 14, 7, 5, 75, 162, 65);
                    if (stage >= 2) renderer.drawWorldRect(camera, stemX - 2, stemY - 6, 7, 5, 84, 171, 65);
                } else {
                    renderer.drawWorldRect(camera, stemX - 8, stemY + 3, 8, 5, 50, 139, 104);
                    renderer.drawWorldRect(camera, stemX + 3, stemY + 1, 8, 5, 50, 139, 104);
                    if (stage >= 1) {
                        renderer.drawWorldRect(camera, stemX - 4, stemY - 4, 7, 5, 76, 192, 147);
                        renderer.drawWorldRect(camera, stemX + 3, stemY - 6, 7, 5, 76, 192, 147);
                    }
                }
                if (stage >= maxStage) {
                    const float pulse = (std::sin(m_visualTime * 5.0f + x * 0.7f + y * 0.4f) > 0.2f) ? 1.0f : 0.0f;
                    const uint8_t glow = static_cast<uint8_t>(190 + pulse * 55.0f);
                    renderer.drawWorldRect(camera, wx + 14, wy + 3, 4, 2, glow, 219, 107, 220);
                    renderer.drawWorldRect(camera, wx + 15, wy + 1, 2, 6, glow, 219, 107, 190);
                    if (crop.type == CropType::Turnip) {
                        renderer.drawWorldRect(camera, wx + 12, wy + 20, 9, 8, 228, 223, 198);
                        renderer.drawWorldRect(camera, wx + 12, wy + 20, 4, 3, 170, 113, 110);
                        renderer.drawWorldRect(camera, wx + 14, wy + 18, 5, 3, 69, 144, 58);
                    } else if (crop.type == CropType::Potato) {
                        renderer.drawWorldRect(camera, wx + 10, wy + 23, 6, 5, 192, 151, 87);
                        renderer.drawWorldRect(camera, wx + 18, wy + 24, 6, 4, 205, 165, 96);
                        renderer.drawWorldRect(camera, wx + 12, wy + 24, 2, 1, 118, 82, 48);
                    } else if (crop.type == CropType::Pumpkin) {
                        renderer.drawWorldRect(camera, wx + 10, wy + 17, 14, 12, 221, 103, 27);
                        renderer.drawWorldRect(camera, wx + 12, wy + 18, 3, 10, 242, 148, 41);
                        renderer.drawWorldRect(camera, wx + 19, wy + 18, 3, 10, 184, 76, 27);
                        renderer.drawWorldRect(camera, wx + 15, wy + 15, 4, 4, 76, 137, 49);
                        renderer.drawWorldRectOutline(camera, wx + 10, wy + 17, 14, 12, 131, 66, 33);
                    } else {
                        renderer.drawWorldRect(camera, wx + 11, wy + 18, 12, 10, 88, 189, 169);
                        renderer.drawWorldRect(camera, wx + 13, wy + 15, 8, 5, 144, 226, 191);
                        renderer.drawWorldRect(camera, wx + 14, wy + 21, 6, 5, 208, 244, 205);
                        renderer.drawWorldRectOutline(camera, wx + 11, wy + 18, 12, 10, 50, 113, 99);
                    }
                }
            }
        }
    }

    for (const auto& prop : m_props) {
        float wx = static_cast<float>(prop.tileX * TILE_SIZE);
        float wy = static_cast<float>(prop.tileY * TILE_SIZE);
        renderer.drawWorldRect(camera, wx + 5, wy + 27, 22, 3, 28, 36, 25, 85);
        if (m_tilesetTexture) {
            int srcIdx = 8 + prop.type;
            renderer.drawSprite(m_tilesetTexture, camera, srcIdx * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE, wx, wy, TILE_SIZE, TILE_SIZE);
        }
    }

    for (const auto& chicken : m_chickens) {
        const float bob = std::sin(m_visualTime * 5.0f + chicken.x * 0.07f) > 0.82f ? -1.0f : 0.0f;
        renderer.drawWorldRect(camera, chicken.x + 5, chicken.y + 25, 23, 4, 30, 45, 32, 100);
        renderer.drawSprite(m_actorTexture, camera, 0, 0, 32, 32, chicken.x, chicken.y + bob, 32, 32);
        if (chicken.hasEgg) renderer.drawWorldRect(camera, chicken.x + 1, chicken.y + 25, 5, 4, 250, 245, 224);
    }
    for (const auto& animal : m_livestock) {
        const float bob = std::sin(m_visualTime * 3.2f + animal.x * 0.035f) > 0.9f ? -1.0f : 0.0f;
        const bool sheep = animal.type.find("Ovelha") != std::string::npos || animal.type.find("Sheep") != std::string::npos;
        renderer.drawWorldRect(camera, animal.x + 2, animal.y + 26, 28, 4, 30, 42, 31, 105);
        renderer.drawSprite(m_actorTexture, camera, (sheep ? 2 : 1) * 32, 0, 32, 32, animal.x, animal.y + bob, 32, 32);
        if (animal.readyToHarvest) renderer.drawWorldRect(camera, animal.x + 4, animal.y + 2, 5, 5, 222, 191, 108);
    }
    for (const auto& npc : m_npcs) {
        const float bob = std::sin(m_visualTime * 2.4f + npc.x * 0.04f + npc.y * 0.03f) > 0.93f ? -1.0f : 0.0f;
        const bool robin = npc.name.find("Robin") != std::string::npos;
        renderer.drawWorldRect(camera, npc.x + 5, npc.y + 27, 22, 3, 30, 42, 31, 110);
        renderer.drawSprite(m_actorTexture, camera, (robin ? 4 : 3) * 32, 0, 32, 32, npc.x, npc.y + bob, 32, 32);
    }

    if (isRaining) {
        for (const auto& p : m_weatherParticles) {
            const int sway = static_cast<int>(std::sin(m_visualTime * 2.0f + p.x * 0.01f) * 2.0f);
            renderer.drawWorldRect(camera, p.x + sway, p.y, 1, 8, 150, 180, 220, 155);
        }
    }
}
