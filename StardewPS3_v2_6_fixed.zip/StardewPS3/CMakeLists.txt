cmake_minimum_required(VERSION 3.10)
project(StardewPS3 VERSION 2.6.0 LANGUAGES CXX)

# Build para PC (teste/desenvolvimento). Para PS3 use o Makefile.ps3.
set(CMAKE_CXX_STANDARD 11)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    add_compile_options(-Wall -Wextra -Wpedantic)
endif()

include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)

find_package(SDL2 REQUIRED)
include_directories(${SDL2_INCLUDE_DIRS})
# Os fontes usam #include <SDL.h>; o pacote SDL2 do sistema costuma instalar em include/SDL2.
include_directories(${SDL2_INCLUDE_DIRS}/SDL2)

find_package(SDL2_mixer QUIET)
if(SDL2_mixer_FOUND)
    include_directories(${SDL2_mixer_INCLUDE_DIRS})
    add_definitions(-DHAVE_SDL_MIXER)
endif()

set(SOURCES
    src/main.cpp
    src/Game.cpp
    src/Player.cpp
    src/TileMap.cpp
    src/Renderer.cpp
    src/Paths.cpp
    src/PadInput.cpp
    src/SaveSlots.cpp
)

add_executable(${PROJECT_NAME} ${SOURCES})

if(TARGET SDL2::SDL2)
    target_link_libraries(${PROJECT_NAME} PRIVATE SDL2::SDL2)
else()
    target_link_libraries(${PROJECT_NAME} PRIVATE ${SDL2_LIBRARIES})
endif()

if(SDL2_mixer_FOUND)
    if(TARGET SDL2_mixer::SDL2_mixer)
        target_link_libraries(${PROJECT_NAME} PRIVATE SDL2_mixer::SDL2_mixer)
    else()
        target_link_libraries(${PROJECT_NAME} PRIVATE ${SDL2_MIXER_LIBRARIES})
    endif()
endif()

add_custom_command(TARGET ${PROJECT_NAME} POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_directory
    ${CMAKE_CURRENT_SOURCE_DIR}/assets $<TARGET_FILE_DIR:${PROJECT_NAME}>/assets
)
