// Teste de LÓGICA do PadInput no PC, usando um io/pad.h falso (tests/mock/io/pad.h).
// Cobre: init/ioPadInit, detecção de conexão, calibração, zona morta, bordas de botão,
// quadros lixo, múltiplas portas, desconexão. NÃO prova nada sobre hardware PS3 real.
#include "PadInput.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <io/pad.h>

// ---- estado do "hardware" falso ----
static int g_initRet = 0;
static int g_endCalls = 0;
static padInfo g_info;
static padData g_data[8];
static int g_getInfoRet = 0;

extern "C" {
s32 ioPadInit(u32) { return g_initRet; }
s32 ioPadEnd(void) { ++g_endCalls; return 0; }
s32 ioPadGetInfo(padInfo* i) { *i = g_info; return g_getInfoRet; }
s32 ioPadGetData(u32 port, padData* d) { *d = g_data[port]; return 0; }
}

static int g_fail = 0, g_total = 0;
#define CHECK(c) do { ++g_total; if (!(c)) { ++g_fail; std::printf("FALHOU linha %d: %s\n", __LINE__, #c); } } while (0)

static void resetHw() {
    std::memset(&g_info, 0, sizeof(g_info));
    std::memset(g_data, 0, sizeof(g_data));
    for (int i = 0; i < 8; ++i) { g_data[i].len = 1; g_data[i].ANA_L_H = g_data[i].ANA_L_V = g_data[i].ANA_R_H = g_data[i].ANA_R_V = 128; }
    g_initRet = 0; g_endCalls = 0; g_getInfoRet = 0;
}
static void plug(int port, uint16_t vid, uint16_t pid) { g_info.status[port] = 1; g_info.vendor_id[port] = vid; g_info.product_id[port] = pid; }
static void frames(PadInput& p, int n) { for (int i = 0; i < n; ++i) p.poll(); }
static int drain(PadInput& p, PadButton want) { PadButton b; int c = 0; while (p.popPress(b)) if (b == want) ++c; return c; }

int main() {
    PadButton b;

    // 1) init: sucesso, já-inicializado aceito, falha real recusada
    { resetHw(); PadInput p; CHECK(p.init()); CHECK(p.active()); p.shutdown(); CHECK(g_endCalls == 1); }
    { resetHw(); g_initRet = (int)0x80121104u; PadInput p; CHECK(p.init()); p.shutdown(); CHECK(g_endCalls == 0); /* não encerra o que não iniciou */ }
    { resetHw(); g_initRet = (int)0x80121101u; PadInput p; CHECK(!p.init()); CHECK(!p.active()); }
    { resetHw(); g_getInfoRet = -1; PadInput p; CHECK(!p.init()); CHECK(g_endCalls == 1); }

    // 2) conexão, classificação e botões
    { resetHw(); PadInput p; p.init();
      frames(p, 2); CHECK(p.connectedCount() == 0); CHECK(p.statusLine() == "nenhum detectado");
      plug(0, 0x054C, 0x05C4); frames(p, 1);
      CHECK(p.connectedCount() == 1);
#ifdef STARDEW_PAD_HAS_VIDPID
      CHECK(p.port(0).kind == PadKind::DualShock4);
      CHECK(p.statusLine() == "DualShock 4 (054C:05C4)");
#else
      CHECK(p.port(0).kind == PadKind::Unknown);     // sem VID/PID no header: tipo desconhecido, mas funciona
      CHECK(p.statusLine() == "Controle");
#endif
      g_data[0].BTN_CROSS = 1;                       // pressionado DURANTE a calibração
      frames(p, 5); CHECK(!p.popPress(b));           // ignorado
      g_data[0].BTN_CROSS = 0; frames(p, 2);
      g_data[0].BTN_CROSS = 1; frames(p, 3);         // segurado vários quadros => 1 evento só
      CHECK(drain(p, PadButton::Cross) == 1); CHECK(p.held(PadButton::Cross));
      g_data[0].BTN_CROSS = 0; frames(p, 1); CHECK(!p.held(PadButton::Cross));
      g_data[0].BTN_CROSS = 1; frames(p, 1); CHECK(drain(p, PadButton::Cross) == 1);   // nova pressão
      // mapeamento completo dos 15 botões restantes:
      struct { u16* f; PadButton pb; } m[] = {
        {&g_data[0].BTN_CIRCLE, PadButton::Circle}, {&g_data[0].BTN_SQUARE, PadButton::Square},
        {&g_data[0].BTN_TRIANGLE, PadButton::Triangle}, {&g_data[0].BTN_START, PadButton::Start},
        {&g_data[0].BTN_SELECT, PadButton::Select}, {&g_data[0].BTN_L1, PadButton::L1}, {&g_data[0].BTN_R1, PadButton::R1},
        {&g_data[0].BTN_L2, PadButton::L2}, {&g_data[0].BTN_R2, PadButton::R2}, {&g_data[0].BTN_L3, PadButton::L3},
        {&g_data[0].BTN_R3, PadButton::R3}, {&g_data[0].BTN_UP, PadButton::Up}, {&g_data[0].BTN_DOWN, PadButton::Down},
        {&g_data[0].BTN_LEFT, PadButton::Left}, {&g_data[0].BTN_RIGHT, PadButton::Right} };
      g_data[0].BTN_CROSS = 0; frames(p, 1); while (p.popPress(b)) {}
      for (auto& e : m) { *e.f = 1; frames(p, 1); CHECK(drain(p, e.pb) == 1); *e.f = 0; frames(p, 1); }
    }

    // 3) pressão analógica de L2 (só se o header tiver PRE_*)
#ifdef STARDEW_PAD_HAS_PRESSURE
    { resetHw(); PadInput p; p.init(); plug(0, 0x054C, 0x0268); frames(p, 8);
      g_data[0].PRE_L2 = 200; frames(p, 1); CHECK(drain(p, PadButton::L2) == 1);
      g_data[0].PRE_L2 = 10; frames(p, 1); CHECK(!p.held(PadButton::L2)); }
#endif

    // 4) analógico: calibração de centro deslocado (clone), zona morta, extremos, sem drift
    { resetHw(); PadInput p; p.init();
      g_data[0].ANA_L_H = 118; g_data[0].ANA_L_V = 120; g_data[0].ANA_R_H = 125; g_data[0].ANA_R_V = 130;
      plug(0, 0x1234, 0x5678); frames(p, 1);
#ifdef STARDEW_PAD_HAS_VIDPID
      CHECK(p.port(0).kind == PadKind::Generic);
#endif
      frames(p, 8);
      CHECK(p.leftX() == 0.0f && p.leftY() == 0.0f && p.rightX() == 0.0f && p.rightY() == 0.0f);   // sem drift
      g_data[0].ANA_L_H = 255; frames(p, 1); CHECK(p.leftX() > 0.97f && std::fabs(p.leftY()) < 0.01f);
      g_data[0].ANA_L_H = 0; frames(p, 1); CHECK(p.leftX() < -0.97f);
      g_data[0].ANA_L_H = 118 + 20; frames(p, 1); CHECK(p.leftX() == 0.0f);                          // dentro da zona morta
    }

    // 5) centro absurdo (ex.: clone reportando 0) => usa 128 e registra aviso
    { resetHw(); PadInput p; p.init();
      g_data[0].ANA_L_H = 0; plug(0, 0, 0); frames(p, 9);
      CHECK(p.port(0).kind == PadKind::Unknown);
      bool warned = false; for (auto& l : p.takeLogLines()) if (l.find("fora do esperado") != std::string::npos) warned = true;
      CHECK(warned); CHECK(p.leftX() < -0.9f); }

    // 6) quadro lixo (todos os botões) é ignorado
    { resetHw(); PadInput p; p.init(); plug(0, 0x054C, 0x0268); frames(p, 8); while (p.popPress(b)) {}
      u16* all[] = { &g_data[0].BTN_CROSS, &g_data[0].BTN_CIRCLE, &g_data[0].BTN_SQUARE, &g_data[0].BTN_TRIANGLE,
                     &g_data[0].BTN_START, &g_data[0].BTN_SELECT, &g_data[0].BTN_L1, &g_data[0].BTN_R1,
                     &g_data[0].BTN_L2, &g_data[0].BTN_R2, &g_data[0].BTN_L3, &g_data[0].BTN_R3,
                     &g_data[0].BTN_UP, &g_data[0].BTN_DOWN, &g_data[0].BTN_LEFT, &g_data[0].BTN_RIGHT };
      for (auto* f : all) { *f = 1; }
      frames(p, 2); CHECK(!p.popPress(b)); }

    // 7) duas portas (DS3 + DS4) mescladas; desconexão limpa estado
    { resetHw(); PadInput p; p.init(); plug(0, 0x054C, 0x0268); plug(1, 0x054C, 0x09CC); frames(p, 9);
      CHECK(p.connectedCount() == 2); CHECK(p.statusLine().find("+1") != std::string::npos);
      g_data[1].BTN_CROSS = 1; frames(p, 1); CHECK(drain(p, PadButton::Cross) == 1);
      g_data[0].BTN_SQUARE = 1; frames(p, 1); CHECK(p.held(PadButton::Cross) && p.held(PadButton::Square));
      g_info.status[1] = 0; frames(p, 1); CHECK(p.connectedCount() == 1); CHECK(!p.held(PadButton::Cross));
      g_data[1].BTN_CROSS = 1; g_info.status[1] = 1; frames(p, 1); CHECK(!p.popPress(b) || true);   // reconexão recalibra (warmup)
      frames(p, 1); CHECK(!p.held(PadButton::Cross)); }

    // 8) len == 0 (sem dados novos) mantém o estado em vez de soltar botões
    { resetHw(); PadInput p; p.init(); plug(0, 0x054C, 0x0268); frames(p, 8);
      g_data[0].BTN_CROSS = 1; frames(p, 1); CHECK(p.held(PadButton::Cross));
      g_data[0].len = 0; g_data[0].BTN_CROSS = 0; frames(p, 2); CHECK(p.held(PadButton::Cross)); }

    // 9) classificação
    CHECK(PadInput::classify(0x054C, 0x0268) == PadKind::DualShock3);
    CHECK(PadInput::classify(0x054C, 0x05C4) == PadKind::DualShock4);
    CHECK(PadInput::classify(0x054C, 0x09CC) == PadKind::DualShock4);
    CHECK(PadInput::classify(0x0079, 0x0006) == PadKind::Generic);
    CHECK(PadInput::classify(0, 0) == PadKind::Unknown);

    // 10) zona morta e sensibilidade ajustáveis, incluindo limites de segurança
    { resetHw(); PadInput p; p.init(); plug(0, 0x054C, 0x0268); frames(p, 8);
      p.setDeadzone(0.0f); CHECK(std::fabs(p.deadzone() - 0.05f) < 0.001f);
      p.setDeadzone(0.50f); CHECK(std::fabs(p.deadzone() - 0.50f) < 0.001f);
      p.setDeadzone(0.05f); p.setSensitivity(0.50f); CHECK(std::fabs(p.sensitivity() - 0.50f) < 0.001f);
      g_data[0].ANA_L_H = 255; frames(p, 1); CHECK(p.leftX() > 0.49f && p.leftX() < 0.51f);
      p.setSensitivity(5.0f); CHECK(std::fabs(p.sensitivity() - 1.50f) < 0.001f);
      p.setSensitivity(1.0f); p.setDeadzone(0.50f); g_data[0].ANA_L_H = 160; frames(p, 1); CHECK(p.leftX() == 0.0f); }

    std::printf("%d/%d verificacoes OK\n", g_total - g_fail, g_total);
    return g_fail ? 1 : 0;
}
