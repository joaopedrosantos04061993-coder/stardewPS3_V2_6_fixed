#include "SaveSlots.h"
#include <cstdio>
#include <fstream>
#include <string>

static int checks = 0, failures = 0;
static void check(bool ok, const char* label) {
    ++checks;
    if (!ok) { ++failures; std::printf("FAIL: %s\n", label); }
}
static bool writeBytes(const std::string& path, const char* bytes, std::streamsize size) {
    std::ofstream f(path.c_str(), std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(bytes, size);
    return f.good();
}

int main() {
    const char* expected[] = { "save_v1.6.dat", "save_slot2.dat", "save_slot3.dat" };
    const char* expectedBackup[] = { "save_v1.6.bak", "save_slot2.bak", "save_slot3.bak" };
    for (int slot = 1; slot <= SaveSlots::COUNT; ++slot) {
        check(SaveSlots::valid(slot) && SaveSlots::fileName(slot) == expected[slot - 1] &&
              SaveSlots::backupFileName(slot) == expectedBackup[slot - 1], "slot mapping");
    }
    check(!SaveSlots::valid(0) && !SaveSlots::valid(4) && SaveSlots::fileName(0).empty() &&
          SaveSlots::backupFileName(4).empty(), "reject invalid slots");

    const char magic[8] = { 'S','D','V','P','S','3','1','6' };
    const int version = 2, otherVersion = 99;
    const std::string base = "/tmp/stardew_slot_test";
    const std::string source = base + ".src", dest = base + ".dst";
    char record[16] = {};
    for (int i = 0; i < 8; ++i) record[i] = magic[i];
    for (int i = 0; i < 4; ++i) record[8 + i] = reinterpret_cast<const char*>(&version)[i];
    record[12] = 'D'; record[13] = 'A'; record[14] = 'T'; record[15] = 'A';

    check(writeBytes(source, record, sizeof(record)) &&
          SaveSlots::inspect(source, magic, version) == SaveSlots::FileStatus::ValidHeader, "recognize header/version");
    check(writeBytes(source, record, 7) &&
          SaveSlots::inspect(source, magic, version) == SaveSlots::FileStatus::InvalidHeader, "reject truncated header");
    for (int i = 0; i < 4; ++i) record[8 + i] = reinterpret_cast<const char*>(&otherVersion)[i];
    check(writeBytes(source, record, sizeof(record)) &&
          SaveSlots::inspect(source, magic, version) == SaveSlots::FileStatus::UnsupportedVersion, "reject unsupported version");
    check(SaveSlots::inspect(base + ".missing", magic, version) == SaveSlots::FileStatus::Missing, "report missing file");
    for (int i = 0; i < 4; ++i) record[8 + i] = reinterpret_cast<const char*>(&version)[i];
    check(writeBytes(source, record, sizeof(record)) && SaveSlots::copyFile(source, dest) &&
          SaveSlots::inspect(dest, magic, version) == SaveSlots::FileStatus::ValidHeader, "copy and verify backup");

    std::remove(source.c_str()); std::remove(dest.c_str());
    std::printf("%d/%d verificacoes SaveSlots OK\n", checks - failures, checks);
    return failures ? 1 : 0;
}
