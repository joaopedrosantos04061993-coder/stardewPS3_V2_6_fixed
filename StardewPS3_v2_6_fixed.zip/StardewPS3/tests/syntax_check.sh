#!/bin/sh
# Checagem de sintaxe de TODOS os .cpp com mocks de SDL2/PSL1GHT (não substitui o build real).
cd "$(dirname "$0")/.." || exit 1
rc=0
for f in src/*.cpp; do
  g++ -std=gnu++11 -Wall -Wextra -fsyntax-only -DSTARDEW_PS3 -DHAVE_SDL_MIXER \
      -DSTARDEW_PAD_HAS_VIDPID -DSTARDEW_PAD_HAS_PRESSURE -Iinclude -Itests/mock "$f" || rc=1
done
[ $rc -eq 0 ] && echo "Sintaxe OK em todos os .cpp"
exit $rc
