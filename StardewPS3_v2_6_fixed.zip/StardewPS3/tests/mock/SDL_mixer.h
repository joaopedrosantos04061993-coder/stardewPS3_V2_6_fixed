#pragma once
#include "SDL.h"
struct Mix_Chunk; struct Mix_Music;
#define MIX_DEFAULT_FORMAT 0x8010
int Mix_OpenAudio(int,Uint16,int,int); void Mix_CloseAudio(); int Mix_AllocateChannels(int); const char* Mix_GetError();
Mix_Chunk* Mix_LoadWAV(const char*); void Mix_FreeChunk(Mix_Chunk*); int Mix_PlayChannel(int, Mix_Chunk*, int);
Mix_Music* Mix_LoadMUS(const char*); void Mix_FreeMusic(Mix_Music*); int Mix_PlayMusic(Mix_Music*, int); int Mix_VolumeMusic(int);
