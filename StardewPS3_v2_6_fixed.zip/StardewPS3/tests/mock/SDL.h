#pragma once
#include <stdint.h>
typedef uint8_t Uint8; typedef uint16_t Uint16; typedef uint32_t Uint32; typedef uint64_t Uint64; typedef int16_t Sint16; typedef int32_t Sint32;
struct SDL_Window; struct SDL_Renderer; struct SDL_Texture; struct SDL_PixelFormat; struct SDL_Surface { int w,h; void* pixels; int pitch; SDL_PixelFormat* format; }; struct SDL_GameController; struct SDL_Joystick;
struct SDL_Rect { int x,y,w,h; };
typedef int32_t SDL_JoystickID;
enum { SDL_INIT_VIDEO=1, SDL_INIT_AUDIO=2, SDL_INIT_JOYSTICK=4, SDL_INIT_GAMECONTROLLER=8 };
enum { SDL_WINDOW_SHOWN=4, SDL_WINDOW_FULLSCREEN=1 };
enum { SDL_RENDERER_ACCELERATED=2, SDL_RENDERER_PRESENTVSYNC=4 };
enum SDL_BlendMode { SDL_BLENDMODE_NONE, SDL_BLENDMODE_BLEND };
enum { SDL_WINDOWPOS_CENTERED=0x2FFF0000 };
enum { SDL_PIXELFORMAT_RGBA8888=1 };
enum { SDL_TEXTUREACCESS_STATIC=0 };
enum { SDL_TRUE=1, SDL_FALSE=0 };
enum SDL_Scancode { SDL_SCANCODE_UP=82, SDL_SCANCODE_DOWN=81, SDL_SCANCODE_LEFT=80, SDL_SCANCODE_RIGHT=79, SDL_NUM_SCANCODES=512 };
enum { SDL_QUIT=0x100, SDL_KEYDOWN=0x300, SDL_JOYBUTTONDOWN=0x603, SDL_CONTROLLERBUTTONDOWN=0x650, SDL_CONTROLLERDEVICEADDED=0x653, SDL_CONTROLLERDEVICEREMOVED=0x654 };
enum SDL_GameControllerButton { SDL_CONTROLLER_BUTTON_A, SDL_CONTROLLER_BUTTON_B, SDL_CONTROLLER_BUTTON_X, SDL_CONTROLLER_BUTTON_Y, SDL_CONTROLLER_BUTTON_BACK, SDL_CONTROLLER_BUTTON_GUIDE, SDL_CONTROLLER_BUTTON_START, SDL_CONTROLLER_BUTTON_LEFTSTICK, SDL_CONTROLLER_BUTTON_RIGHTSTICK, SDL_CONTROLLER_BUTTON_LEFTSHOULDER, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, SDL_CONTROLLER_BUTTON_DPAD_UP, SDL_CONTROLLER_BUTTON_DPAD_DOWN, SDL_CONTROLLER_BUTTON_DPAD_LEFT, SDL_CONTROLLER_BUTTON_DPAD_RIGHT };
enum SDL_GameControllerAxis { SDL_CONTROLLER_AXIS_LEFTX, SDL_CONTROLLER_AXIS_LEFTY };
enum { SDLK_ESCAPE=27, SDLK_UP=1, SDLK_DOWN=2, SDLK_LEFT=3, SDLK_RIGHT=4, SDLK_RETURN=13, SDLK_SPACE=32 };
struct SDL_Keysym { int scancode; Sint32 sym; Uint16 mod; };
struct SDL_KeyboardEvent { Uint32 type; Uint8 repeat; SDL_Keysym keysym; };
struct SDL_JoyButtonEvent { Uint32 type; SDL_JoystickID which; Uint8 button; Uint8 state; };
struct SDL_ControllerButtonEvent { Uint32 type; SDL_JoystickID which; Uint8 button; Uint8 state; };
struct SDL_ControllerDeviceEvent { Uint32 type; Sint32 which; };
union SDL_Event { Uint32 type; SDL_KeyboardEvent key; SDL_JoyButtonEvent jbutton; SDL_ControllerButtonEvent cbutton; SDL_ControllerDeviceEvent cdevice; };
extern "C++" {
int SDL_Init(Uint32); int SDL_InitSubSystem(Uint32); void SDL_Quit(); void SDL_Delay(Uint32);
Uint64 SDL_GetPerformanceCounter(); Uint64 SDL_GetPerformanceFrequency();
SDL_Window* SDL_CreateWindow(const char*, int,int,int,int, Uint32); void SDL_DestroyWindow(SDL_Window*); void SDL_GetWindowSize(SDL_Window*, int*, int*);
SDL_Renderer* SDL_CreateRenderer(SDL_Window*, int, Uint32); void SDL_DestroyRenderer(SDL_Renderer*);
int SDL_RenderSetLogicalSize(SDL_Renderer*, int,int); int SDL_SetRenderDrawBlendMode(SDL_Renderer*, SDL_BlendMode); int SDL_SetRenderDrawColor(SDL_Renderer*, Uint8,Uint8,Uint8,Uint8);
int SDL_RenderClear(SDL_Renderer*); void SDL_RenderPresent(SDL_Renderer*); int SDL_RenderFillRect(SDL_Renderer*, const SDL_Rect*); int SDL_RenderDrawRect(SDL_Renderer*, const SDL_Rect*);
int SDL_RenderCopy(SDL_Renderer*, SDL_Texture*, const SDL_Rect*, const SDL_Rect*);
SDL_Surface* SDL_LoadBMP(const char*); void SDL_FreeSurface(SDL_Surface*); int SDL_SetColorKey(SDL_Surface*, int, Uint32); Uint32 SDL_MapRGB(const void*, Uint8,Uint8,Uint8);
SDL_Texture* SDL_CreateTextureFromSurface(SDL_Renderer*, SDL_Surface*); SDL_Texture* SDL_CreateTexture(SDL_Renderer*, Uint32, int, int, int);
int SDL_UpdateTexture(SDL_Texture*, const SDL_Rect*, const void*, int); int SDL_SetTextureBlendMode(SDL_Texture*, SDL_BlendMode); int SDL_SetTextureColorMod(SDL_Texture*, Uint8,Uint8,Uint8); int SDL_SetTextureAlphaMod(SDL_Texture*, Uint8); void SDL_DestroyTexture(SDL_Texture*);
int SDL_PollEvent(SDL_Event*); const Uint8* SDL_GetKeyboardState(int*);
int SDL_NumJoysticks(); int SDL_IsGameController(int); SDL_GameController* SDL_GameControllerOpen(int); void SDL_GameControllerClose(SDL_GameController*); Sint16 SDL_GameControllerGetAxis(SDL_GameController*, SDL_GameControllerAxis); SDL_GameController* SDL_GameControllerFromInstanceID(SDL_JoystickID);
SDL_Joystick* SDL_JoystickOpen(int); void SDL_JoystickClose(SDL_Joystick*); Sint16 SDL_JoystickGetAxis(SDL_Joystick*, int);
}

enum { SDLK_0=100, SDLK_1=101, SDLK_2=102, SDLK_3=103, SDLK_4=104, SDLK_5=105, SDLK_6=106, SDLK_7=107, SDLK_8=108, SDLK_9=109, SDLK_F5=110, SDLK_TAB=111, SDLK_a=112, SDLK_b=113, SDLK_c=114, SDLK_e=115, SDLK_i=116, SDLK_j=117, SDLK_k=118, SDLK_m=119, SDLK_p=120, SDLK_s=121, SDLK_t=122, SDLK_v=123 };
