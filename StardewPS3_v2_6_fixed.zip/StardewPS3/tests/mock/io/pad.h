// MOCK do <io/pad.h> do PSL1GHT, apenas para compilar/testar a LÓGICA do PadInput no PC.
// Reflete as suposições do código (nomes de campos BTN_*/ANA_*/PRE_*, status[]); NÃO substitui
// a verificação contra o io/pad.h real do seu toolchain.
#ifndef MOCK_IO_PAD_H
#define MOCK_IO_PAD_H
#include <stdint.h>
typedef int32_t s32;
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;
#define MAX_PADS 127
typedef struct _padInfo {
    u32 max;
    u16 vendor_id[MAX_PADS];
    u16 product_id[MAX_PADS];
    u8 status[MAX_PADS];
} padInfo;
typedef struct _padData {
    s32 len;
    u16 BTN_LEFT, BTN_DOWN, BTN_RIGHT, BTN_UP, BTN_START, BTN_R3, BTN_L3, BTN_SELECT;
    u16 BTN_SQUARE, BTN_CROSS, BTN_CIRCLE, BTN_TRIANGLE, BTN_R1, BTN_L1, BTN_R2, BTN_L2;
    u16 ANA_L_H, ANA_L_V, ANA_R_H, ANA_R_V;
    u16 PRE_L2, PRE_R2;
} padData;
#ifdef __cplusplus
extern "C" {
#endif
s32 ioPadInit(u32 max);
s32 ioPadEnd(void);
s32 ioPadGetInfo(padInfo* info);
s32 ioPadGetData(u32 port, padData* data);
#ifdef __cplusplus
}
#endif
#endif
