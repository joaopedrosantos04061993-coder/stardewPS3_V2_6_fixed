#pragma once
#define SYSMODULE_FS 1
#define SYSMODULE_IO 2
#define SYSMODULE_AUDIO 3
int sysModuleLoad(int);
