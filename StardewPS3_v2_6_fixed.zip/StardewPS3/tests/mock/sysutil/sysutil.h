#pragma once
#include <stdint.h>
typedef uint64_t u64;
#define SYSUTIL_EXIT_GAME 0x0101
#define SYSUTIL_EVENT_SLOT0 0
typedef void (*sysutilCallback)(u64 status, u64 param, void* usrdata);
int sysUtilRegisterCallback(int slot, sysutilCallback cb, void* usrdata); int sysUtilCheckCallback();
