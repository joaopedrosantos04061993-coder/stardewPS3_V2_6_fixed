# Relatório da atualização v1.8 — controles DualShock

## O que foi encontrado na v1.7
- Leitura de controle: SDL2 (`SDL_GameController`, com fallback `SDL_Joystick` e tabela `JOY_BUTTON_MAP`), tudo em `Game::init/processEvents`. A API nativa do PS3 (libio) estava só linkada (`-lio`), não usada.
- Causa do DS4 não funcionar dentro do jogo: **não confirmada** (não há hardware aqui). Hipótese principal: o SDL2 do PS3 só enxerga o que a libio expõe como pad e o DS4 funciona no XMB por outro caminho do sistema. A v1.8 troca para leitura direta pela libio e registra o que ela informa (`saves/pad_log.txt` e tela inicial). Se o DS4 não aparecer nem assim, a libio não o expõe para o jogo e será preciso outra abordagem (ex.: USB HID direto), que NÃO foi implementada.
- Observação: a v1.7 nunca foi compilada com o toolchain por mim; o README dela já informava isso.

## Alterações
Novos: `include/PadInput.h`, `src/PadInput.cpp`, `tests/pad_test.cpp`, `tests/mock/io/pad.h`.
Modificados: `include/Game.h`, `src/Game.cpp`, `include/Player.h`, `src/Player.cpp` (`cycleToolPrev`), `Makefile.ps3`, `CMakeLists.txt`, `README.md`.
Versão: título da janela, CMake 1.8.0, CONTENTID `...STARDEWPS3V18000`, pacote `StardewPS3_v1_8.pkg`. Saves continuam em `save_v1.6.dat` (compatíveis).
- PadInput: `ioPadInit` uma vez (aceita "já inicializado" e só chama `ioPadEnd` se foi quem iniciou), `ioPadGetInfo` por quadro, `ioPadGetData` por porta conectada; hot-plug; mescla várias portas; 6 quadros de calibração ao conectar (botões ignorados); centro dos analógicos medido (volta a 128 se fora de 96–160); zona morta radial 0,24; quadros com 11+ botões simultâneos descartados; `len==0` mantém o estado; L2/R2 digital ou por pressão (se o header tiver `PRE_*`).
- Detecção de tipo por VID:PID só se o `io/pad.h` tiver esses campos (o Makefile detecta sozinho). Clones costumam copiar o VID:PID da Sony: **original e paralelo não são distinguíveis com segurança**; o tratamento é por robustez (calibração/validação), não por identificação.
- Analógico direito: lido, mas o jogo não tem câmera livre, então sem função.
- Detecção automática do `io/pad.h` no Makefile (`PAD_FLAGS`; veja `make -f Makefile.ps3 info`).

## Testes
Realizados (PC, sem hardware):
- `tests/pad_test.cpp` com libio falsa: 57/57 verificações (sem VID/PID) e 60/60 (com VID/PID e pressão). Cobre init/falha/já-inicializado, hot-plug, mapeamento dos 16 botões, bordas, calibração com centro deslocado, zona morta, centro absurdo, quadro lixo, duas portas, `len==0`.
- Verificação de sintaxe (`-fsyntax-only`) de Game.cpp/Player.cpp/PadInput.cpp com headers falsos de SDL/PSL1GHT, em modo PC e PS3, sem erros nem warnings.
- Detecção de `PAD_FLAGS` no Makefile contra headers falsos.

NÃO realizados / pendentes:
- Compilação com PSL1GHT real, ELF/SELF/PKG (toolchain indisponível aqui). Os headers falsos refletem minhas suposições sobre `io/pad.h`; se der erro de campo/tipo, ajuste `src/PadInput.cpp` (bloco `Ps3PadBackend`).
- Qualquer teste em PS3 Super Slim/HEN: DS3 original, DS3 paralelo, DS4 original, DS4 paralelo, USB e Bluetooth, mapeamento no jogo, conflitos. Compatibilidade NÃO confirmada.
- Compilação da build SDL de PC com SDL2 real.

## Compilar (PS3)
```sh
export PS3DEV=/usr/local/ps3dev
export PSL1GHT=$PS3DEV
make -f Makefile.ps3 info    # confira PAD_FLAGS
make -f Makefile.ps3 clean && make -f Makefile.ps3
make -f Makefile.ps3 pkg     # gera StardewPS3_v1_8.pkg
```
Dependências: ps3toolchain/PSL1GHT, SDL2 (e opcional SDL2_mixer) em `$PS3DEV/portlibs/ppu`, ferramentas `fself.py`, `make_self_npdrm`, `sfo.py`, `pkg.py`.
Teste de lógica no PC: `g++ -std=gnu++11 -DSTARDEW_PS3 -Itests/mock -Iinclude src/PadInput.cpp tests/pad_test.cpp -o pad_test && ./pad_test`

## Instalar no PS3 HEN
1. Copie `StardewPS3_v1_8.pkg` para um pendrive USB (FAT32), na raiz ou em `/PKG`.
2. Ative o HEN, vá em Jogo > Package Manager/Instalar arquivos de pacote > pendrive e instale.
3. Se a v1.7 já estiver instalada (mesmo ID `STDP00001`), a v1.8 a substitui; os saves em `USRDIR/saves` são mantidos. Faça backup antes.
4. Conecte os controles antes de abrir o jogo (USB) e confira a linha "Controle:" na tela inicial. Se algo falhar, envie `saves/pad_log.txt`.
